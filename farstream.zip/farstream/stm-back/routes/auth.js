const express = require('express')

const authController = require('../controllers/auth')
const { authJwt, authValidators } = require('../middleware');
const { rateLimit } = require('express-rate-limit');

const router = express.Router()

const authLimiter = rateLimit({
    windowMs: 5 * 60 * 1000, // 5 minutes
    max: 5, // Limit to 5 requests per windowMs
    message: 'Trop de tentatives de connexion, veuillez réessayer plus tard.',
});

router.post('/api/login', [authValidators.validateUsername, authValidators.validateLoginPassword], authLimiter, authController.postLogin)
router.post('/api/refresh', authController.getRefresh)
router.get('/api/history', authJwt.verifyToken, authJwt.isAdmin, authController.getHistory)
router.post('/api/logout', authJwt.verifyToken, authController.postLogout)

module.exports = router
