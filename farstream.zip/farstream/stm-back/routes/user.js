const express = require('express')

const userController = require('../controllers/user')
const { authJwt, authValidators } = require("../middleware")

const router = express.Router()
router.use(authJwt.verifyToken)
router.use(authJwt.isAdmin)

router.get('/api/users', userController.getUsers)
router.post('/api/user', [
    authValidators.validateUsername,
    authValidators.validateObservation,
    authValidators.validatePassword,
    authValidators.validateRole,
], userController.createUser)

router.put('/api/user/:id', [
    authValidators.validateId,
    authValidators.validateUsername,
    authValidators.validateObservation,
    authValidators.validatePassword,
    authValidators.validateRole,
], userController.updateUser)

router.delete('/api/user/:id', [authValidators.validateId], userController.deleteUser)


module.exports = router