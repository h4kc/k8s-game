const express = require('express')

const sourceController = require('../controllers/source')
const { authJwt, authValidators } = require("../middleware")

const router = express.Router()
router.use(authJwt.verifyToken)

router.get('/api/source', authJwt.isAdmin, sourceController.getSourceList)

router.get('/api/source/user', sourceController.getUserSources)

router.get('/api/vods', authJwt.isAdmin, sourceController.getAllVods)

router.get('/api/vods/source/:sourceId', [authValidators.validateSourceId], sourceController.getSourcePlaylist)

router.get('/api/generateId', sourceController.getGeneratedId)

router.put('/api/vods/list/source/:sourceId',
    authJwt.isAdmin,
    [authValidators.validateSourceId, authValidators.validateVodIds],
    sourceController.associateMultipleVods)

router.put('/api/vods/:vodId/source/:sourceId',
    authJwt.isAdmin,
    [authValidators.validateSourceId, authValidators.validateVodId],
    sourceController.associateVod)

router.delete('/api/vods/list', authJwt.isAdmin, [authValidators.validateVodIds], sourceController.deleteMultipleVods)

router.delete('/api/vods/:id', authJwt.isAdmin, [authValidators.validateId], sourceController.deleteVod)

router.post('/api/source', authJwt.isAdmin, [
    authValidators.validateName,
    // authValidators.validateStreamUrl,
    // authValidators.validateStreamId,
    authValidators.validatePosition,
    authValidators.validateDescription,
    authValidators.validateDate,
], sourceController.createSource)

router.put('/api/source/:id', authJwt.isAdmin, [
    authValidators.validateId,
    authValidators.validateName,
    authValidators.validateStreamUrl,
    authValidators.validatePosition,
    authValidators.validateDescription,
    authValidators.validateDate,
], sourceController.updateSource)

router.delete('/api/source/:id', authJwt.isAdmin, [authValidators.validateId], sourceController.deleteSource)

module.exports = router