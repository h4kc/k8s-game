// const path = require('path')

const express = require('express')

const streamController = require('../controllers/stream')
const { authJwt, authValidators } = require("../middleware")

const router = express.Router()
router.use(authJwt.verifyToken)

router.get('/api/stream', streamController.getStreamList)

router.put('/api/stream/:id/recording/:recordingStatus',
    authJwt.isRecorder,
    [authValidators.validateParmStreamId, authValidators.validateStatus],
    streamController.updateBroadcastRecord)

// router.post('/api/stream/:id/action/:action',
//     authJwt.isRecorder,
//     [authValidators.validateParmStreamId, authValidators.validateAction],
//     streamController.updateBroadcastStatus)

module.exports = router