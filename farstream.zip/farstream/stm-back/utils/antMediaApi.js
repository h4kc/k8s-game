const axios = require('axios');
const https = require('https');
// 1.60
const BASE_URL = "http://192.168.11.184:5080/WebRTCApp/rest/v2";

const axiosInstance = axios.create({
    baseURL: BASE_URL,
    httpsAgent: new https.Agent({
      rejectUnauthorized: false
    }),
    headers: {
      'Content-Type': 'application/json',
      'Authorization': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ0b2tlbiIsImlhdCI6MTUxNjIzOTAyMn0.OESIxgNsnD_JwByKTXcrw9Ov4GaOUZw66QxMfmudhKQ'
    }
  });
  

const fetchData = async (endpoint) => {
    try {
        const response = await axiosInstance.get(endpoint);
        return response;
    } catch (error) {
        throw error;
    }
};

const postData = async (endpoint, data) => {
    try {
        const response = await axiosInstance.post(endpoint, data);
        return response;
    } catch (error) {
        throw error;
    }
};

const updateData = async (endpoint, data) => {
    try {
      const response = await axiosInstance.put(endpoint, data);
      return response;
    } catch (error) {
      throw error;
    }
  };

const deleteData = async (endpoint) => {
    try {
      const response = await axiosInstance.delete(endpoint);
      return response;
    } catch (error) {
      throw error;
    }
  };

module.exports = { fetchData, postData, updateData, deleteData };
