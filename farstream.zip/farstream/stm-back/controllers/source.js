const { fetchData, postData, updateData, deleteData } = require('../utils/antMediaApi')
const { v4: uuidv4 } = require('uuid')
const db = require("../models")
const { validationResult } = require('express-validator')
const Source = db.source
const Playlist = db.playlist
const User = db.user

// @desc get all sources
// @route get /source
// @access Private
exports.getSourceList = async (req, res) => {
    try {
        const sources = await Source.findAll()
        const formattedSources = sources.map(source => {
            const { createdAt, updatedAt, streamId, user_sources, ...formattedSource } = source.toJSON()
            return formattedSource
        })

        return res.json({ sources: formattedSources })
    } catch (error) {
        res.status(500).json({ error: 'Erreur lors de l\'appel des sources' })
    }
}

// @desc get user sources
// @route get /source/user/:id
// @access Private
exports.getUserSources = async (req, res) => {
    try {
        const id = req.userId // must update slice in front end
        const user = await User.findByPk(id)
        let sources
        if (req.role === "admin") {
            sources = await Source.findAll()
        } else {
            sources = await user.getSources()
        }

        const formattedSources = sources.map(source => {
            const { createdAt, updatedAt, user_sources, ...formattedSource } = source.toJSON()
            return formattedSource
        })

        return res.json({ sources: formattedSources })
    } catch (error) {
        res.status(500).json({ error: 'Erreur lors de l\'appel des sources' })
    }
}

// @desc create a source
// @route post /source
// @access Private
exports.createSource = async (req, res) => {
    const randomStreamId = uuidv4()
    const { protocol, streamId, name, streamUrl, position, description, creationDate } = req.body
    console.log(req.body)

    let streamIdToInsert
    if (protocol === "RTSP") {
        streamIdToInsert = randomStreamId
    } else {
        streamIdToInsert = streamId

    }
    const errors = validationResult(req)
    const validationErrors = errors.array()
    const validationMessage = validationErrors.length > 0 ? validationErrors[0].msg : ''

    if (!errors.isEmpty()) {
        return res.status(400).json({ message: validationMessage })
    }

    try {
        const duplicate = await Source.findOne({ where: { name } })

        if (duplicate) {
            return res.status(409).json({ message: 'Nom déjà utilisé' })
        }

        let antMediaInfo
        if (protocol === "RTSP") {
            antMediaInfo = { streamId: streamIdToInsert, name, streamUrl, type: "streamSource" }
        } else {
            antMediaInfo = { streamId: streamIdToInsert, name, type: "liveStream" }
        }
        console.log('antMediaInfo', antMediaInfo)


        const response = await postData(`broadcasts/create`, antMediaInfo)
        if (response.status === 200) {
            const createdSource = await Source.create({ streamId: streamIdToInsert, protocol, name, streamUrl, position, description, creationDate })
            if (!createdSource) {
                return res.status(500).json({ error: 'Erreur lors de la creation de la source partie sql' })
            }
            //that for keeping info for history log
            req.createdSource = createdSource

            return res.status(200).json({ message: 'Source ajoutee avec succes', antMediasource: response.data })
        } else {
            const status = response?.status ? response.status : 500
            return res.status(status).json({ error: response.data })
        }
    } catch (error) {
        console.log(error)
        let status
        let msg
        if (error.response) {
            status = error.response.status
            msg = error.response.data?.message
        } else if (error.code === 'ETIMEDOUT') {
            status = 500
            msg = 'Le serveur Ant Media a pris beaucoup de temps pour repondre.'
        } else {
            status = 500
            msg = 'Erreur lors de la creation de la source.'
        }
        res.status(status).json({ error: msg })
    }
}

// @desc get random ID for RTMP streams
// @route get /generateId
// @access Private
exports.getGeneratedId = async (req, res) => {
    const randomStreamId = uuidv4()
    return res.status(200).json({ message: 'ID generated', result: randomStreamId })
}

// @desc update source
// @route put /source/:id
// @access Private
exports.updateSource = async (req, res) => {
    const { id } = req.params
    const { name, streamUrl, position, description, creationDate } = req.body
    // console.log(req.body)
    const errors = validationResult(req)
    const validationErrors = errors.array()
    const validationMessage = validationErrors.length > 0 ? validationErrors[0].msg : ''
    // console.log(validationErrors)
    if (!errors.isEmpty()) {
        return res.status(400).json({ message: validationMessage })
    }

    try {
        const sourceToUpdate = await Source.findByPk(id)

        if (!sourceToUpdate) {
            return res.status(404).json({ message: 'Source introuvable' })
        }
        //this block generates info for keeping it in history log
        req.updatedSource = sourceToUpdate
        const updatedInfo = [
            sourceToUpdate.name !== name && 'le nom',
            sourceToUpdate.streamUrl !== streamUrl && 'le lien',
            sourceToUpdate.position !== position && 'la position',
            sourceToUpdate.description !== description && 'la description',
            sourceToUpdate.creationDate !== creationDate && 'la date de création',
        ].filter(Boolean).join(' et ') || 'aucun detail'

        // Set updatedInfo in the request
        req.updatedInfo = updatedInfo

        const response = await updateData(`broadcasts/${sourceToUpdate.streamId}`, {
            name,
            streamUrl
        })
        // console.log(response)
        if (response.data.success) {
            const [updatedRowCount] = await Source.update(
                { name, streamUrl, position, description, creationDate },
                { where: { id } }
            )
            if (updatedRowCount > 0) {
                // console.log(`Updated ${updatedRowCount} row(s)`)
                return res.status(200).json({ message: 'Source mise à jour avec succès' })
            } else {
                return res.status(500).json({ message: 'Aucune mise à jour effectuée: partie sql' })
            }
        } else {
            const status = response.status ? response.status : 500
            return res.status(status).json({ data: response.data })
        }
    } catch (error) {
        console.log(error)
        let status
        let msg
        if (error.response) {
            status = error.response.status
            msg = error.response.data?.message
        } else if (error.code === 'ETIMEDOUT') {
            status = 500
            msg = 'Le AMS a pris beaucoup de temps pour repondre.'
        } else {
            status = 500
            msg = 'Erreur lors de la mise a jour de la source.'
        }
        res.status(status).json({ error: msg, ams: error })
    }
}

// @desc delete source
// @route delete /source/:id
// @access Private
exports.deleteSource = async (req, res) => {
    const { id } = req.params
    const errors = validationResult(req)
    const validationErrors = errors.array()
    const validationMessage = validationErrors.length > 0 ? validationErrors[0].msg : ''
    if (!errors.isEmpty()) {
        return res.status(400).json({ message: validationMessage })
    }
    try {
        const sourceTodelete = await Source.findByPk(id)
        if (!sourceTodelete) {
            return res.status(404).json({ message: 'Source ne peut pas etre trouvee' })
        }
        //that for keeping info for history log
        req.deletedSource = sourceTodelete

        const response = await deleteData(`broadcasts/${sourceTodelete.streamId}`)
        if (response.data.success) {
            const rowCount = await Source.destroy({ where: { id } })
            if (rowCount === 0) {
                return res.status(404).json({ error: 'Source introuvable ou deja supprimee dans sql' })
            } else {
                return res.status(200).json({ message: `Source supprimee avec succes` })
            }
        } else {
            return res.status(200).json({ message: `success : ${response.data.success}` })
        }
    } catch (error) {
        console.log(error)
        let status
        let msg
        if (error.response) {
            status = error.response.status
            msg = error.response.data?.message
        } else if (error.code === 'ETIMEDOUT') {
            status = 500
            msg = 'Le AMS a pris beaucoup de temps pour repondre.'
        } else {
            status = 500
            msg = 'Erreur lors de la suppression de la source.'
        }

        res.status(status).json({ error: msg })
    }
}

// @desc get all v-o-d
// @route get /vods
// @access Private
exports.getAllVods = async (req, res) => {
    try {
        const vods = await Playlist.findAll()
        const vodData = []
        function formatDateTime(date) {
            const formattedDate = date.toLocaleDateString('fr-FR', {
                year: 'numeric',
                month: 'numeric',
                day: 'numeric'
            })

            const formattedTime = date.toLocaleTimeString('fr-FR', {
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit'
            })

            return `Sauvegarde du ${formattedDate} - ${formattedTime}`
        }
        for (const item of vods) {
            const response = await fetchData(`vods/${item.vodId}`)
            if (item.sourceId) {
                const source = await Source.findByPk(item.sourceId)
                response.data.streamName = source.name
            }
            const creationDate = new Date(response.data.creationDate)
            response.data.creationDate = formatDateTime(creationDate)
            vodData.push({
                ...response.data,
                sourceId: item.sourceId
            })
        }

        return res.status(200).json(vodData)
    } catch (error) {
        console.log(error)
        let status
        let msg
        if (error.response) {
            status = error.response.status
            msg = error.response.data?.message
        } else if (error.code === 'ETIMEDOUT') {
            status = 500
            msg = 'Le AMS a pris beaucoup de temps pour repondre.'
        } else {
            status = 500
            msg = 'Erreur lors de la recuperation des sauvegardes.'
        }
        res.status(status).json({ error: msg })
    }
}

// @desc get playlist for specific source
// @route get /api/vods/source/:sourceId
// @access Private
exports.getSourcePlaylist = async (req, res) => {
    try {
        const { sourceId } = req.params

        const userId = req.userId
        const errors = validationResult(req)
        const validationErrors = errors.array()
        const validationMessage = validationErrors.length > 0 ? validationErrors[0].msg : ''
        if (!errors.isEmpty()) {
            return res.status(400).json({ message: validationMessage })
        }

        let source
        if (req.role !== 'admin') {
            source = await Source.findOne({
                where: { id: sourceId },
                include: [{
                    model: User,
                    where: { id: userId }
                }]
            });

            if (!source) {
                return res.status(400).json({ message: 'Source not found or not associated with user' });
            }
        } else {
            source = await Source.findByPk(sourceId)
            if (!source) {
                return res.status(400).json({ message: 'Source not found' })
            }
        }

        const playlistItems = await source.getPlaylists()
        const vodData = []
        function formatDateTime(date) {
            const formattedDate = date.toLocaleDateString('fr-FR', {
                year: 'numeric',
                month: 'numeric',
                day: 'numeric'
            })

            const formattedTime = date.toLocaleTimeString('fr-FR', {
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit'
            })

            return `Sauvegarde du ${formattedDate} - ${formattedTime}`
        }
        for (const item of playlistItems) {
            const response = await fetchData(`vods/${item.vodId}`)
            const creationDate = new Date(response.data.creationDate)
            response.data.creationDate = formatDateTime(creationDate)
            vodData.push({
                ...response.data,
                createdAt: item.createdAt, // Include the createdAt property
                streamName: source.name,
                sourceId: source.id
            })
        }

        res.json(vodData)
    } catch (error) {
        console.log(error)
        res.status(500).json({ error: 'Erreur lors de l\'appel de playlist' })
    }
}

// @desc associate v-o-d with a source
// @route put /vods/:vodId
// @access Private
exports.associateVod = async (req, res) => {
    try {
        const { vodId, sourceId } = req.params

        const errors = validationResult(req)
        const validationErrors = errors.array()
        const validationMessage = validationErrors.length > 0 ? validationErrors[0].msg : ''
        if (!errors.isEmpty()) {
            return res.status(400).json({ message: validationMessage })
        }

        const associteSource = await Source.findByPk(sourceId)
        if (!associteSource) {
            return res.status(404).json({ message: 'Source ne peut pas etre trouvee' })
        }
        //that for keeping info for history log
        req.associteSource = associteSource

        const vod = await Playlist.findOne({ where: { vodId } })
        if (!vod) {
            return res.status(404).json({ message: 'Vod introuvable' })
        }
        if (vod.sourceId) {
            return res.status(400).json({ message: 'Vod deja associee' })
        }

        const [updatedRowCount] = await Playlist.update(
            { sourceId },
            { where: { vodId } }
        )
        if (updatedRowCount > 0) {
            return res.status(200).json({ message: 'vod mise à jour avec succès' })
        } else {
            return res.status(500).json({ message: 'Aucune mise à jour effectuée' })
        }

    } catch (error) {
        console.log(error)
        res.status(500).json({ error: 'Erreur lors de l\'appel de playlist' })
    }
}

// @desc Associate multiple V-O-Ds with a source
// @route put /vods/associate-multiple
// @access Private
exports.associateMultipleVods = async (req, res) => {
    try {
        const { sourceId } = req.params
        const { vodIds } = req.body

        const errors = validationResult(req)
        const validationErrors = errors.array()
        const validationMessage = validationErrors.length > 0 ? validationErrors[0].msg : ''
        if (!errors.isEmpty()) {
            return res.status(400).json({ message: validationMessage })
        }

        const associteSource = await Source.findByPk(sourceId)
        if (!associteSource) {
            return res.status(404).json({ message: 'Source ne peut pas etre trouvee' })
        }
        //that for keeping info for history log
        req.associteSource = associteSource

        const vods = await Playlist.findAll({ where: { vodId: vodIds } })

        if (vods.length === 0) {
            return res.status(404).json({ message: 'Aucune Vod trouvée' })
        }

        // Check if any of the Vod is already associated
        if (vods.some((vod) => vod.sourceId)) {
            return res.status(400).json({ message: 'Au moins une Vod est déjà associée' })
        }

        const updatedRowCount = await Playlist.update(
            { sourceId },
            { where: { vodId: vodIds } }
        )

        if (updatedRowCount[0] === vodIds.length) {
            return res.status(200).json({ message: 'Vods mises à jour avec succès' })
        } else {
            return res.status(500).json({ message: 'Aucune ou certaines mises à jour non effectuées' })
        }
    } catch (error) {
        console.error(error)
        res.status(500).json({ error: 'Erreur lors de l\'association des Vods' })
    }
}

// @desc delete playlist item
// @route delete /vods/:id
// @access Private
exports.deleteVod = async (req, res) => {
    try {
        const { id: vodId } = req.params

        const errors = validationResult(req)
        const validationErrors = errors.array()
        const validationMessage = validationErrors.length > 0 ? validationErrors[0].msg : ''
        if (!errors.isEmpty()) {
            return res.status(400).json({ message: validationMessage })
        }

        const vodTodelete = await Playlist.findOne({ where: { vodId } })
        if (!vodTodelete) {
            return res.status(404).json({ message: 'L\'element ne peut pas etre trouve' })
        }

        const id = vodTodelete.id
        const response = await deleteData(`vods/${vodId}`)
        if (response.data.success) {
            const rowCount = await Playlist.destroy({ where: { id } })
            if (rowCount === 0) {
                return res.status(404).json({ error: 'L\'element introuvable ou deja supprimee dans sql' })
            } else {
                return res.status(200).json({ message: `L\'element supprimee avec succes` })
            }
        } else {
            return res.status(200).json({ message: `success : ${response.data.success}` })
        }
    } catch (error) {
        res.status(500).json({ error: 'Erreur lors de la suppression de l\'element' })
    }
}

// @desc delete multiple playlist items
// @route delete /vods/list
// @access Private
exports.deleteMultipleVods = async (req, res) => {
    try {
        const { vodIds } = req.body
        console.log(vodIds)

        const errors = validationResult(req)
        const validationErrors = errors.array()
        const validationMessage = validationErrors.length > 0 ? validationErrors[0].msg : ''
        if (!errors.isEmpty()) {
            return res.status(400).json({ message: validationMessage })
        }

        const vodsTodelete = await Playlist.findAll({ where: { vodId: vodIds } })

        if (!vodsTodelete || vodsTodelete.length === 0) {
            return res.status(404).json({ message: 'Aucun élément de la playlist trouvé pour les ids fournis' })
        }

        const deletePromises = vodsTodelete.map(async (playlistItem) => {
            const { id, vodId } = playlistItem
            const response = await deleteData(`vods/${vodId}`)

            if (response.data.success) {
                await Playlist.destroy({ where: { id } })
            }

            return response.data.success
        })

        const results = await Promise.all(deletePromises)

        if (results.every(Boolean)) {
            return res.status(200).json({ message: 'Éléments de la playlist supprimés avec succès' })
        } else {
            return res.status(500).json({ error: 'Erreur lors de la suppression d\'un ou de plusieurs éléments de la playlist' })
        }
    } catch (error) {
        console.error(error)
        res.status(500).json({ error: 'Erreur interne du serveur' })
    }
}
