
// const { validationResult } = require('express-validator')
require('dotenv').config();
var jwt = require("jsonwebtoken")
var bcrypt = require("bcryptjs")
const asyncHandler = require('express-async-handler')

const db = require("../models")
const User = db.user
const HistoryEntry = db.historyEntry
const { validationResult } = require("express-validator")

// @desc Login
// @route POST /login
// @access Public
exports.postLogin = asyncHandler(async (req, res) => {
    const { username, password } = req.body
    console.log(req.body)

    const errors = validationResult(req) // validation de id
    const validationErrors = errors.array()
    const validationMessage = validationErrors.length > 0 ? validationErrors[0].msg : ''

    if (!errors.isEmpty()) {
        return res.status(400).json({ message: validationMessage })
    }

    const user = await User.findOne({ where: { username } })

    if (!user) {
        return res.status(401).json({ message: 'Nom  d\'utilisateur ou mot de passe invalide.' })
    }

    const match = await bcrypt.compare(password, user.password)
    if (!match) return res.status(401).json({ message: 'Nom  d\'utilisateur ou mot de passe invalide.' })

    req.username = user.username
    req.userId = user.id

    const refreshToken = jwt.sign(
        { "username": user.username },
        process.env.REFRESH_TOKEN_SECRET,
        { expiresIn: '7d' }
    )

    //session logic
    user.sessionID = 1
    user.refreshToken = refreshToken
    await user.save()

    const accessToken = jwt.sign(
        {
            "UserInfo": {
                "id": user.id,
                "username": user.username,
                "role": user.roleId === 2 ? 'admin' : user.isRecorder ? 'recorder' : 'viewer',
                "session": user.sessionID
            }
        },
        process.env.ACCESS_TOKEN_SECRET,
        { expiresIn: '15m' }
    )

    // Send accessToken containing username and role
    res.json({ accessToken, refreshToken })
})


// @desc Refresh
// @route GET /refresh
// @access Public - because access token has expired
exports.getRefresh = (req, res) => {
    console.log(req.body)
    const refreshToken = req.body.refreshToken
    if (!refreshToken) return res.status(401).json({ message: "Vous n'êtes pas autorisé" })

    jwt.verify(
        refreshToken,
        process.env.REFRESH_TOKEN_SECRET,
        asyncHandler(async (err, decoded) => {
            if (err) return res.status(403).json({ message: 'votre acces est refuse' })

            const user = await User.findOne({ where: { username: decoded.username } })

            if (!user || user.refreshToken !== refreshToken) {
                return res.status(403).json({ error: 'Refresh Token Invalide' })
            }

            const accessToken = jwt.sign(
                {
                    "UserInfo": {
                        "id": user.id,
                        "username": user.username,
                        "role": user.roleId === 2 ? 'admin' : user.isRecorder ? 'recorder' : 'viewer',
                        "session": user.sessionID
                    }
                },
                process.env.ACCESS_TOKEN_SECRET,
                { expiresIn: '15m' }
            )

            res.json({ accessToken })
        })
    )
}

// @desc History
// @route GET /history
// @access Private - get all history entries
exports.getHistory = async (req, res) => {
    try {
        const historyEntries = await HistoryEntry.findAll({
            order: [['id', 'DESC']]
        });

        // Format createdAt values
        const formattedHistory = historyEntries.map(entry => ({
            ...entry.toJSON(),
            createdAt: entry.createdAt.toLocaleString('fr-FR', {
                day: 'numeric',
                month: 'long',
                year: 'numeric',
                hour: 'numeric',
                minute: 'numeric',
                second: 'numeric',
                hour12: false // Use 24-hour time format
            })
        }));

        res.json({ history: formattedHistory });
    } catch (error) {
        console.error('Error getting history:', error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
};


// @desc Logout
// @route POST /logout
// @access Public - just to clear cookie if exists
exports.postLogout = async (req, res) => {
    
    const userId = req.userId
    const user = await User.findByPk(userId)
    await user.clearSession()
    
    res.json({ message: 'Session cleared' })
}


