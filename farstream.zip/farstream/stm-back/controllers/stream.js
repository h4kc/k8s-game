
const db = require("../models")
const { fetchData, updateData, postData } = require('../utils/antMediaApi')
const { validationResult } = require('express-validator')
const User = db.user
const Source = db.source
const Playlist = db.playlist

exports.getStreamList = async (req, res) => {
    try {
        const id = req.userId
        const user = await User.findByPk(id)
        let sources
        if (req.role === "admin") {
            sources = await Source.findAll()
        } else {
            sources = await user.getSources()
        }

        const streamsData = []
        for (const source of sources) {
            const response = await fetchData(`broadcasts/${source.streamId}`)
            // Include source.protocol
            streamsData.push({ ...response.data, protocol: source.protocol })
        }

        res.json(streamsData)
    } catch (error) {
        console.log(error)
        let status
        let msg
        if (error.response) {
            status = error.response.status
            msg = error.response.data?.message
        } else if (error.code === 'ETIMEDOUT') {
            status = 500
            msg = 'Le AMS a pris beaucoup de temps pour repondre.'
        } else {
            status = 500
            msg = 'Erreur lors de lappel des streams.'
        }
        res.status(status).json({ error: msg, ams: error })
    }
}

exports.updateBroadcastRecord = async (req, res) => {
    const { id: streamId, recordingStatus } = req.params

    const errors = validationResult(req)
    const validationErrors = errors.array()
    const validationMessage = validationErrors.length > 0 ? validationErrors[0].msg : ''
    // console.log(validationErrors)
    if (!errors.isEmpty()) {
        return res.status(400).json({ message: validationMessage })
    }

    try {
        const source = await Source.findOne({ where: { streamId } })
        if (!source) {
            return res.status(400).json({ message: 'Source not found' })
        }
        // keeping info for history log
        req.streamObj = source

        const response = await updateData(`broadcasts/${streamId}/recording/${recordingStatus}`)
        if (response.data.success && recordingStatus === 'false') {
            const createdItem = await Playlist.create({ vodId: response.data.dataId })

            if (createdItem) {
                const associate = await source.addPlaylist(createdItem)
                if (!associate) {
                    return res.status(500).json({ message: 'Error associating playlist item with source' })
                }
            } else {
                return res.status(500).json({ message: 'Error creating VOD' })
            }
        }

        return res.json(response.data)
    } catch (error) {
        console.error(error)
        res.status(500).json({ message: 'record request didn\'t go well' })
    }
}


// exports.updateBroadcastStatus = async (req, res) => {
//     const { id: streamId, action } = req.params
//     const errors = validationResult(req)
//     const validationErrors = errors.array()
//     const validationMessage = validationErrors.length > 0 ? validationErrors[0].msg : ''
//     // console.log(validationErrors)
//     if (!errors.isEmpty()) {
//         return res.status(400).json({ message: validationMessage })
//     }
//     try {
//         const source = await Source.findOne({ where: { streamId } })
//         if (!source) {
//             return res.status(400).json({ message: 'Source not found' })
//         }
//         //that for keeping info for history log
//         req.streamObj = source
//         const response = await postData(`broadcasts/${streamId}/${action}`)
//         res.json(response.data)
//     } catch (error) {
//         console.error(error)
//         res.status(500).json({ message: 'toggle Broadcast didn\'t go well' })
//     }
// }



