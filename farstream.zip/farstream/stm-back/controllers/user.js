const { validationResult } = require('express-validator')
var bcrypt = require("bcryptjs")
const asyncHandler = require('express-async-handler')

const db = require("../models")
const User = db.user
const Role = db.role
const Source = db.source

// @desc Get all users
// @route get /users
// @access Private
exports.getUsers = async (req, res, next) => {
    try {
        const users = await User.findAll({
            include: [{ model: Role }, { model: Source }]
        })
        const formattedUsers = users.map(user => {
            const sources = user.sources && user.sources.length > 0
                ? user.sources.map(source => ({ id: source.id, name: source.name }))
                : []
            return {
                ...user.toJSON(),
                password: '', // Set password to an empty string
                role: user.role ? user.role.name : 'no role',
                sources: sources
            }
        }).map(({ createdAt, updatedAt, roleId, refreshToken, sessionID, ...user }) => user)

        res.json({ users: formattedUsers })
    } catch (error) {
        console.error(error)
        res.status(500).json({ error: 'get users list request didn\'t go well' })
    }
}


// @desc Registration
// @route POST /user
// @access Private
exports.createUser = asyncHandler(async (req, res) => {
    const { username, observation, password, role, sources } = req.body
    // console.log(req.body)

    const errors = validationResult(req)
    const validationErrors = errors.array()
    const validationMessage = validationErrors.length > 0 ? validationErrors[0].msg : ''

    if (!errors.isEmpty()) {
        return res.status(400).json({ message: validationMessage })
    }

    try {
        const duplicate = await User.findOne({ where: { username } })

        if (duplicate) {
            return res.status(409).json({ message: 'Nom déjà utilisé' })
        }

        const hashedPassword = await bcrypt.hash(password, 12)
        let createdUser

        if (role === "admin") {
            return res.status(400).json({ message: 'L\'admin est déjà crée' })
        } else {
            if (!sources || sources.length === 0) {
                return res.status(400).json({ message: 'Aucune source sélectionnée' })
            }

            const userSources = await Source.findAll({ where: { id: sources } })

            if (!userSources || userSources.length === 0) {
                return res.status(400).json({ message: 'Aucune source valide sélectionnée' })
            }

            if (role === 'recorder') {
                const recorderUsers = await User.findAll({ where: { isRecorder: true } })
                const nonAdminRecorder = recorderUsers.filter(user => user.roleId !== 2)
                if (nonAdminRecorder[0]) {
                    await User.update({ isRecorder: false }, { where: { id: nonAdminRecorder[0].id } })
                }
            }

            createdUser = await User.create({
                username,
                observation,
                password: hashedPassword,
                isRecorder: role === 'recorder',
                roleId: 1, //here is automatically created as viwer
            })

            if (!createdUser) {
                return res.status(400).json({ message: 'Les informations reçues sont invalides' })
            }

            const userSourcesAdded = await createdUser.addSources(userSources)

            if (!userSourcesAdded) {
                // return res.status(400).json({ message: 'Erreur lors de l\'association des sources' })
            }
        }
        //that for keeping info for history log
        req.createdUser = createdUser

        return res.status(200).json({ message: `Utilisateur ${username} ajouté avec succès` })

    } catch (error) {
        console.error(error)
        res.status(500).json({ error: "Erreur lors de la création de l'utilisateur" })
    }

})

// @desc update specific user
// @route PUT /user
// @access Private
exports.updateUser = asyncHandler(async (req, res) => {
    const { id } = req.params 
    const { username, observation, password, role, sources } = req.body
    console.log(req.body)
    const errors = validationResult(req) // ici je valide req.body et req.params, voir le middlware authValidators
    const validationErrors = errors.array()
    const validationMessage = validationErrors.length > 0 ? validationErrors[0].msg : ''

    if (!errors.isEmpty()) {
        return res.status(400).json({ message: validationMessage })
    }

    let hashedPassword = password ? await bcrypt.hash(password, 12) : null

    try {
        const userToUpdate = await User.findByPk(id)

        if (!userToUpdate) {
            return res.status(404).json({ message: 'Utilisateur introuvable' })
        }

        //this block generates info for keeping it in history log
        req.updatedUser = userToUpdate
        // Helper function to compare arrays
        function arraysEqual(arr1, arr2) {
            return arr1 && arr2 && arr1.length === arr2.length && arr1.every((value, index) => value === arr2[index])
        }
        const usersources = await userToUpdate.getSources()
        const sourcesIds = usersources.map(source => source.id)
        const updatedInfo = [
            userToUpdate.username !== username && 'le nom d\'utilisateur',
            userToUpdate.observation !== observation && 'l\'observation',
            password && 'le mot de passe',
            role === 'recorder' && 'l\'abilité de sauvgarde',
            !arraysEqual(sourcesIds, sources) && 'les sources allouées'
        ].filter(Boolean).join(' et ') || 'aucun detail'

        // Set updatedInfo in the request
        req.updatedInfo = updatedInfo

        if (role === 'recorder' && !userToUpdate.isRecorder) {
            const recorderUsers = await User.findAll({ where: { isRecorder: true } })
            const nonAdminRecorder = recorderUsers.filter(user => user.roleId !== 2)
            if (nonAdminRecorder[0]) {
                await User.update({ isRecorder: false }, { where: { id: nonAdminRecorder[0].id } })
            }
        }

        const userData = {
            username,
            observation,
            ...(hashedPassword && { password: hashedPassword }), // Only include if password is provided
            isRecorder: role === 'recorder' || role === 'admin'
        }

        let updatedRowCount

        if (role !== "admin") {
            // Check for sources only if the role is not "admin"
            if (!sources || sources.length === 0) {
                return res.status(400).json({ message: 'Aucune source sélectionnée' })
            }

            [updatedRowCount] = await User.update(userData, { where: { id } })

            if (updatedRowCount > 0) {
                const userSources = await Source.findAll({ where: { id: sources } })

                if (!userSources || userSources.length === 0) {
                    return res.status(400).json({ message: 'Aucune source valide sélectionnée' })
                }

                await userToUpdate.setSources(userSources)
            }
        } else {
            // Update user directly if the role is "admin"
            [updatedRowCount] = await User.update(userData, { where: { id } })
        }

        if (updatedRowCount > 0) {
            // console.log(`Updated ${updatedRowCount} row(s)`)
            return res.status(200).json({ message: 'Utilisateur mis à jour avec succès' })
        } else {
            return res.status(500).json({ message: 'Aucune mise à jour effectuée' })
        }
    } catch (error) {
        console.error(error)
        res.status(500).json({ error: "Erreur lors de la mise à jour de l'utilisateur" })
    }

})

// @desc delete specific user
// @route DELETE /user
// @access Private
exports.deleteUser = asyncHandler(async (req, res) => {
    try {
        const { id } = req.params

        const errors = validationResult(req) // validation de id
        const validationErrors = errors.array()
        const validationMessage = validationErrors.length > 0 ? validationErrors[0].msg : ''
    
        if (!errors.isEmpty()) {
            return res.status(400).json({ message: validationMessage })
        }

        const userTodelete = await User.findByPk(id)
        if (!userTodelete) {
            return res.status(404).json({ message: 'Utilisateur ne peut pas etre trouve' })
        }

        //that for keeping info for history log
        req.deletedUser = userTodelete

        const rowCount = await User.destroy({ where: { id } })
        if (rowCount === 0) {
            return res.status(404).json({ error: 'Utilisateur introuvable ou deja supprime' })
        } else {
            return res.status(200).json({ message: `Utilisateur supprime avec succes` })
        }

    } catch (error) {
        res.status(500).json({ error: "Erreur lors de la suppression de l'utilisateur" })
    }
})