module.exports = (sequelize, Sequelize) => {
    const User = sequelize.define("user", {
      id: {
        type: Sequelize.INTEGER,
        autoIncrement: true,
        allowNull: false,
        primaryKey: true
      },
      username: {
        type: Sequelize.STRING
      },
      observation: {
        type: Sequelize.STRING
      },
      password: {
        type: Sequelize.STRING
      },
      isRecorder: {
        type: Sequelize.BOOLEAN
      },
      refreshToken: {
        type: Sequelize.STRING
      },
      sessionID: {
        type: Sequelize.STRING
      }
    });
  
    User.prototype.clearSession = async function () {
      this.sessionID = null; 
      this.refreshToken = null;
      await this.save();
    }
  
    return User
  };
  