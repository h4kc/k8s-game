module.exports = (sequelize, Sequelize) => {
    const Playlist = sequelize.define("playlist", {
        id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            allowNull: false,
            primaryKey: true
        },
        vodId: {
            type: Sequelize.STRING
        },
        observation: {
            type: Sequelize.STRING
        }

    });

    return Playlist;
};
