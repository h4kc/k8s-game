const config = require("../config/db.config.js")

const Sequelize = require("sequelize")
const sequelize = new Sequelize(
  config.DB,
  config.USER,
  config.PASSWORD,
  {
    host: config.HOST,
    dialect: config.dialect,
    // logging: false,
  }
)

const db = {}

db.Sequelize = Sequelize
db.sequelize = sequelize

db.user = require("../models/user.js")(sequelize, Sequelize)
db.role = require("../models/role.js")(sequelize, Sequelize)
db.source = require("../models/source.js")(sequelize, Sequelize)
db.playlist = require("../models/playlist.js")(sequelize, Sequelize)
db.historyEntry = require("../models/historyEntry.js")(sequelize, Sequelize)

db.role.hasMany(db.user)
db.user.belongsTo(db.role)

db.user.belongsToMany(db.source, { through: 'user_sources' })
db.source.belongsToMany(db.user, { through: 'user_sources' })

db.source.hasMany(db.playlist)
db.playlist.belongsTo(db.source)

db.ROLES = ["viewer", "admin"]

module.exports = db
