module.exports = (sequelize, Sequelize) => {
    const HistoryEntry = sequelize.define("historyEntry", {
        id: {
            type: Sequelize.INTEGER,
            primaryKey: true,
            autoIncrement: true,
            allowNull: false,
        },
        userId: {
            type: Sequelize.INTEGER,
            allowNull: false,
        },
        operation: {
            type: Sequelize.TEXT,
            allowNull: false,
        },

    })

    return HistoryEntry
}