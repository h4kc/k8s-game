module.exports = (sequelize, Sequelize) => {
    const Source = sequelize.define("source", {
        id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            allowNull: false,
            primaryKey: true
        },
        name: {
            type: Sequelize.STRING
        },
        protocol: {
            type: Sequelize.STRING
        },
        streamId: {
            type: Sequelize.STRING
        },
        streamUrl: {
            type: Sequelize.STRING
        },
        position: {
            type: Sequelize.STRING
        },
        description: {
            type: Sequelize.STRING
        },
        creationDate: {
            type: Sequelize.STRING
        }
    });

    return Source;
};
