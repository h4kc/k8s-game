const express = require('express')
const bodyParser = require('body-parser')
const cookieParser = require('cookie-parser')
const cors = require("cors")
const rateLimit = require('express-rate-limit')

var corsOptions = {
    origin: true,
    credentials: true,
    // exposedHeaders: ['x-refresh-token']
}

const limiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 100, // Limit each IP to 100 requests per windowMs
    message: 'Too many requests, please try again later.',
})

const streamRoutes = require('./routes/stream')
const authRoutes = require('./routes/auth')
const sourceRoutes = require('./routes/source')
const userRoutes = require('./routes/user')
const db = require("./models")
const { logHistory } = require('./middleware')
const { logger } = require('./middleware/logger')
const errorHandler = require('./middleware/errorHandler')
const Role = db.role
const User = db.user


const app = express()
app.use(cors(corsOptions))
app.options('*', cors())

// app.set('trust proxy', 'loopback');
app.use(cookieParser())
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({ extended: true }))

// app.use(limiter)
app.use(logger)
app.use(logHistory)
app.use(authRoutes)
app.use(sourceRoutes)
app.use(streamRoutes)
app.use(userRoutes)
app.use(errorHandler)

db.sequelize.sync()
    .then(() => {
        //initial()
        app.listen(3001)
    })
    .catch(err => {
        console.log(err)
    })

function initial() {
    Role.create({
        id: 1,
        name: "viewer"
    })

    Role.create({
        id: 2,
        name: "admin"
    })

    User.create({
        username: "admin",
        password: "$2y$10$8TokryfYLPS5phWQ91btg.1h8V/Hrpard6KK00GTSfVj4w0Z1fk5u",
        isRecorder: true,
        roleId: 2
    })
}