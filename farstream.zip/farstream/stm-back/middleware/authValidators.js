const { check, param } = require('express-validator')
const validator = require('validator')

// Custom validator for alphanumeric input
const isAlphanumeric = (value, field, allowedCharacters = []) => {
    if (!value) {
        return true
    }
    const regex = new RegExp(`^[a-zA-Z0-9${allowedCharacters.join(' ')}]+$`)
    if (!regex.test(value)) {

        const allowedCharsMessage = allowedCharacters.length > 0 ? `, caractères autorisés: [${allowedCharacters.join(' ')}]` : '.'
        throw new Error(`${field} ne doit contenir que des lettres et des chiffres${allowedCharsMessage}`)
    }
    return true
}

// Custom validator for date
const isValidDate = (value) => {
    if (!value) {
        return true
    }

    if (/[a-zA-Z]/.test(value)) {
        throw new Error(`La date ne doit pas contenir de lettres.`)
    }

    if (!value.includes('/')) {
        throw new Error(`Veuillez entrer une date valide.`)
    }

    const commonDateFormats = ['DD/MM/YYYY']

    if (!validator.isDate(value) && !commonDateFormats.some(format => validator.isDate(value, { format }))) {
        throw new Error(`Veuillez entrer une date valide.`)
    }

    return true
}

const isValidPassword = (value, req) => {
    if (req.body.password) {
        if (!value) {
            throw new Error(`Veuillez entrer un mot de passe.`)
        }
        if (value.length < 12 || value.length > 100) {
            throw new Error('Le mot de passe doit comporter entre 12 et 100 caractères');
        }
        if (!/[A-Z]/.test(value)) {
            throw new Error('Le mot de passe doit contenir au moins une lettre majuscule');
        }
        if (!/[a-z]/.test(value)) {
            throw new Error('Le mot de passe doit contenir au moins une lettre minuscule');
        }
        if (!/[0-9]/.test(value)) {
            throw new Error('Le mot de passe doit contenir au moins un chiffre');
        }
        if (!/[!@#$%^&*(),.?":{}|<>]/.test(value)) {
            throw new Error('Le mot de passe doit contenir au moins un caractère spécial');
        }
        if (/\s/.test(value)) {
            throw new Error('Le mot de passe ne peut pas contenir d’espaces');
        }
        if (!/^[a-zA-Z0-9!@#$%^&*(),.?":{}|<>]*$/.test(value)) {
            throw new Error('Le mot de passe ne peut contenir que des caractères alphanumériques et des caractères spéciaux standard');
        }
        if (/(password|123456|123456789|qwerty|abc123|password1)/i.test(value)) {
            throw new Error('Le mot de passe est trop commun');
        }
    }

    return true; // Validation passed
};

exports.validateId = param('id')
    .isInt({ min: 1 })
    .withMessage('ID must be a positive integer')

exports.validateSourceId = param('sourceId')
    .isInt({ min: 1 })
    .withMessage('sourceId must be a positive integer')

exports.validateVodId = param('vodId')
    .isString()
    .withMessage('vodId must be a string')
    .matches(/^[a-zA-Z0-9_-]+$/)
    .withMessage('vodId can only contain letters, numbers, underscores, and hyphens')

exports.validateParmStreamId = param('id')
    .isString()
    .withMessage('streamId must be a string')
    .matches(/^[a-zA-Z0-9_-]+$/)
    .withMessage('streamId can only contain letters, numbers, underscores, and hyphens')

exports.validateStatus = param('recordingStatus')
    .isIn(['true', 'false'])
    .withMessage('Status must be \'true\' or \'false\'')

exports.validateAction = param('action')
    .isIn(['start', 'stop'])
    .withMessage('Status must be \'start\' or \'stop\'')

exports.validateVodIds = check('vodIds')
    .isArray({ min: 1 })
    .withMessage('vodIds must be a non-empty array')
    .bail() // Stop validation chain if previous check fails
    .custom((value) => {
        return value.every(id =>
            typeof id === 'string' &&
            /^[a-zA-Z0-9_-]+$/.test(id)
        );
    })
    .withMessage('Each vodId can only contain letters, numbers, underscores, and hyphens')

// Express validators for your Users
exports.validateUsername = check('username')
    .trim()
    .notEmpty().withMessage('Veuillez entrer un nom d\'utilisateur.')
    .custom(value => isAlphanumeric(value, 'Le nom d\'utilisateur', ["_", "-"]))

exports.validateObservation = check('observation')
    .trim()
    .custom(value => isAlphanumeric(value, 'La description', ["'", "_", ",", ".", ":"]))

exports.validatePassword = check('password')
    .trim()
    .custom((value, { req }) => isValidPassword(value, req))

exports.validateLoginPassword = check('password')
    .notEmpty().withMessage('Veuillez entrer un mot de passe.')
    .matches(/^\S*$/)
    .withMessage('Le mot de passe ne peut pas contenir d\'espaces')
    .matches(/^[a-zA-Z0-9!@#$%^&*(),.?":{}|<>]*$/)
    .withMessage('Les données fournies contienent des caratères non alloués')

exports.validateRole = check('role')
    .notEmpty().withMessage('Veuillez choisir un rôle valide.')
    .isIn(['admin', 'viewer', 'recorder'])
    .withMessage('Veuillez choisir un rôle valide.')

// Express validators for your Sources
exports.validateName = check('name')
    .trim()
    .notEmpty().withMessage('Veuillez entrer un nom.')
    .custom(value => isAlphanumeric(value, 'Le nom', ["_", "-"]))

exports.validateStreamUrl = (req, res, next) => {
    if (req.body.protocol === 'RTMP') {
        // If protocol is RTMP, skip validation
        return next()
    }

    return check('streamUrl')
        .trim()
        .notEmpty().withMessage('Veuillez entrer un lien.')
        .isURL({ protocols: ['http', 'https', 'rtsp'] })
        .withMessage('Veuillez entrer un lien valide')(req, res, next)
}

exports.validateStreamId = (req, res, next) => {
    if (req.body.protocol === 'RTSP') {
        // If protocol is RTMP, skip validation
        return next()
    }

    return check('streamId')
        .trim()
        .notEmpty().withMessage('Veuillez entrer un identifient.')
}

exports.validateDescription = check('description')
    .trim()
    .custom(value => isAlphanumeric(value, 'La description', ["'", "_", ",", ".", ":"]))

exports.validatePosition = check('position')
    .trim()
    .custom(value => isAlphanumeric(value, 'La position', ["'", "°", ",", "."]))

exports.validateDate = check('creationDate')
    .trim()
    .custom(value => isValidDate(value))
