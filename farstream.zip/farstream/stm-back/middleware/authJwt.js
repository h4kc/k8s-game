require('dotenv').config()
const jwt = require("jsonwebtoken")
const db = require("../models")
const User = db.user

verifyToken = (req, res, next) => {
    const authHeader = req.headers.authorization || req.headers.Authorization

    if (!authHeader?.startsWith('Bearer ')) {
        return res.status(401).json({ message: 'Votre jeton d\'accès est invalide. Essayez de rafraîchir la page.' })
    }

    const token = authHeader.split(' ')[1]

    jwt.verify(
        token,
        process.env.ACCESS_TOKEN_SECRET,
        async (err, decoded) => {
            if (err) return res.status(403).json({ message: 'Forbidden' })
            const user = await User.findOne({ where: { username: decoded.UserInfo.username } })
            if (!user ) {
                return res.status(401).json({ error: 'Unauthorized - Invalid access token' });
            }
            req.username = decoded.UserInfo.username
            req.userId = decoded.UserInfo.id
            req.role = decoded.UserInfo.role
            next()
        }
    )
}

isAdmin = (req, res, next) => {
    if (req.role === "admin") {
        next()
    } else {
        res.status(403).send({
            message: "Unauthorized, Require Admin Role!"
        })
    }
}

isRecorder = (req, res, next) => {
    if (req.role === "recorder") {
        next()
    } else {
        res.status(403).send({
            message: "Unauthorized, Require Recorder Role!"
        })
    }
}

const authJwt = {
    verifyToken,
    isAdmin,
    isRecorder
}
module.exports = authJwt