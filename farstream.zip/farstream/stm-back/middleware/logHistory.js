// middleware/historyLogger.js
const db = require("../models")
const HistoryEntry = db.historyEntry

const operationDescriptions = {
    'POST /api/login': 'L\'utilisateur "{username}" s\'est connecté',
    'POST /api/logout': 'L\'utilisateur "{username}" s\'est déconnecté',

    'PUT /api/vods/list/source/:sourceId': 'L\'administrateur "{username} "a associé plusieurs sauvegardes [{liste}] avec la source "{sourceName}"',
    'PUT /api/vods/:vodId/source/:sourceId': 'L\'administrateur "{username}" a associé la sauvegarde avec l\'ID {vodId} avec la source "{sourceName}"',
    'DELETE /api/vods/list': 'L\'administrateur "{username}" a supprimé plusieurs sauvegardes [{liste}]',
    'DELETE /api/vods/:id': 'L\'administrateur "{username}" a supprimé la sauvegarde avec l\'ID {vodId}',

    'POST /api/source': 'L\'administrateur "{username}" a créé une nouvelle source "{sourceName}"',
    'PUT /api/source/:id': 'L\'administrateur "{username}" a mis à jour {updatedInfo} de la source "{sourceName}"',
    'DELETE /api/source/:id': 'L\'administrateur "{username}" a supprimé la source "{sourceName}"',

    'POST /api/stream/:id/action/:action': (action, additionalParams) => {
        if (action === 'start') {
            return `L\'administrateur "${additionalParams.username}" a commencé le broadcast du stream "${additionalParams.streamName}"`
        } else {
            return `L\'administrateur "${additionalParams.username}" a arrêté le broadcast du stream "${additionalParams.streamName}"`
        }
    },
    'PUT /api/stream/:id/recording/:recordingStatus': (recordingStatus, additionalParams) => {
        if (recordingStatus === 'true') {
            return `L\'administrateur "${additionalParams.username}" a commencé l\'enregistrement du stream "${additionalParams.streamName}"`
        } else {
            return `L\'administrateur "${additionalParams.username}" a arrêté l\'enregistrement du stream "${additionalParams.streamName}"`
        }
    },

    'POST /api/user': 'L\'administrateur "{username}" a créé un nouvel utilisateur "{manipulatedUser}"',
    'PUT /api/user/:id': 'L\'administrateur "{username}" a mis à jour {updatedInfo} de l\'utilisateur "{manipulatedUser}"',
    'DELETE /api/user/:id': 'L\'administrateur "{username}" a supprimé l\'utilisateur "{manipulatedUser}"',
}

function sanitizeUrl(route) {
    if (route.startsWith('/api/vods/list/source/')) return '/api/vods/list/source/:sourceId'
    if (route.startsWith('/api/vods/source/')) return '/api/vods/source/:sourceId'
    if (route.includes('/vods/') && route.includes('/source/')) return '/api/vods/:vodId/source/:sourceId'
    if (route.includes('/stream/') && route.includes('/recording/')) return '/api/stream/:id/recording/:recordingStatus'
    if (route.includes('/stream/') && route.includes('/action/')) return '/api/stream/:id/action/:action'
    if (route.startsWith('/api/vods/')) return route === '/api/vods/list' ? route : '/api/vods/:id'
    if (route.startsWith('/api/source/')) return '/api/source/:id'
    if (route.startsWith('/api/user/')) return '/api/user/:id'
    return route
}

async function logHistory(req, res, next) {
    try {
        const { method, originalUrl } = req
        const Url = sanitizeUrl(originalUrl)
        const operationType = `${method} ${Url}`
        const operationDescription = operationDescriptions[operationType]

        res.on('finish', async () => {
            if (res.statusCode >= 200 && res.statusCode < 300) {
                if (operationDescription) {
                    const objUser = req.createdUser || req.updatedUser || req.deletedUser
                    const source = req.createdSource || req.updatedSource || req.deletedSource || req.associteSource
                    const updatedInfo = req.updatedInfo
                    const stream = req.streamObj
                    const vodId = req.params.id || req.params.vodId

                    let formattedOperation

                    if (typeof operationDescription === 'function') {

                        const additionalParams = {
                            username: req.username || 'null',
                            streamName: stream ? stream.name : 'null',
                        }

                        formattedOperation = operationDescription(req.params.recordingStatus || req.params.action, additionalParams)
                    } else {
                        formattedOperation = operationDescription
                            .replace('{username}', req.username || 'null')
                            .replace('{sourceName}', source?.name || 'null')
                            .replace('{manipulatedUser}', objUser?.username || 'null')
                            .replace('{updatedInfo}', updatedInfo || 'null')
                            .replace('{vodId}', vodId || 'null')
                            .replace('{liste}', req.body.vodIds || 'null')
                    }

                    HistoryEntry.create({
                        userId: req.userId || 'null',
                        operation: formattedOperation,
                    })
                }
            }
        })

        next()
    } catch (error) {
        console.error('Error logging history:', error)
        res.status(500).json({ error: 'History related error' })
    }
}


module.exports = logHistory
