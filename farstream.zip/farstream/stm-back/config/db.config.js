require('dotenv').config();

module.exports = {
  HOST: process.env.DB_HOST,
  USER: process.env.DB_USER,
  PASSWORD: process.env.DB_PASSWORD,
  DB: process.env.DB_NAME,
  dialect: process.env.DB_DIALECT,
  pool: {
    max: parseInt(process.env.DB_POOL_MAX, 10),
    min: parseInt(process.env.DB_POOL_MIN, 10),
    acquire: parseInt(process.env.DB_POOL_ACQUIRE, 10),
    idle: parseInt(process.env.DB_POOL_IDLE, 10)
  }
};

// for production thats the sql commands to set up db user

// -- Create a new user
// CREATE USER 'sequelize_user'@'localhost' IDENTIFIED BY 'your_password';

// -- Grant the necessary privileges
// GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, ALTER, DROP, INDEX ON your_database.* TO 'sequelize_user'@'localhost';

// -- Apply the changes
// FLUSH PRIVILEGES;
