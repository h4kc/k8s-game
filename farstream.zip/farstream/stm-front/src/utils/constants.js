import React from "react"


import { GoBroadcast } from "react-icons/go"
import { FiSettings } from "react-icons/fi"
import { BiSolidVideos} from 'react-icons/bi'
import { BsHddNetwork} from 'react-icons/bs'


export const categories = [
  { name: "Sources", icon: <BsHddNetwork />, type: "/sources" },
  { name: "Stream", icon: <GoBroadcast />, type: "/stream"},
  { name: "Sauvegardes", icon: <BiSolidVideos/>, type: "/vods", spliter: true},
]
