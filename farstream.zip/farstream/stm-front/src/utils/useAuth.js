import { useSelector } from 'react-redux'
import jwtDecode from 'jwt-decode'
import { selectCurrentToken } from '../store/slices/authSlice'

const useAuth = () => {
    const token = useSelector(selectCurrentToken)
    let isAdmin = false
    let isRecorder = false

    if (token) {
        const decoded = jwtDecode(token)
        const { id, username, role } = decoded.UserInfo
        isAdmin = role === 'admin'
        isRecorder = role === 'recorder'
        return { id, username, isAdmin, isRecorder }
    }

    return { id: '', username: '', isAdmin }
}
export default useAuth