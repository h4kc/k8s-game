import { Navigate, Outlet, useLocation, useNavigate } from "react-router-dom"
import { useEffect, useRef, useState } from 'react'
import { useSelector } from 'react-redux'
import { selectCurrentToken } from "../store/slices/authSlice"
import { useRefreshMutation } from "../store/slices/authApiSlice"
import { CgBrowser } from "react-icons/cg"

const PersistLogin = () => {
    const token = useSelector(selectCurrentToken)
    const refToken = localStorage.getItem('refreshTo')

    const effectRan = useRef(false)
    const location = useLocation()
    const navigate = useNavigate()

    const [browser, setBrowser] = useState('')

    useEffect(() => {
        const userAgent = navigator.userAgent
        let detectedBrowser = ''

        if (userAgent.indexOf('Edg') > -1) {
            detectedBrowser = 'Edge'
        }

        setBrowser(detectedBrowser)
    }, [])

    const [trueSuccess, setTrueSuccess] = useState(false)

    const [refresh, {
        isUninitialized,
        isLoading,
        isSuccess,
        error,
        isError
    }] = useRefreshMutation()
    useEffect(() => {
        if ((effectRan.current === true || process.env.NODE_ENV !== 'development')) {
            const verifyRefreshToken = async () => {
                console.log('verifying refresh token')
                try {
                    await refresh(refToken)
                    setTrueSuccess(true)
                }
                catch (err) {
                    console.error(err)
                    // Navigate to the login page on error
                    navigate('/login')
                }
            }

            if (!token) verifyRefreshToken()
        }
        return () => effectRan.current = true
        //eslint-disable-next-line
    }, [])

    let content
    if (browser === 'Edge') {
        content = (
            <div className="flex items-center justify-center bg-white dark:bg-black text-black dark:text-white  h-[calc(100vh-64px)]">
                <div className="text-center">
                    <div className="inline-flex rounded-full bg-purple-100 dark:bg-[#7b3c7e] p-4">
                        <div className="rounded-full stroke-purple-600 bg-purple-200 dark:bg-[#c62cb9] p-4">
                            <CgBrowser  size={54} />
                        </div>
                    </div>
                    <h1 className="mt-5 text-[36px] font-bold text-slate-800 dark:text-gray-300 lg:text-[30px] mb-3">Navigateur insupportable.</h1>
                    <p>Nous avons remarqué que vous utilisez un navigateur insupportable.</p>
                    <p>Pour une expérience optimale, nous vous recommandons d'utiliser un navigateur tel que Chrome ou Firefox.</p>

                </div>
            </div>
        )
        console.log(navigator.userAgent)
    }
    else if (isLoading) {
        content = (
            <div className="flex items-center justify-center bg-white dark:bg-black text-black dark:text-white  h-[calc(100vh-64px)]">
                <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 
                                border-solid border-current border-r-transparent -mt-1.5 animate-spin-slow"></div>
            </div>
        )
    } else if (isError) {
        console.log("error:", error?.data?.message)
        content = <Navigate to="/login" state={{ from_: location }} replace />
    } else if (isSuccess && trueSuccess) {
        content = <Outlet />
    } else if (token && isUninitialized) {
        content = <Outlet />
    }

    return content
}

export default PersistLogin
