import { Outlet } from "react-router-dom"
import useAuth from "./useAuth"
import { BiError } from "react-icons/bi"

const RequireAuth = () => {
    // const location = useLocation()
    const { isAdmin } = useAuth()

    const content = (
        isAdmin
            ? <Outlet />
            : <section className=" h-full grow flex items-center sm:p-16 text-gray-600 bg-white dark:bg-black dark:text-white">
                <div className="container flex flex-col items-center justify-center px-5 mx-auto text-center sm:max-w-md">
                    <BiError
                        className="w-40 h-40 text-gray-300 dark:text-gray-600 "
                    />

                    <p className="text-3xl">
                        Vous n'êtes pas autorisé à accéder à cette page
                    </p>

                </div>
            </section>
    )

    return content
}
export default RequireAuth