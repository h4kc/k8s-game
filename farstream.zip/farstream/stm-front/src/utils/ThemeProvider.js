import React, { useEffect } from 'react';
import { useSelector } from 'react-redux';

const ThemeProvider = ({ children }) => {
  const currentTheme = useSelector(state => state.ui.theme);

  useEffect(() => {
    const rootElement = document.getElementById('root');
    updateThemeClass(currentTheme, rootElement);
  }, [currentTheme]);

  const updateThemeClass = (theme, element) => {
    if (theme === 'dark') {
      element.classList.add('dark');
    } else {
      element.classList.remove('dark');
    }
  };

  return (
    <>
      {children}
    </>
  );
};

export default ThemeProvider;
