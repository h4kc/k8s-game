import React, { useState, useEffect } from 'react'
// import ReactPlayer from "react-player"
import { CgMoveRight, CgOptions } from "react-icons/cg"
import { BsRecord2 } from "react-icons/bs"
import Dropdown from "../shared/Dropdown"
import VideoInfo from './VideoInfo'
import { useUpdateRecordingStatusMutation } from '../store/slices/streamApiSlice'
import useAuth from '../utils/useAuth'
import { AiOutlineFullscreen, AiOutlineStop } from 'react-icons/ai'
// import { TbBroadcastOff, TbBroadcast } from "react-icons/tb"
import { useDispatch } from 'react-redux'
import { openErrorAlert, openSuccessAlert, setAlertMsg } from '../store/slices/uiSlice'


const VideoPlayer = ({ video, videoCount, deleteFromGrid, setGridToOneStream, handleBroadcast, broadcastLoading }) => {

    const { isRecorder } = useAuth()
    const [updateRecordingStatus,
        { isLoading: recordLoading }
    ] = useUpdateRecordingStatusMutation()

    const dispatch = useDispatch()

    const [dropdownIsOpen, setDropdownIsOpen] = useState()
    const [recordStatus, setRecordStatus] = useState(video?.mp4Enabled === 1)
    const [mouseInsidePlayer, setMouseInsidePlayer] = useState()
    const [isAllShown, setIsAllShown] = useState(false)

    const handleRecordClick = async (id, recordingStatus) => {
        try {
            dispatch(setAlertMsg(`la sauvegarde va ${recordingStatus ? "se lancer" : "s'arrêter"} dans quelque secondes.`))
            dispatch(openSuccessAlert())
            setDropdownIsOpen()
            const response = await updateRecordingStatus({ id, recordingStatus })
            if (response.data?.success) {
                setRecordStatus(perv => !perv)
                console.log(response)
            } else {
                console.log(response.data?.message)
                dispatch(setAlertMsg(`Erreur lors  ${recordingStatus ? "du lancement" : "de l'arrêt"} de la sauvegarde.`))
                dispatch(openErrorAlert())
            }

        } catch (err) {
            console.error(err)
        }
    }

    // const handleBroadcastClick = (id) => {
    //     handleBroadcast(id, video?.status)
    //     setDropdownIsOpen()
    // }

    const handleDelete = () => {
        deleteFromGrid(video)
    }

    const handleOneStreamInGrid = () => {
        setGridToOneStream(video)
    }

    const handleMouseInOut = (id) => {
        setMouseInsidePlayer(id)
        if (dropdownIsOpen && id !== "allShown") {
            setDropdownIsOpen()
        }
    }

    const handleDropClick = (id) => {
        if (dropdownIsOpen) setDropdownIsOpen()
        else setDropdownIsOpen(id)
    }

    useEffect(() => {
        const handleKeyDown = (event) => {
            if (event.key === 'i') {
                event.preventDefault()
                setIsAllShown(true)
            }
        }
        const handleKeyUp = (event) => {
            if (event.key === 'i') {
                setIsAllShown(false)
            }
        }

        document.addEventListener('keydown', handleKeyDown)
        document.addEventListener('keyup', handleKeyUp)

        return () => {
            document.removeEventListener('keydown', handleKeyDown)
            document.removeEventListener('keyup', handleKeyUp)
        }
        // eslint-disable-next-line
    }, [])


    // useEffect(() => {
    //     console.log(mouseInsidePlayer)
    // }, [mouseInsidePlayer])


    return (

        <div
            onMouseEnter={() => handleMouseInOut(video?.streamId)}
            onMouseLeave={() => handleMouseInOut()}
            className="relative w-full py-[3px] px-[3px] rounded-md shadow-md overflow-hidden"
        >
            {video && (
                <>
                    <>
                        {/* if we want ro control broadcast start/stop */}
                        {/* {(videoCount > 1 || video?.protocol === "RTSP") && */}
                        {((videoCount > 1) || (video?.status === "broadcasting")) &&
                            (<div
                                title='Options'
                                onClick={() => handleDropClick(video?.streamId)}
                                className={`absolute z-30 top-2 right-2 p-1 ${(mouseInsidePlayer !== video?.streamId && !isAllShown) && 'hidden'}
                            text-white shadow-md shadow-purple-300 cursor-pointer rounded-md text-[17px]`
                                }
                                style={{
                                    backdropFilter: "blur(20px)", // Adjust the blur intensity as needed
                                    backgroundColor: "rgba(0, 0, 0, 0.4)" // Adjust background color and opacity
                                }}
                            >
                                <CgOptions />
                            </div>)}

                        {dropdownIsOpen === video?.streamId && (
                            <Dropdown
                                items={[
                                    ...(videoCount > 1
                                        ? [
                                            { value: "Supprimer de la grille", action: handleDelete, icon: <CgMoveRight /> },
                                            { value: "Occuper la grille", action: handleOneStreamInGrid, icon: <AiOutlineFullscreen /> }
                                        ]
                                        : []
                                    ),

                                    isRecorder && (video?.status === "broadcasting")
                                        ? {
                                            value: recordLoading ? "Requête Envoyée..." : recordStatus ? "Arrêter la Sauvegarde" : "Sauvegarder",
                                            action: recordLoading ? null : () => handleRecordClick(video.streamId, !recordStatus),
                                            icon: recordStatus ? <AiOutlineStop /> : <BsRecord2 />
                                        }
                                        : null,

                                    // isAdmin && (video?.protocol === "RTSP")
                                    //     ? {
                                    //         value: (video?.status === "broadcasting") ? "Arrêter le Broadcast" : broadcastLoading ? "Requête Envoyée..." : "Commencer le Broadcast",
                                    //         action: broadcastLoading ? null : () => handleBroadcastClick(video.streamId),
                                    //         icon: video?.status === "broadcasting" ? <TbBroadcastOff /> : <TbBroadcast />
                                    //     }
                                    //     : null
                                ].filter(item => item !== null)}
                            />
                        )}
                    </>

                    <VideoInfo
                        video={video}
                        title={video?.name}
                        duration={video?.startTime}
                        viewers={video?.hlsViewerCount}
                        record={recordStatus}
                        mouseInsidePlayer={mouseInsidePlayer}
                        isAllShown={isAllShown} />

                    <div className="rounded-md h-full overflow-hidden">
                        <iframe
                            className='overflow-hidden'
                            title={`${video?.name}`}
                            width="100%"
                            height="100%"
                            src={`${process.env.REACT_APP_AMS_URL}/WebRTCApp/play.html?id=${video?.streamId}`}
                        ></iframe>
                    </div>
                </>)
            }
        </div >
    )
}

export default VideoPlayer
