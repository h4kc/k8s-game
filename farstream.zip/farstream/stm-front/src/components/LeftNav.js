import React, { useState, useRef, useEffect, useCallback, Fragment } from "react"
import { useNavigate, useLocation } from "react-router-dom"
import { useSelector, useDispatch } from 'react-redux'

import { categories } from "../utils/constants"

import { FaUser } from "react-icons/fa"
import { RiUserSettingsLine } from "react-icons/ri"
import { BiDotsHorizontal, BiLogOut } from "react-icons/bi"

import LeftNavMenuItem from "./LeftNavMenuItem"
import Logo from "../shared/Logo"
import { useSendLogoutMutation } from "../store/slices/authApiSlice"
import useAuth from "../utils/useAuth"
import Dropdown from "../shared/Dropdown"
import { closeLeftNav, openOptions } from "../store/slices/uiSlice"


const LeftNav = () => {
  const { username, isAdmin } = useAuth()
  const isLeftNavOpen = useSelector((state) => state.ui.leftNav)

  const [dropdownIsOpen, setDropdownIsOpen] = useState(false)

  const { pathname } = useLocation()
  const isStreamPage = pathname === "/stream"
  const isLoginPage = pathname === "/login"

  const dispatch = useDispatch()
  const navigate = useNavigate()
  const LeftNavRefElement = useRef()
  const dropdownElmt = useRef()
  const [selectedCategory, setSelectedCategory] = useState(pathname === '/' ? "/sources" : pathname)

  const [sendLogout, {
    isSuccess,
    isLoading : logoutLoading,
    isError,
    error
  }] = useSendLogoutMutation()


  const CloseLeftNavAndDropDown = useCallback((event) => {

    const isOutsideLeftNavClick = !LeftNavRefElement?.current?.contains(event.target)
    const isOutsideDropdownClick = !dropdownElmt?.current?.contains(event.target)
    if (isOutsideLeftNavClick && isLeftNavOpen) {
      dispatch(closeLeftNav())
    }
    if (isOutsideDropdownClick && dropdownIsOpen) {
      setDropdownIsOpen(false)
    }

    //eslint-disable-next-line
  }, [isLeftNavOpen, dropdownIsOpen])

  useEffect(() => {

    if (isSuccess) {
      navigate('/login')
    }

    if (isError) console.log(error)
    document.addEventListener('click', CloseLeftNavAndDropDown)

    // console.log(pathname)

    return () => {
      document.removeEventListener('click', CloseLeftNavAndDropDown)
    }

    //eslint-disable-next-line
  }, [isSuccess, isError, error, CloseLeftNavAndDropDown])

  const clickHandler = (type) => {
    if (type !== "option") {
      setSelectedCategory(type)
    }
  }

  const goToUsersPage = () => {
    navigate('/users')
    setDropdownIsOpen(false)
  }

  const logOutAction = () => {
    localStorage.removeItem('refreshTo')
    sendLogout()
  }

  const toggleDropDown = (event) => {
    event.stopPropagation()
    setDropdownIsOpen(perv => !perv)
  }

  const handleOpenOptions = (event) => {
    event.stopPropagation()
    dispatch(openOptions())
  }

  return (
    <div
      ref={LeftNavRefElement}
      className={`w-[240px] fixed bg-white py-4 dark:bg-black transition-transform 
                  overflow-y-auto z-9 shadow-md dark:shadow-gray-300 no-scrollbar
        ${isStreamPage ? "!z-50 left-0 top-0 h-screen !bg-[#F1F3F5] dark:!bg-[#000000fc] w-[260px]" : "md:translate-x-0 h-full"} 
        ${isLeftNavOpen ? "translate-x-0" : "translate-x-[-240px] !w-[240px]"} `}
    >
      <div className="mt-[2px] ml-[8px]">
        {isStreamPage && <Logo
          isLoginPage={isLoginPage}
          isStreamPage={isStreamPage}
          leftNav={true}
        />}
      </div>

      <div className={`flex px-3 flex-col justify-between ${isStreamPage ? 'h-full':'h-[calc(100%-64px)]'} pt-5`}>
        <div>
        {categories
          .filter((item) => !((item.name === 'Historique') && !isAdmin))
          .map((item) => {
            const isSelected = selectedCategory.startsWith(item.type)
            return (
              <Fragment key={item.type}>
                <LeftNavMenuItem
                  text={item.name}
                  icon={item.icon}
                  action={(event) => {
                    clickHandler(item.type)
                    item.type !== "option" ? navigate(`${item.type}`) : handleOpenOptions(event)
                  }}
                  isSelected={isSelected}
                />
                {(item.divider || (item.spliter && !isAdmin)) && (
                  <hr className="my-5 border-black/[0.2] border dark:border dark:border-white/[0.2]" />
                )}
              </Fragment>
            )
          })}
          </div>
        <div
          className={`flex items-center mt-auto h-10 px-3 text-black dark:text-white text-sm 
                      rounded-lg hover:bg-black/[0.15] dark:hover:bg-white/[0.15] cursor-pointer
                      ${dropdownIsOpen && "bg-black/[0.15] dark:bg-white/[0.15]"}`}
          onClick={toggleDropDown}>
          <span className="text-[18px] mr-3"><FaUser /></span>
          <div className="flex items-center flex-grow justify-between ">
            <span>{username}</span>
            <span className="text-lg"><BiDotsHorizontal /></span>
          </div>
        </div>

        {dropdownIsOpen && (
          <Dropdown
            isStreamPage={isStreamPage}
            refelmt={dropdownElmt}
            leftnav={true}
            light={true}
            items={[
              isAdmin ? { value: "Gestion des utilisateurs", action: goToUsersPage, icon: <RiUserSettingsLine /> } : null,
              { value: `Déconnection`, action: logOutAction, icon: <BiLogOut />, loading: logoutLoading }
            ].filter(item => item !== null)}
          />
        )}

      </div>
    </div>
  )
}

export default LeftNav
