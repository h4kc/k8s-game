import React from "react"


import { GoBroadcast } from "react-icons/go"
import { AiOutlinePlus } from "react-icons/ai"


const SuggestionVideoCard = ({ video, addAction }) => {

  const handleAddVideo = () => {
    addAction(video)
  }

  function formatTime(Time) {
    const date = new Date(Time)
    const currentDate = new Date()
    const timeDifference = (currentDate.getTime() - date.getTime()) / 1000

    const startDuration = Math.floor(timeDifference)
    if (!startDuration) {
      return "NaN"
    }
    const hours = Math.floor(startDuration / 3600)
    const minutes = Math.floor((startDuration % 3600) / 60)
    const seconds = startDuration % 60

    let timeString = ""

    if (hours > 24) {
      return "--pas d'info--"
    }

    if (hours > 0) {
      timeString += `${hours}h `
    }

    if (minutes > 0 || hours > 0) {
      timeString += `${minutes}m `
    }
    if (minutes < 1) {
      timeString += `${seconds}s `
    }

    return timeString.trim()
  }


  return (

    <div className="flex relative mb-4">
      <div className="flex items-center justify-center relative h-28 w-36 bg-gray-300 dark:bg-gray-500 rounded-xl overflow-hidden">
        <GoBroadcast className="text-7xl text-gray-500 dark:text-gray-300" />
      </div>

      <div className="flex flex-grow text-black dark:text-white">
        <div className="w-[80%] flex flex-col ml-3 overflow-hidden">
          <span className="text-[15px] font-bold line-clamp-2 my-2">
            {` Source : ${video.name}`}
          </span>
          <div className="flex text-[13px] font-semibold text-black/[0.8] dark:text-white/[0.7] truncate 
                          overflow-hidden">

            {video.status === "broadcasting"
              ?
              <div className="flex flex-col">
                <span>{`Actif depuis  ${formatTime(video.startTime)}`}</span>
                {video.mp4Enabled === 1 && <span>{`Sauvegarde en cours`}</span>}
              </div>
              :
              <span>{`Stream en arret`}</span>
            }

          </div>
        </div>
      </div>

      <div>
        <div
          title="Ajouter a la grille"
          onClick={handleAddVideo}
          className={`absolute top-1 right-1 p-1 text-black dark:text-white shadow-md shadow-purple-300 cursor-pointer rounded-md`}>
          <AiOutlinePlus />
        </div>
      </div>

    </div>

  )
}

export default SuggestionVideoCard
