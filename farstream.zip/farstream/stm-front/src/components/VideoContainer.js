
import React from "react";
import VideoPlayer from "./VideoPlayer";

const VideoContainer = ({ videoCount, videosInGrid, deleteFromGrid, setGridToOneStream, handleBroadcast, broadcastLoading }) => {
  // Calculate the number of rows and columns based on videoCount

  const numCols = Math.ceil(Math.sqrt(videoCount));
  const numRows = Math.ceil(videoCount / numCols);

  // Generate the grid template areas
  const gridTemplateAreas = [];
  for (let row = 0; row < numRows; row++) {
    const rowAreas = [];
    for (let col = 0; col < numCols; col++) {
      const area = `part${col * numRows + row + 1}`;
      rowAreas.push(area);
    }
    gridTemplateAreas.push(`"${rowAreas.join(" ")}"`);
  }

  return (
    <div
      className="video-container w-full h-full bg-slate-400/[0.4] rounded-md"
      style={{
        display: "grid",
        gridTemplateColumns: `repeat(${numCols}, 1fr)`,
        gridTemplateRows: `repeat(${numRows}, 1fr)`,
        gridTemplateAreas: gridTemplateAreas.join(" "),
      }}
    >

      {videosInGrid?.map((video, index) => (
        <VideoPlayer
          key={video ? video.streamId : `fallback_${index}`}
          video={video}
          videoCount={videoCount}
          deleteFromGrid={deleteFromGrid}
          setGridToOneStream={setGridToOneStream}
          // if we want ro control broadcast start/stop
          // handleBroadcast={handleBroadcast}
          // broadcastLoading={broadcastLoading}
          style={{ gridArea: `part${index + 1}` }}
        />
      ))}
    </div>
  );
}


export default VideoContainer;
