import React from "react"

import { BsHddNetwork, BsInfoCircle, BsRecordCircle } from "react-icons/bs"
import { IoIosTimer } from "react-icons/io"
// import { FaEye } from "react-icons/fa"
// import { abbreviateNumber } from "js-abbreviation-number"

const VideoInfo = ({ video, title, viewers, duration, record, mouseInsidePlayer, isAllShown }) => {

    function formatTime(Time) {
        const date = new Date(Time)
        const currentDate = new Date()
        const timeDifference = (currentDate.getTime() - date.getTime()) / 1000

        const startDuration = Math.floor(timeDifference)
        if (!startDuration) {
            return "NaN"
        }
        const hours = Math.floor(startDuration / 3600)
        const minutes = Math.floor((startDuration % 3600) / 60)
        const seconds = startDuration % 60

        let timeString = ""

        if (hours > 24) {
            return "--pas d'info--"
        }

        if (hours > 0) {
            timeString += `${hours}h `
        }

        if (minutes > 0 || hours > 0) {
            timeString += `${minutes}m `
        }
        if (minutes < 1) {
            timeString += `${seconds}s `
        }

        return timeString.trim()
    }

    return (
        <>
            {(mouseInsidePlayer === video?.streamId || isAllShown) &&
                <div className="absolute top-1 left-1 right-1 py-1 z-[25] flex flex-col text-white rounded-md text-[13px]"
                    style={{
                        backdropFilter: "blur(20px)",
                        backgroundColor: "rgba(0, 0, 0, 0.4)"
                    }}>

                    <div className="flex items-center my-1">
                        {record
                            ? <BsRecordCircle className="text-[17px] text-[#ff0707] animate-pulse ml-2 mr-2" />
                            : <BsInfoCircle className='text-[18px] text-white  ml-2 mr-2' />}
                        <span>{`${record ? "Sauvegarde en cours" : ""}`}</span>
                    </div>

                    <div className={`flex items-center mb-1`}>
                        <BsHddNetwork className="text-[19px] ml-2 mr-2" />
                        <span>{`Source :  ${title}`}</span>
                    </div>

                    {(video?.status === "broadcasting") && <div className="flex items-center mb-1">
                        <IoIosTimer className="text-[19px] ml-2 mr-2" />
                        <span >{`Actif depuis ${formatTime(duration)}`}</span>
                    </div>
                    }
                    {/* <div className="flex items-center mb-1">
                    <FaEye className="text-[19px] ml-2 mr-2" />
                    <span>{`${abbreviateNumber(
                        viewers,
                        2
                    )} Spectateurs`}</span>
                </div> */}
                </div>}
        </>
    )
}

export default VideoInfo
