import React from "react"
// import { abbreviateNumber } from "js-abbreviation-number"
// import { BsFillCheckCircleFill } from "react-icons/bs"

import VideoLength from "../shared/VideoLength"
import { BiSolidVideos } from "react-icons/bi"
import { CgOptions } from "react-icons/cg"
import { useState } from "react"
import { useRef } from "react"
import { useEffect } from "react"
import Dropdown from "../shared/Dropdown"
import { RiDeleteBinLine } from "react-icons/ri"
import { IoIosLink } from "react-icons/io"
import useAuth from "../utils/useAuth"
import { openDeleteConfimation } from "../store/slices/uiSlice"
import { useDispatch } from "react-redux"
// import { CiEdit } from "react-icons/ci"

const VideoCard = ({ video, setVideoPath, toggleVideoPlayer, togglePanel, setSelectedVod, isPlaylistSource, matchingSource }) => {

  const [dropdownIsOpen, setDropdownIsOpen] = useState(false)
  const dropDownElement = useRef()
  const { isAdmin } = useAuth()
  const dispatch = useDispatch()

  useEffect(() => {
    const closeDropDown = (event) => {
      const isOutsideDropDownClick = !dropDownElement?.current?.contains(event.target)
      if (isOutsideDropDownClick && dropdownIsOpen) {
        setDropdownIsOpen(false)
      }
    }
    document.addEventListener('click', closeDropDown)
    // console.log(video)
    return () => {
      document.removeEventListener('click', closeDropDown)
    }
  }, [dropdownIsOpen])

  const toggleDropDown = (e) => {
    setDropdownIsOpen(prev => !prev)
  }

  const handlePlayButton = () => {
    if (video.filePath && video.filePath.trim() !== '') {
      setVideoPath(video.filePath)
      toggleVideoPlayer()
    }
  }

  const handleDeleteClick = () => {
    setDropdownIsOpen(false)
    setSelectedVod(video)
    dispatch(openDeleteConfimation())
  }

  const handleAssociate = () => {
    setDropdownIsOpen(false)
    togglePanel(video.vodId)
  }


  return (
    <div className="flex flex-col mb-8">
      <div className="relative flex items-center justify-center h-48 md:h-40 md:rounded-xl overflow-hidden dark:bg-slate-500/[0.4] bg-slate-500/[0.2]">
        <div ref={dropDownElement}>
          {isAdmin &&
            (<>
              <div
                onClick={toggleDropDown}
                className={`absolute z-30 top-2 right-1 p-1 text-white cursor-pointer rounded-md text-[17px] bg-black bg-opacity-40`
                }
              >
                <CgOptions />
              </div>
              {dropdownIsOpen && (
                <Dropdown
                  items={[
                    { value: "Supprimer", action: handleDeleteClick, icon: <RiDeleteBinLine /> },
                    (!video.sourceId && !isPlaylistSource)
                      ? { value: "Associer a une source", action: handleAssociate, icon: <IoIosLink /> }
                      : null,
                    // { value: "Ajouter une marque", action: null, icon: <CiEdit /> }
                  ].filter(item => item !== null)}
                  light={true}
                  PlaylistItem={true}
                />
              )}
            </>)
          }
        </div>
        <BiSolidVideos
          onClick={handlePlayButton}
          className="text-7xl text-gray-500 dark:text-gray-400 hover:text-gray-800 hover:dark:text-gray-100 hover:cursor-pointer" />
        <VideoLength time={video.duration} />
      </div>

      <div className="flex mt-3">

        <div className="flex flex-col ml-2">
          <span className="text-sm text-black dark:text-white">
            {video.creationDate}
          </span>
          {!isPlaylistSource &&
            <span className={`text-sm   ${matchingSource ? "font-bold text-green-400 dark:text-green-500" : "text-black dark:text-white"} `}>
              {`Source: ${video.streamName}`}
            </span>}
        </div>
      </div>
    </div>
  )
}

export default VideoCard
