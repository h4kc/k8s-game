import React from "react"
import { useLocation } from "react-router-dom"

import { useSelector } from 'react-redux'



import Logo from "../shared/Logo"


const Header = () => {

  const isWideView = useSelector((state) => state.ui.wideView)
  const { pathname } = useLocation()
  const isLoginPage = pathname === "/login"
  const isStreamPage = pathname === "/stream"
  const wideViewVerify = isStreamPage && isWideView

  return (
    <div className={`header h-16 !z-40 bg-[#F1F3F5] dark:bg-[#000000fc] transition-[height] duration-300 sticky top-0
      ${wideViewVerify ? "!h-0" : ""} 
      `}>
      {!isWideView &&
        <div className={`flex flex-row h-full shadow-md dark:shadow-gray-600
        ${isStreamPage ? "pl-2 pr-4" : "px-4 md:px-5"} 
        justify-between items-center 
        `}>

          <Logo
            isLoginPage={isLoginPage}
            isStreamPage={isStreamPage}
          />

        </div>}
    </div>
  )
}

export default Header
