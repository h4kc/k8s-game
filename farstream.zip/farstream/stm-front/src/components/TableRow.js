import React from 'react'
import { CiEdit } from 'react-icons/ci'
import { RiDeleteBinLine } from 'react-icons/ri'
import { useState } from 'react'
import { IoIosLink } from 'react-icons/io'
import { IoPlayOutline } from 'react-icons/io5'

const TableRow = ({ data, object, userPage, vodPage, isAdmin, handleUpdate, handleDelete, handlePlayButton, matchingSource, isPlaylistSource }) => {
  const [showMore, setShowMore] = useState(false)
  const handleShowMore = () => {
    setShowMore(perv => !perv)
  }
  return (
    <tr className="bg-gray-100 dark:bg-gray-700 text-center">
      {data.map((item, index) => {
        return (
          (<td key={index} className={`p-3`}>
            {!item && '---'}
            {userPage && index === 3
              ? object.role === "admin"
                ? "Toute source"
                : showMore
                  ? item
                  : item.length > 3
                    ? <>
                      {item[0]} {item[1]}
                    </>
                    : <>
                      {item[0]} {item[1]} {item[2]}
                    </>
              : item
            }
            {index === 3 && userPage && item.length > 3 && object.role !== "admin" &&
              <span className="text-blue-500 cursor-pointer" onClick={handleShowMore}>
                {showMore ? 'Afficher moins' : 'Afficher tout'}
              </span>
            }
          </td>))
      }
      )}
      {isAdmin
        ? (<td className="p-3">
          <div className={`flex items-center justify-center ${userPage ? "text-[25px]" : "text-[20px]"} `}>
            {vodPage
              ?
              <>
                {!isPlaylistSource && (<div
                  onClick={() => !matchingSource && handleUpdate(object)}
                  className={`mx-2 ${!matchingSource ? 'dark:hover:text-gray-100 hover:text-gray-400 text-yellow-500 cursor-pointer' : 'text-transparent'}`}>
                  <IoIosLink />
                </div>)}
                <div
                  onClick={() => { handlePlayButton(object) }}
                  className='text-green-500 font-bold text-[17px] dark:hover:text-gray-100 hover:text-gray-400 mx-1 cursor-pointer p-1'>
                  <IoPlayOutline />
                </div>
              </>
              :
              <div
                onClick={() => handleUpdate(object)}
                className="dark:hover:text-gray-100 hover:text-gray-400 mx-1 text-blue-600 dark:text-blue-400 cursor-pointer">
                <CiEdit />
              </div>}
              <div
                onClick={() => handleDelete(object)}
                className="dark:hover:text-gray-100 hover:text-gray-400 mx-1 text-red-600 dark:text-red-500 cursor-pointer">
                {object.role !== 'admin' && <RiDeleteBinLine />}
              </div>
          </div>
        </td>
        )
        : (vodPage &&
          <td className="p-3">
            <div className={`flex items-center justify-center text-[20px]`}>
              <div
                onClick={() => { handlePlayButton(object) }}
                className='text-green-500 font-bold text-[17px] dark:hover:text-gray-100 hover:text-gray-400 mx-1 cursor-pointer p-1'>
                <IoPlayOutline />
              </div>
            </div>
          </td>)
      }
    </tr>
  )
}

export default TableRow
