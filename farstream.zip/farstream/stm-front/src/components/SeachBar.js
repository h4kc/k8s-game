import React, { useEffect, useState } from "react";

import { CgClose } from "react-icons/cg";


const SearchBar = ({ setIsSearchVisible, items, setFilteredItems, vodPage }) => {
    const [searchQuery, setSearchQuery] = useState("")

    let filteredItems
    if (vodPage) {
        filteredItems = items?.filter((item) =>
            item.creationDate.toLowerCase().includes(searchQuery.toLowerCase()) ||
            item.streamName.toLowerCase().includes(searchQuery.toLowerCase())
        )
    } else {
        filteredItems = items?.filter((item) =>
            item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
            item.streamUrl.toLowerCase().includes(searchQuery.toLowerCase()) ||
            item.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
            item.position.toLowerCase().includes(searchQuery.toLowerCase()) ||
            item.creationDate.toLowerCase().includes(searchQuery.toLowerCase())
        )
    }
    useEffect(() => {
        setFilteredItems(filteredItems)
        //eslint-disable-next-line
    }, [searchQuery])

    return (
        <div className={`grow flex items-center ${vodPage ? "mr-3" : "mt-3"}`}>

            <label
                className="mx-auto h-8 md:h-11 relative bg-transparent w-full text-gray-600 dark:text-gray-300 flex flex-col md:flex-row items-center justify-center border border-gray-400 dark:border-gray-400 py-2 px-2 rounded-2xl gap-2 focus-within:border-blue-500 ">
                <input
                    autoComplete="off"
                    name="searchBar"
                    type="text"
                    placeholder="Recherche"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="px-6 pl-4 w-full rounded-md flex-1 border-0 focus:ring-0 outline-none bg-transparent text-black dark:text-white"
                />
                <button
                    onClick={() => { setIsSearchVisible(false) }}
                    className={`w-full md:w-auto px-2 py-1 bg-transparent text-gray-600 dark:text-gray-300 active:scale-90 duration-100 
                                will-change-transform overflow-hidden relative`}>
                    <div className="relative">
                        <div className="flex items-center opacity-1">
                            <span
                                className="text-lg font-semibold whitespace-nowrap truncate mx-auto">
                                <CgClose />
                            </span>
                        </div>
                    </div>

                </button>
            </label>
        </div>
    );
};

export default SearchBar;

