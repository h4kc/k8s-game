import React, { useEffect, useRef } from 'react'

import { useDispatch } from 'react-redux'
import useAuth from '../utils/useAuth'

import TableRow from './TableRow'
// import { BsListCheck } from 'react-icons/bs'
// import { Link } from 'react-router-dom'
import { openPanel, openDeleteConfimation, setUpdateMode } from '../store/slices/uiSlice'
import moment from 'moment'

const Table = ({ userPage,
    vodPage,
    isPlaylistSource,
    items,
    setItemToUpdate,
    setItemToDelete,
    setVideoPath,
    toggleVideoPlayer,
    togglePanel,
    isSelectionAlloued,
    checkedItems,
    toggleCheck,
    handleAllCheck }) => {

    const dispatch = useDispatch()
    const { isAdmin } = useAuth()

    const handleDelete = (item) => {
        setItemToDelete(item)
        dispatch(openDeleteConfimation())
    }

    const handleUpdate = (item) => {
        setItemToUpdate(item)
        dispatch(setUpdateMode())
        dispatch(openPanel())
    }

    const handleAssociate = (item) => {
        togglePanel(item.vodId)
    }

    const handlePlayButton = (item) => {
        if (item.filePath && item.filePath.trim() !== '') {
            setVideoPath(item.filePath)
            toggleVideoPlayer()
        }
    }

    const TableHeader = ({ headers, isAdmin }) => (
        <tr className="bg-purple-200 dark:bg-[#aefc] text-gray-800 dark:text-black ">
            {headers.map((header, index) => {

                if (!header) {
                    return null;
                }
                if ((header === "Actions" || header === "Protocole de stream" || header === "Lien/ID de stream") && !isAdmin) {
                    return null // Skip rendering "Actions , Protocole de stream, Lien/ID de stream" if user is not admin
                }
                if (header === "Lecture" && isAdmin) {
                    return null // Skip rendering "Lecture" if user is admin
                }

                return (
                    <th
                        key={index}
                        className={`p-5 ${header === "Nom de l'utilisateur" && "w-[15%]"} 
                                  ${header === "Actions" && userPage && "w-[10%]"}`}
                    >
                        {header}
                    </th>
                )
            })}
        </tr>
    )

    const CheckBox = ({ itemId, handleChange, isChecked, isSomeSelected }) => {
        const checkboxRef = useRef(null)

        // Effect to update the indeterminate state of the checkbox, isSomeSelected is a prop of main check box only
        useEffect(() => {
            if (checkboxRef.current) {
                if (isSomeSelected && !isChecked) checkboxRef.current.indeterminate = true
            }
            // eslint-disable-next-line
        }, [])

        return (
            <input
                ref={checkboxRef}
                className="w-4 h-4 focus:outline-none focus:ring-0 cursor-pointer dark:focus:outline-none"
                id={itemId}
                type="checkbox"
                checked={isChecked}
                onChange={handleChange}
            />
        )
    }

    return (
        <div className="flex w-full items-center justify-center overflow-hidden">
            {(!items)
                ? (<div className='p-3 pl-10 inline-block text-lg mt-8'>Pas d'informations disponibles pour le moment.</div>)
                : !(items.length > 0)
                    ? (<div className='p-3 pl-10 inline-block text-lg mt-8'>Pas de Ressource</div>)
                    : (<table className={`w-full table text-black dark:text-gray-100  border border-gray-400 dark:border-gray-400 rounded-lg border-separate space-y-6 text-sm`}>
                        <thead className="bg-purple-500 dark:bg-purple-900 text-gray-800 dark:text-gray-100">
                            {userPage
                                ?
                                <TableHeader headers={['Nom de l\'utilisateur', 'Description', 'Role', 'Sources allouées', 'Actions']} isAdmin={isAdmin} />
                                :
                                vodPage
                                    ?
                                    <TableHeader headers={
                                        [(isSelectionAlloued && <CheckBox
                                            itemId={'header'}
                                            handleChange={handleAllCheck}
                                            // all checkboxes are checked
                                            isChecked={Object.values(checkedItems).every(Boolean)}
                                            // at least one checkbox is unchecked
                                            isSomeSelected={Object.values(checkedItems).some(value => value)}
                                        />),
                                            'Date de la sauvgarde',
                                            'Duration',
                                            'Nom de la source',
                                            'Actions',
                                            'Lecture' //for normal users
                                        ]} isAdmin={isAdmin} />
                                    :
                                    <TableHeader headers={[
                                        'Nom de la source',
                                        'Protocole de stream',
                                        'Lien/ID de stream',
                                        'Description',
                                        'Position',
                                        'Date de création',
                                        'Actions']} isAdmin={isAdmin} />
                            }
                        </thead>
                        <tbody>
                            {userPage
                                ? (
                                    items?.map((item) => {
                                        const sourceNames = item.sources.map((source) => (
                                            <div key={source.id} className='mb-1'>{source.name}</div>
                                        ))
                                        const role = item.isRecorder ? 'recorder' : item.role
                                        return (
                                            <TableRow
                                                key={item.id}
                                                object={item}
                                                data={[item.username, item.observation, role, sourceNames]}
                                                isAdmin={isAdmin}
                                                handleUpdate={handleUpdate}
                                                handleDelete={handleDelete}
                                                userPage={userPage}
                                            />
                                        )
                                    })
                                ) :
                                vodPage
                                    ?
                                    (
                                        items?.map((item) => {
                                            //if theres a sourceID attribute it means the vod has a matching source
                                            const matchingSource = item.sourceId
                                            // Determine the content and styling for the source depending if vod is associated and if we are in source playlist page
                                            const sourceName = (
                                                <div
                                                    className={`justify-center inline-block px-2 
                                                    ${matchingSource && 'bg-green-600 dark:bg-green-400 text-white dark:text-black'} rounded-md`}
                                                >
                                                    {item.streamName}
                                                </div>
                                            );
                                            const duration = moment().startOf("day").milliseconds(item.duration).format("H:mm:ss")
                                            return (
                                                <TableRow
                                                    key={item.vodId}
                                                    object={item}
                                                    data={
                                                        isSelectionAlloued
                                                            ? [
                                                                <CheckBox
                                                                    key="checkbox"
                                                                    itemId={item.vodId}
                                                                    handleChange={() => { toggleCheck(item.vodId) }}
                                                                    isChecked={!!checkedItems[item.vodId]}
                                                                />,
                                                                item.creationDate,
                                                                duration,
                                                                sourceName
                                                            ]
                                                            : [item.creationDate, duration, sourceName]
                                                    }
                                                    isAdmin={isAdmin}
                                                    handleUpdate={handleAssociate}
                                                    handleDelete={handleDelete}
                                                    handlePlayButton={handlePlayButton}
                                                    vodPage={vodPage}
                                                    isPlaylistSource={isPlaylistSource}
                                                    matchingSource={matchingSource}
                                                />
                                            )
                                        })
                                    ) : (
                                        items?.map((item) => {
                                            return (
                                                <TableRow
                                                    key={item.id}
                                                    object={item}
                                                    //i used 'toBeRemoved' because null might be as info in database
                                                    data={[
                                                        item.name,
                                                        isAdmin ? item.protocol : 'toBeRemoved',
                                                        isAdmin ? ((item.protocol === 'RTSP') ? item.streamUrl : item.streamId) : 'toBeRemoved',
                                                        item.description,
                                                        item.position,
                                                        item.creationDate
                                                    ].filter(item => item !== 'toBeRemoved')}
                                                    isAdmin={isAdmin}
                                                    handleUpdate={handleUpdate}
                                                    handleDelete={handleDelete}
                                                />
                                            )
                                        })
                                    )}

                        </tbody>
                    </table>
                    )}
        </div>
    )
}

export default Table
