import React, { useState, useEffect } from 'react'
import { CgClose } from "react-icons/cg"
import { useCreateSourceMutation, useGenerateIdMutation, useGetSourcesQuery, useUpdateSourceMutation } from "../store/slices/sourceApiSlice"
import { useCreateUserMutation, useUpdateUserMutation } from '../store/slices/userApiSlice'
import { useDispatch, useSelector } from 'react-redux'
import { FaEye, FaEyeSlash } from 'react-icons/fa'
import DropdownV2 from '../shared/DropdownV2'
import { BsListCheck } from 'react-icons/bs'
import { IoMdArrowDropdown, IoMdArrowDropup } from 'react-icons/io'
import { BiCheckSquare } from 'react-icons/bi'
import { closePanel, openErrorAlert, openSuccessAlert, setAlertMsg } from '../store/slices/uiSlice'

const Panel = ({ userPage, itemToUpdate, setItemToUpdate }) => {

    const dispatch = useDispatch()
    const isUpdateMode = useSelector(state => state.ui.updateMode)

    const [sourceIds, setSourceIds] = useState({})

    const [isRoleListVisible, setIsRoleListVisible] = useState(false)
    const [isProtocolListVisible, setIsProtocolListVisible] = useState(false)
    const [isSourceListVisible, setIsSourceListVisible] = useState(false)
    const [isPasswordVisible, setIsPasswordVisible] = useState(false)
    const [modifiablePassword, setModifiablePassword] = useState(false)

    const [focusedInput, setFocusedInput] = useState(null)
    const [validationErrors, setValidationErrors] = useState({})

    const handleFocusChange = (inputId, isFocused) => {
        setFocusedInput(isFocused ? inputId : null)
    }

    const { data: allSources, isLoading: getSourcesLoading } = useGetSourcesQuery()
    //user ID genertion for RTMP streams
    const [generateId, { isLoading: generateIdLoading, isSuccess: generateIdSuccess, error: generateIdError, data: generatedId }] = useGenerateIdMutation()

    const [createSource, { isLoading: isCreatingSource, isSuccess: createSourceSuccess, error: createSourceError }] = useCreateSourceMutation()
    const [updateSource, { isLoading: isUpdatingSource, isSuccess: updateSourceSuccess, error: updateSourceError }] = useUpdateSourceMutation()
    const [createUser, { isLoading: isCreatingUser, isSuccess: createUserSuccess, error: createUserError }] = useCreateUserMutation()
    const [updateUser, { isLoading: isUpdatingUser, isSuccess: updateUserSuccess, error: updateUserError }] = useUpdateUserMutation()

    const LoadingFinished = !isCreatingSource && !isUpdatingSource && !isCreatingUser && !isUpdatingUser

    const initialData =
        userPage
            ? { username: '', observation: '', password: '', role: 'viewer', sources: '' }
            : { name: '', protocol: 'RTMP', streamId: '', streamUrl: '', position: '', description: '', creationDate: '' }

    const [panelData, setPanelData] = useState(initialData)

    let panelLabels

    if (userPage) {
        panelLabels = ['Nom de l\'utilisateur', 'Description', 'Role', 'Selectionnez les sources allouées']

        if (modifiablePassword || !isUpdateMode) {
            panelLabels.splice(2, 0, 'Mot de passe')
        }
    } else {
        panelLabels = ['Nom de la source', 'Protocole de stream', 'Position', 'Description', 'Date de creation']

        // insert right label after name
        const insertIndex = panelLabels.indexOf('Protocole de stream') + 1
        if (panelData.protocol === 'RTMP') {
            const costumLabel = isUpdateMode ? 'Identifient de stream' : 'Identifient de stream (doit être unique)'
            panelLabels.splice(insertIndex, 0, costumLabel)
        } else if (panelData.protocol === 'RTSP') {
            panelLabels.splice(insertIndex, 0, 'Lien de stream')
        }
    }

    // Function to check if a field is required 
    const isFieldRequired = (key, protocol) => {
        return (key === 'username' || key === 'password' || key === 'name' || key === 'streamUrl' || key === 'streamId') &&
            !(key === 'password' && !modifiablePassword && isUpdateMode) && //if we dont want to modify pw on update mode
            !(key === 'streamId' && protocol === 'RTSP') && //skip streamId on RTSP
            !(key === 'streamUrl' && protocol === 'RTMP'); //skip streamUrl on RTMP
    };

    // Validates if fields are filled
    const canSubmit = Object.entries(panelData).every(([key, value]) => {
        const protocol = panelData.protocol;
        if (isFieldRequired(key, protocol)) {
            return Boolean(value);
        }
        return true; // For other keys, return true to skip the validation
    });


    const isDisable = (!canSubmit && LoadingFinished) || isSourceListVisible

    const handleCloseClick = () => {
        dispatch(closePanel())
    }

    const handleGenerateClick = () => {
        generateId()
    }

    const handleInputChange = (e) => {
        const { name, value } = e.target
        setPanelData({
            ...panelData,
            [name]: value
        })
    }

    const toggleSourcesList = (e) => {
        e.stopPropagation()
        setIsSourceListVisible(prev => !prev)
        if (isSourceListVisible) {
            setPanelData({
                ...panelData,
                "sources": sourceIds
            })
        }
    }

    const toggleRoleList = (e) => {
        e.stopPropagation()
        setIsRoleListVisible(prev => !prev)
        if (isSourceListVisible) setIsSourceListVisible(false)
    }

    const toggleProtocolList = (e) => {
        e.stopPropagation()
        setIsProtocolListVisible(prev => !prev)
    }

    const togglePasswordVisiblity = (e) => {
        e.stopPropagation()
        setIsPasswordVisible(prev => !prev)
    }

    const handleRoleClick = (e, role) => {
        e.stopPropagation()
        setPanelData({
            ...panelData,
            "role": role
        })
        setIsRoleListVisible(false)
    }

    const handleProtocolClick = (e, protocol) => {
        e.stopPropagation()
        setPanelData({
            ...panelData,
            "protocol": protocol
        })
        setIsProtocolListVisible(false)
    }

    useEffect(() => {
        if (itemToUpdate) {
            if (!userPage) {
                setPanelData(itemToUpdate)
            } else {
                //remove isRecorder from users
                const { isRecorder, ...restOfItem } = itemToUpdate
                // For user page, set sources according to item To Update
                const modifiedUser = {
                    ...restOfItem,
                    sources: itemToUpdate.sources.map(source => source.id)
                }
                setPanelData(modifiedUser)
            }
        }
        return () => {
            setItemToUpdate()
        }
        // eslint-disable-next-line
    }, [])

    const handleSubmit = async (e) => {
        e.preventDefault()

        if (!canSubmit) return

        try {
            const { id, ...dataWithoutId } = panelData
            const { password, ...dataWithoutPass } = dataWithoutId
            const dataToSend = (modifiablePassword || !isUpdateMode) ? dataWithoutId : dataWithoutPass

            if (isUpdateMode) {
                if (userPage) {
                    await updateUser({ id, userToUpdate: dataToSend }).unwrap()
                } else {
                    await updateSource({ id, sourceToUpdate: dataToSend }).unwrap()
                }
            } else {
                const createFunction = userPage ? createUser : createSource
                await createFunction(dataToSend).unwrap()
            }

            if (LoadingFinished) {
                dispatch(closePanel())
                dispatch(setAlertMsg(
                    `${isUpdateMode
                        ? userPage
                            ? "Utilisateur mis à jour"
                            : "Source mise à jour"
                        : userPage
                            ? "Utilisateur créé"
                            : "Source créé"} avec succès.`))
                setTimeout(() => {
                    dispatch(openSuccessAlert())
                }, 300)
            }

        } catch (err) {
            console.error(err)
            dispatch(setAlertMsg(`Erreur lors de la 
            ${isUpdateMode
                    ? userPage
                        ? "mise à jour de l'utilisateur."
                        : "mise à jour de la source."
                    : userPage
                        ? "création de l'utilisateur."
                        : "création de la source."}`))
            dispatch(openErrorAlert())
        }
    }

    const inputClasses = ` peer placeholder-transparent h-10 w-full border border-black dark:border-gray-500 border-opacity-20 bg-transparent text-black dark:text-white focus:outline-none rounded-md py-5 px-3 text-[15px] focus:border-blue-600 dark:focus:border-blue-600 focus:border-opacity-80 dark:focus:border-opacity-80 `

    // Classes de style pour les étiquettes des champs de saisie
    const labelClasses = ` absolute left-0 -top-3.5 text-blue-800 dark:text-blue-500 text-sm ml-3 bg-[#e8daf9] dark:bg-[#36454f] peer-placeholder-shown:text-base peer-placeholder-shown:top-2 transition-all peer-focus:px-1 peer-focus:-top-3.5 peer-focus:text-sm peer-placeholder-shown:text-black dark:peer-placeholder-shown:text-gray-300 `

    const buttonClasses = `font-bold text-md mt-2 bg-blue-600 rounded-xl text-white dark:text-black p-3 px-7 border m-auto border-transparent  ${isDisable ? '!text-blue-400' : 'hover:bg-transparent hover:border-blue-600 hover:text-blue dark:hover:text-blue-600'} focus:outline-none focus:ring-2 focus:ring-blue-600 dark:focus:ring-blue-900 `

    // helper function that takes the mutation error
    const renderErrorMessage = (error, success) => {
        if (error && !success) {
            return (
                <div className="error-message text-center mt-3 text-[#ff2323]">
                    <p className='px-4'>{error?.data?.message}</p>
                </div>
            )
        }

        return null
    }

    //nominations to increase readability in following map function
    const isPassword = key => key === 'password'
    const isRole = key => key === 'role'
    const isProtocol = key => key === 'protocol'
    const isSources = key => key === 'sources'
    const isName = key => key === 'username' || key === 'name'
    const isStreamUrl = key => key === 'streamUrl'
    const isStreamId = key => key === 'streamId'
    const isDate = key => key === 'creationDate'
    const isPosition = key => key === 'position'
    const isDescription = key => key === 'description' || key === 'observation'
    const userSourceCount = sourceIds?.length
    const allSourcesCount = allSources?.sources?.length

    /****************validation input functions : isAlphanumeric, isValidDate, isValidUrl, isValidPassword ****************/

    const isAlphanumeric = (value, field, allowedCharacters = []) => {
        const regex = new RegExp(`^[a-zA-Z0-9${allowedCharacters.join(' ')} ]+$`)
        if (!regex.test(value)) {
            const allowedCharsMessage = allowedCharacters.length > 0 ? `, caractères autorisés: [${allowedCharacters.join(' ')}]` : '.'
            return `${field} ne doit contenir que des lettres et des chiffres${allowedCharsMessage}`
        }
        return null
    }

    const isValidDate = (value) => {
        if (/[a-zA-Z]/.test(value)) { return `La date ne doit pas contenir de lettres.` }

        const regex = /^(\d{2})\/(\d{2})\/(\d{4})$/
        if (!regex.test(value)) { return `Veuillez entrer une date valide : (DD/MM/YYYY).` }

        const [, day, month, year] = value.match(regex)
        if (day < 1 || day > 31 || month < 1 || month > 12 || year < 1000) { return `La date n'est pas logique.` }

        // Create a Date object to handle edge cases (e.g., February 30)
        const parsedDate = new Date(`${year}-${month}-${day}`)
        if (
            parsedDate.getDate() !== parseInt(day, 10) ||
            parsedDate.getMonth() !== parseInt(month, 10) - 1 ||
            parsedDate.getFullYear() !== parseInt(year, 10)
        ) {
            return `La date n'est pas logique.`
        }
        return null
    }

    const isValidUrl = (value, protocols) => {
        const protocolRegex = protocols.join('|')
        const urlRegex = new RegExp(`^(?:${protocolRegex}):\\/\\/(?:[a-z0-9-]+\\.)*[a-z0-9]+(?::\\d+)?(?:\\/[^]*)?$`, 'i')

        if (!urlRegex.test(value)) {
            return `Veuillez entrer un lien valide avec le format "protocole://domaine.suffixe".`
        }
        return null
    }

    const isValidPassword = (value) => {
        if (value.length < 5) {
            return "Veuillez entrer un mot de passe d'au moins 5 caractères."
        }
        return null
    }

    /****************validation input functions : isAlphanumeric, isValidDate, isValidUrl, isValidPassword ****************/

    const renderValidationMessage = (key, value) => {
        if (value) {
            switch (true) {
                case isPassword(key):
                    return isValidPassword(value)
                case isName(key):
                    return isAlphanumeric(value, 'Le nom', ["-", "_"])
                case isDescription(key):
                    return isAlphanumeric(value, 'La description', ["'", "_", ",", ".", ":"])
                case isDate(key):
                    return isValidDate(value)
                case isStreamUrl(key):
                    return isValidUrl(value, ['http', 'https', 'rtsp'])
                case isPosition(key):
                    return isAlphanumeric(value, 'La position', ["'", "°", ",", "."])
                default:
                    return null
            }
        }
        return null
    }

    useEffect(() => {
        const errors = {}
        Object.keys(panelData).forEach((key) => {
            const validationError = renderValidationMessage(key, panelData[key])
            if (validationError) {
                errors[key] = validationError
            }
        })
        setValidationErrors(errors)
        // eslint-disable-next-line
    }, [panelData])

    // useEffect(() => {
    //     console.log(panelData)
    // }, [panelData])

    //random id geration state change
    useEffect(() => {
        if (generateIdSuccess) {
            setPanelData({
                ...panelData,
                streamId: generatedId.result
            })
            if (generateIdError) (
                console.log(generateIdError)
            )
        }
        // eslint-disable-next-line
    }, [generatedId])

    return (
        <div className={`z-[52] absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 p-5 bg-[#e8daf9] dark:bg-[#36454f] rounded-2xl shadow-2xl dark:shadow-[#a2a2a2d2] md:min-w-[692px]`}>

            <div
                onClick={handleCloseClick}
                className={`absolute top-4 right-4 p-1 text-black dark:text-white cursor-pointer rounded-md text-[17px] hover:bg-gray-400/[0.3]`}>
                <CgClose size={24} />
            </div>

            <div className="flex justify-between items-center">
                <h3 className="text-black dark:text-white text-[22px] font-bold m-2">
                    {
                        isUpdateMode
                            ?
                            (userPage ? 'Mettre à jour un utilisateur' : 'Mettre à jour une source')
                            :
                            (userPage ? 'Ajouter un utilisateur' : 'Créer une source')
                    }
                </h3>
            </div>

            {renderErrorMessage(createSourceError, createSourceSuccess)}
            {renderErrorMessage(updateSourceError, updateSourceSuccess)}
            {renderErrorMessage(createUserError, createUserSuccess)}
            {renderErrorMessage(updateUserError, updateUserSuccess)}

            {getSourcesLoading && userPage
                ?
                <div className="flex items-center justify-center bg-transparent text-black dark:text-white h-[450px]">
                    <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 
                                            border-solid border-current border-r-transparent -mt-1.5 animate-spin-slow">
                    </div>
                </div>
                : (<div className={`flex flex-col`}>
                    <div className={`${(isUpdateMode && userPage) ? 'pt-8' : 'py-8'} mx-auto w-[90%] leading-6 space-y-7 text-gray-700 sm:text-lg sm:leading-7 `}>
                        {Object.entries(panelData)
                            .filter(([key]) =>
                                key !== 'id'
                                && !(isPassword(key) && !modifiablePassword && isUpdateMode)
                                && !(isRole(key) && panelData.role === "admin")
                                && !(isStreamId(key) && panelData.protocol === 'RTSP')
                                && !(isStreamUrl(key) && panelData.protocol === 'RTMP')
                                && !((isSources(key)) && panelData.role === "admin"))
                            .map(([key, value], index) => (
                                <div className="relative mb-8" key={key}>
                                    <input
                                        autoComplete="off"
                                        type={(isPassword(key) && !isPasswordVisible) ? 'password' : 'text'}
                                        id={key}
                                        name={key}
                                        value=
                                        {
                                            (isSources(key)
                                                ? userSourceCount > 0
                                                    ? allSourcesCount === userSourceCount
                                                        ? "Toutes les sources sont sélectionnées"
                                                        : userSourceCount === 1
                                                            ? "01 source est sélectionnée"
                                                            : userSourceCount < 10
                                                                ? `0${userSourceCount} sources sont sélectionnées`
                                                                : `${userSourceCount} sources sont sélectionnées`
                                                    : ''
                                                : value)
                                        }
                                        onChange={handleInputChange}
                                        className={inputClasses + (validationErrors[key] && "!border-[#ff2323]")}
                                        placeholder={panelLabels[index]}
                                        disabled={isRole(key) || isSources(key) || isProtocol(key) || (isStreamId(key) && isUpdateMode)}
                                        onFocus={() => { handleFocusChange(key, true) }}
                                        onBlur={() => { handleFocusChange(key, false) }}
                                    />
                                    {/* hide/show button for password input */}
                                    {(isPassword(key) && value) && (
                                        <div
                                            className="absolute right-3 top-[10px] cursor-pointer text-black dark:text-white"
                                            onClick={togglePasswordVisiblity}
                                        >
                                            {isPasswordVisible
                                                ? <FaEye className="text-xl" />
                                                : <FaEyeSlash className="text-xl" />}
                                        </div>
                                    )}
                                    {/* side buttons for role protocol and source input */}
                                    {(isRole(key) || isSources(key) || (isProtocol(key) && !isUpdateMode)) && (
                                        <div
                                            className="absolute z-20 right-3 top-[10px] text-black dark:text-white cursor-pointer text-xl rounded hover:bg-gray-400/[0.3]"
                                            onClick={
                                                isRole(key)
                                                    ? toggleRoleList
                                                    : (isProtocol(key) && !isUpdateMode)
                                                        ? toggleProtocolList
                                                        : userPage
                                                            ? toggleSourcesList
                                                            : null}
                                        >
                                            {isRole(key) || isProtocol(key)
                                                ? (isRoleListVisible || isProtocolListVisible ? <IoMdArrowDropdown /> : <IoMdArrowDropup />)
                                                : (isSourceListVisible ? <BiCheckSquare className='text-[#25b441]' /> : <BsListCheck />)
                                            }
                                        </div>
                                    )}
                                    {/* generer button */}
                                    {(isStreamId(key) && !isUpdateMode) && (
                                        <div
                                            className="absolute z-20 p-1 right-3 top-[6px] text-black dark:text-white cursor-pointer border border-gray-400 text-sm rounded hover:bg-gray-400/[0.3]"
                                            onClick={handleGenerateClick}
                                        >
                                            <div className='flex justify-center items-center dark:invert'>
                                                <span className={`${generateIdLoading} && "mr-2 text-black dark:text-white"`}>Générer</span>
                                                {generateIdLoading && <>
                                                    <div className='h-1 w-1 mx-[1px] bg-black rounded-full animate-bounce [animation-delay:-0.3s]'></div>
                                                    <div className='h-1 w-1 mx-[1px] bg-black rounded-full animate-bounce [animation-delay:-0.15s]'></div>
                                                    <div className='h-1 w-1 mx-[1px] bg-black rounded-full animate-bounce'></div>
                                                </>}
                                            </div>
                                        </div>
                                    )}
                                    {/* role list */}
                                    {(isRole(key)) && (
                                        <DropdownV2
                                            handleRoleClick={handleRoleClick}
                                            isRoleListVisible={isRoleListVisible}
                                        />
                                    )}
                                    {/* protocol list */}
                                    {(isProtocol(key)) && (
                                        <DropdownV2
                                            handleProtocolClick={handleProtocolClick}
                                            isProtocolListVisible={isProtocolListVisible}
                                        />
                                    )}
                                    {/* source list */}
                                    {(isSources(key)) && (
                                        <DropdownV2
                                            setSourceIds={setSourceIds}
                                            panelData={panelData}
                                            isSourceListVisible={isSourceListVisible}
                                            allSources={allSources}
                                        />
                                    )}
                                    {/* labels */}
                                    <label
                                        onClick={(isSources(key) ? toggleSourcesList : null)}
                                        htmlFor={key}
                                        className={labelClasses +
                                            ((isSources(key) && userSourceCount === 0) && 'w-[96%] flex items-center justify-between cursor-pointer')
                                        }
                                    >
                                        {isSources(key)
                                            ? userSourceCount > 0
                                                ? 'Sources allouées'
                                                : panelLabels[index]
                                            : panelLabels[index]
                                        }
                                    </label>
                                    {focusedInput === key && (
                                        <p className="text-xs pl-2 pt-1 text-[#ff2323]">
                                            {validationErrors[key]}
                                        </p>
                                    )}
                                </div>
                            ))}
                    </div>
                    {userPage && isUpdateMode &&
                        (<div className="flex items-center text-left py-2 mx-auto w-[90%]">
                            <input
                                id={`Up-pass-checkbox`}
                                type="checkbox"
                                checked={modifiablePassword}
                                onChange={() => { setModifiablePassword(prev => !prev) }}
                                className="w-5 h-5 text-blue-600 bg-gray-100 dark:bg-gray-500 border-gray-300 rounded shadow-sm cursor-pointer"
                            />
                            <label
                                htmlFor={`Up-pass-checkbox`}
                                className="py-3 ml-2 text-md text-black dark:text-white cursor-pointer"
                            >
                                Modifier le mot de passe
                            </label>
                        </div>)}
                    <button
                        type="button"
                        onClick={handleSubmit}
                        className={buttonClasses + 'flex items-center'}
                        disabled={isDisable} // Disable the button if neither create nor update is possible
                    >
                        <span className=''>{isUpdateMode ? 'Mettre à jour' : (userPage ? 'Ajouter' : 'Créer')}</span>
                        {!LoadingFinished && (
                            <div className="h-7 w-7 ml-3 animate-spin rounded-full border-4 
                                        border-solid border-current border-r-transparent animate-spin-slow"></div>
                        )}
                    </button>
                </div>)}
        </div>
    )
}

export default Panel