import React from "react";

const LeftNavMenuItem = ({ text, icon, isSelected, action }) => {
  return (
    <div
    className={`flex items-center h-10 px-3 text-black dark:text-gray-200 text-sm cursor-pointer mb-[3px] rounded-lg${
      isSelected
        ? " bg-black/[0.07] dark:bg-white/[0.15] !text-[#aef] dark:!text-[#aef] font-bold"
        : " left-nav-menu-item hover:!shadow-[-2px_6px_19px_1px_#CBD5E0] dark:hover:!shadow-[-2px_6px_19px_1px_#2D3748] hover:bg-black/[0.05] dark:hover:bg-white/[0.20]"
    }`}
      onClick={action}
    >
      <span className="text-xl mr-5">{icon}</span>
      {text}
    </div>
  );
};

export default LeftNavMenuItem;
