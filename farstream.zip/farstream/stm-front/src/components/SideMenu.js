import React, { useState, useEffect, useRef } from "react"
// import { Link } from "react-router-dom"
import { CgMediaLive } from "react-icons/cg"


import { BiChevronLeft, BiChevronRight } from "react-icons/bi"
import { MdFullscreenExit } from "react-icons/md"
import CheckBoxList from "../shared/CheckBoxList"
import { useSelector } from "react-redux"


const SideMenu = ({ sideMenuIsOpen, setSideMenuIsOpen, videosInSideMenu, handleViewClick, videosInGrid, setVideosInGrid, setOtherVideos }) => {
    const wideView = useSelector((state) => state.ui.wideView)
    const [isAllSelected, setIsAllSelected] = useState(false)
    const [checkedVideos, setCheckedVideos] = useState({})
    const sideMenuRefElement = useRef()
    const sideMenuRefBtn = useRef()

    useEffect(() => {
        const toggleSideMenu = (event) => {
            const isMenuButtonClick = sideMenuRefBtn?.current?.contains(event.target)
            const isOutsideMenuClick = !sideMenuRefElement?.current?.contains(event.target)
            //close the side menu
            if (isOutsideMenuClick && sideMenuIsOpen) { setSideMenuIsOpen(false) }
            //toggle the side menu 
            if (isMenuButtonClick) { setSideMenuIsOpen(prev => !prev) }
        }
        document.addEventListener('click', toggleSideMenu)
        return () => {
            document.removeEventListener('click', toggleSideMenu)
        }
        // eslint-disable-next-line
    }, [sideMenuIsOpen])

    const handleFullscreenExit = () => {
        setSideMenuIsOpen(false)
        handleViewClick()
    }

    const UpdateGrid = () => {
        const selectedVideoIds = Object.keys(checkedVideos).filter(streamId => checkedVideos[streamId])
        const selectedVideos = videosInSideMenu.filter(video => selectedVideoIds.includes(video.streamId))
        if (selectedVideoIds.length === 0) {
            setVideosInGrid(videosInSideMenu.slice(0, 1))
        } else {
            setVideosInGrid(selectedVideos.slice(0, 16))
        }
    }

    useEffect(() => {
        const initialCheckedVideos = {}
        //setting the CheckedVideos with every render
        videosInGrid?.forEach(video => { initialCheckedVideos[video?.streamId] = true })
        setCheckedVideos(initialCheckedVideos)
        // its mendatory to set OtherVideos here
        const nonSelectedVideos = videosInSideMenu?.filter(video => !initialCheckedVideos[video.streamId])
        setOtherVideos(nonSelectedVideos)
        // eslint-disable-next-line
    }, [videosInGrid])

    const filteredVideosInSideMenu = videosInSideMenu?.filter(video => video !== undefined)


    return (
        <div ref={sideMenuRefElement}>
            <div
                title={`${sideMenuIsOpen ? "Fermer le menu latéral" : "Ouvrir le menu latéral"}`}
                ref={sideMenuRefBtn}
                className={`absolute right-[-14px] transition-all duration-300 z-[35] bg-black bg-opacity-0 hover:bg-opacity-10 dark:bg-opacity-0 hover:dark:bg-opacity-40 dark:bg-white rounded-tl rounded-bl py-[14px] cursor-pointer  border-2 border-gray-400 dark:border-gray-400
                          ${wideView ? sideMenuIsOpen ? "bg-white bg-opacity-40 top-6" : "top-6" : "top-5"}
                          ${sideMenuIsOpen ? "translate-x-[-400px] !right-[-10px] !bg-opacity-20 dark:bg-opacity-40 !border-0" : "hover:right-[-10px] "}`}
            >

                {!sideMenuIsOpen ?
                    <BiChevronLeft className={`text-2xl translate-x-[-6px] text-black dark:text-white`} />
                    :
                    <BiChevronRight className={`text-2xl translate-x-[-6px] text-black dark:text-white ${sideMenuIsOpen && wideView && "text-white"}`} />
                }

            </div>


            <div className={`absolute w-[400px] h-[550px] z-[36] right-0 rounded-bl transition-transform duration-300 
                            ${wideView ? "top-6" : "top-5"} bg-black bg-opacity-10 dark:bg-white dark:bg-opacity-10 
                            ${sideMenuIsOpen ? "translate-x-[0px] shadow-md" : "translate-x-[400px]"}`}
                style={{
                    backdropFilter: "blur(40px)",
                    backgroundColor: sideMenuIsOpen && wideView ? "rgba(0, 0, 0, 0.4)" : "initial"
                }}>

                <div className="sticky top-0 left-1 flex justify-between items-center p-3 m-1
                                 text-black dark:text-white bg-purple-200 dark:bg-purple-900 rounded-lg" >

                    <div className="flex items-center">
                        <CgMediaLive className="text-xl mr-2" />
                        <span>Selectionnez les streams</span>
                    </div>
                    <div
                        title="Quitter le mode plein écran"
                        onClick={handleFullscreenExit}
                        className={`absolute top-[5.6px] right-[4.6px]
                        ${wideView && 'p-2 rounded-md  hover:bg-black/[0.2] dark:hover:bg-[#ffe3e3]/[0.4] cursor-pointer'}`}>
                        {wideView && <MdFullscreenExit className="text-[21px]" />}
                    </div>

                </div>
                {filteredVideosInSideMenu?.length > 0
                    ?
                    <div className={`h-[calc(550px-65px)] w-[97%] m-auto overflow-y-scroll text-black dark:text-white
                                ${wideView ? "text-white" : ""}`}>
                        <div className="flex flex-col ">
                            <CheckBoxList
                                videolist={videosInSideMenu}
                                isAllSelected={isAllSelected}
                                checkedVideos={checkedVideos}
                                setCheckedVideos={setCheckedVideos}
                            />
                            <div className="m-auto mb-3">
                                <button
                                    onClick={() => { setIsAllSelected(perv => !perv) }}
                                    className="inline-block rounded bg-primary px-3 pb-2 pt-2.5 text-xs font-medium 
                                    transition hover:bg-primary-600 active:scale-90 duration-100 will-change-transform
                                    hover:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.3),0_4px_18px_0_rgba(59,113,202,0.2)] mx-auto mt-4"
                                >
                                    {`${isAllSelected ? "Déselectionner tout" : "Tout selectionner"}`}
                                </button>
                                <button
                                    onClick={UpdateGrid}
                                    className="inline-block rounded bg-primary px-6 pb-2 pt-2.5 text-xs font-medium 
                                    transition hover:bg-primary-600 active:scale-90 duration-100 will-change-transform
                                    hover:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.3),0_4px_18px_0_rgba(59,113,202,0.2)] mx-auto mt-4"
                                >
                                    Mettre à jour la grille
                                </button>
                            </div>
                        </div>
                    </div>
                    :
                    <div className={`p-4 text-black dark:text-white ${wideView ? "text-white" : ""}`}>
                        Pas de streams a regarder
                    </div>
                }

            </div>

        </div>

    )
}

export default SideMenu

