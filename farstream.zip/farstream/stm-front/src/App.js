import React from "react"
import { Outlet, Route, Routes } from "react-router-dom"

import Login from "./pages/Login"
import StreamPage from "./pages/StreamPage"
import SourcesPage from "./pages/SourcesPage"
import Header from "./components/Header"
import ErrorComponent from "./shared/ErrorComponent"
import RequireAuth from "./utils/RequireAuth"
import PersistLogin from "./utils/PersistLogin"
import Users from "./pages/Users"
import PlaylistPage from "./pages/PlaylistPage"
import HistoryPage from "./pages/HistoryPage"



const AppLayout = () => {
  return (
    <>
      <Header />
      <Outlet />
    </>
  )
}


function App() {
  
  return (
    <Routes>
      <Route path="/" element={<AppLayout />} >
        <Route path="login" element={<Login />} />
        <Route element={<PersistLogin />}>
          <Route index element={<SourcesPage />} />
          <Route path="sources" element={<SourcesPage />} />
          <Route path="stream" element={<StreamPage />} />
          <Route path="vods" element={<PlaylistPage />} />
          <Route element={<RequireAuth />}>
            <Route path="users" element={<Users />} />
            <Route path="history" element={<HistoryPage />} />
          </Route>
        </Route>
        <Route path='*' exact={true} element={<ErrorComponent />} />
      </Route>
    </Routes>
  )
}

export default App
