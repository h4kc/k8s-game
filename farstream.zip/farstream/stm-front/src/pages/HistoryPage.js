import React from 'react'

import LeftNav from '../components/LeftNav'
import Options from '../shared/Options'
import { useGetHistoryQuery } from '../store/slices/historyApiSlice'
import { VscRefresh } from 'react-icons/vsc'
import { CgClose } from 'react-icons/cg'

const HisoryPage = () => {
    const { data, isLoading, isError, refetch } = useGetHistoryQuery()
    const handleRefresh = () => {
        refetch()
    }
    return (

        <>
            <LeftNav />
            <Options />

            <div className="flex flex-col float-right w-[calc(100%-240px)] h-[calc(100vh-64px)] overflow-y-scroll p-9 pb-0 bg-white dark:bg-black">
                {isError
                    ?
                    <div className="flex h-full items-center justify-center p-5 w-full bg-white dark:bg-black">
                        <div className="text-center">
                            <div className="inline-flex rounded-full bg-red-100 dark:bg-red-900 p-4">
                                <div className="rounded-full stroke-red-600 bg-red-200 dark:bg-red-700 p-4">
                                    <CgClose size={54} />
                                </div>
                            </div>
                            <h1 className="mt-5 text-[36px] font-bold text-slate-800 dark:text-gray-300 lg:text-[50px]">Erreur</h1>
                            <p className="text-slate-600 dark:text-gray-400 mt-5 lg:text-lg">
                                Ressource indisponible pour le moment.
                                  
                                <br /> Essayez de rafraîchir la page.
                            </p>
                        </div>
                    </div>
                    : isLoading
                        ? <div className="flex h-full w-full items-center justify-center bg-white dark:bg-black text-black dark:text-white">
                            <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 
                            border-solid border-current border-r-transparent -mt-1.5 animate-spin-slow">
                            </div>
                        </div>
                        :
                        <>
                            <div className="flex justify-between text-black dark:text-white w-full mb-5">
                                <h1 className="bg-[#00000016] dark:bg-gray-900 border border-gray-400 dark:border-gray-400 p-3 px-10 inline-block rounded-[7px] text-lg">
                                    <div className="flex items-center">
                                        {`Liste des évenements`}
                                    </div>
                                </h1>
                                <div className="flex">
                                    <button
                                        onClick={handleRefresh}
                                        className={`text-white dark:text-black bg-blue-600 hover:bg-blue-400 px-3 my-1 inline-block rounded-xl text-sm`}>
                                        <div className="flex items-center">
                                            <VscRefresh className="mr-2 text-lg" />
                                            <span>Rafraîchir</span>
                                        </div>
                                    </button>

                                </div>
                            </div>

                            <ul className='w-full text-black dark:text-white  bg-white dark:bg-black'>
                                <hr className="my-5 border-black/[0.2] border dark:border dark:border-white/[0.2]" />
                                {data?.history
                                    .map((item) => {
                                        return (
                                            <li className="w-full" key={item.id}>
                                                <div className='flex justify-between px-4'>
                                                    <span>{item.operation}</span>
                                                    <span>{item.createdAt}</span>
                                                </div>
                                                <hr className="my-5 border-black/[0.2] border dark:border dark:border-white/[0.2]" />
                                            </li>
                                        )
                                    })}
                            </ul>
                        </>}
            </div>
        </>
    )
}

export default HisoryPage
