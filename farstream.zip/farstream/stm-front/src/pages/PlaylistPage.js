
import React, { useEffect, useState } from "react"
import { Watermark } from "antd"


import Table from "../components/Table"
import LeftNav from "../components/LeftNav"
import DeleteConfimation from "../shared/DeleteConfimation"
import ShimmerVideoCard from "../shared/ShimmerVideoCard"
import VideoCard from "../components/VideoCard"
import Options from "../shared/Options"

import useAuth from "../utils/useAuth"
import { useGetSourcesForUserQuery } from "../store/slices/sourceApiSlice"
import { useAssociateMultipleVodsMutation, useAssociateVodMutation, useGetAllVodsMutation, useGetSourcePlaylistMutation } from "../store/slices/vodApiSlice"
import { openDeleteConfimation, openErrorAlert, openSuccessAlert, setAlertMsg } from "../store/slices/uiSlice"

import { CgClose } from "react-icons/cg"
import { useDispatch, useSelector } from "react-redux"
import { BiSolidSelectMultiple } from "react-icons/bi"
import { MdCancel } from "react-icons/md"
import { IoIosLink, IoMdArrowDropdown, IoMdArrowDropup } from "react-icons/io"
import { RiDeleteBinLine } from "react-icons/ri"
import { GoDatabase } from "react-icons/go"
import SearchBar from "../components/SeachBar"
import { CiSearch } from "react-icons/ci"
import AlertElt from "../shared/AlertElt"
import DropdownV2 from "../shared/DropdownV2"

const PlaylistPage = () => {
    // State of the Layout of page, its used to not trigger useEffects unnessecerly in case of checkbox, and control showed buttons and layout
    const currentLayout = useSelector((state) => state.ui.layout)
    const listLayout = currentLayout === 'list'
    const gridLayout = currentLayout === 'grid'

    const dispatch = useDispatch()

    //state to know if checkbox are visible or not
    const [isSelectionAlloued, setIsSelectionAlloued] = useState(false)

    //state to know if search bar is visible or not
    const [isSearchVisible, setIsSearchVisible] = useState(false)

    //state to show only searched items
    const [filteredItems, setFilteredItems] = useState([])

    // State Object for individual checkbox status
    const [checkedItems, setCheckedItems] = useState({})

    // State to track if all checkboxes are selected
    const [isAllSelected, setIsAllSelected] = useState(false)

    // State to track if the "Check All" button is clicked
    const [checkAllClicked, setCheckAllClicked] = useState(true)

    // State to track video player panel
    const [playerIsOpen, setPlayerIsOpen] = useState(false)

    // State to track association of vod/source panel
    const [panelIsOpen, setPanelIsOpen] = useState(false)

    // State to track the path of vod to play
    const [videoPath, setVideoPath] = useState("")

    // State to track the source selected in association vod/source panel
    const [selectedSource, setSelectedSource] = useState()

    // State to track the vod to be : associated/deleted
    const [selectedVod, setSelectedVod] = useState(null)

    // State to track the list of sources next to the search bar
    const [isSourceListVisible, setIsSourceListVisible] = useState(false)

    //State to track the selected source from the list of sources to get playlist
    const [sourceToGetPlaylist, setSourceToGetPlaylist] = useState()

    //State to track some text change if we select allsources to get vodss
    const [isAllSources, setIsAllSources] = useState(true)

    //State to track the fetched items because we have 2 get mutaions
    const [videos, setVideos] = useState(true)

    //State to track the fetching error because we have 2 get mutaions
    const [error, setError] = useState(true)


    const { isAdmin, username } = useAuth()

    const [getSourcePlaylist, {
        data: playlist,
        isLoading: PlaylistLoading,
        isSuccess: isPlaylistSuccess,
        isError: IsPlaylistError,
        error: playlistError
    }] = useGetSourcePlaylistMutation()

    const [getAllVods, {
        data: vods,
        isLoading: VodsLoading,
        isSuccess: isVodsSuccess,
        isError: isVodsError,
        error: vodsError
    }] = useGetAllVodsMutation()


    const { data: sources, isSuccess: getSourceSuccess, isError: sourceError, isLoading: sourcesLoading } = useGetSourcesForUserQuery({
        refetchOnFocus: true,
        refetchOnMountOrArgChange: true
    })

    const getIsLoading = PlaylistLoading || VodsLoading
    const getisSuccess = isVodsSuccess || isPlaylistSuccess
    const videosError = IsPlaylistError || isVodsError

    const [associateVod, { isLoading: isUpdatingVod }] = useAssociateVodMutation()
    const [associateVods, { isLoading: isUpdatingVods }] = useAssociateMultipleVodsMutation()
    const vodAssociateLoadingFinished = !isUpdatingVod && !isUpdatingVods

    //function in relation with video player : iframe
    const toggleVideoPlayer = () => {
        setPlayerIsOpen(prev => !prev)
    }

    //function in relation with panel to asssociate vod with source
    const togglePanel = (item) => {
        if (panelIsOpen) {
            setSelectedSource()
        }
        setSelectedVod(item)
        setPanelIsOpen(prev => !prev)
    }

    //function in relation with panel to asssociate vod with source
    const handleRadioChange = (source) => {
        setSelectedSource(source)
    }


    // Function to handle delete of selection of vods (checkboxes)
    const handleDeleteButton = (items) => {
        //here we filter and get only vodIs(keys) that are checked(true) in checkedItems
        const selectedVodIds = Object.entries(items)
            .filter(([key, value]) => value)
            .map(([key]) => key)
        //if no item is checked nothing happens ( for the moment :> )
        if (selectedVodIds.length === 0) {
            //we will handle that later with an alert
            return
        }
        setSelectedVod(selectedVodIds)
        dispatch(openDeleteConfimation())

    }

    // Function to handle association of selection of vods with a source (checkboxes)
    const handleAssociateButton = (items) => {
        //here we filter and get only vodIs(keys) that are checked(true) in checkedItems
        const selectedVodIds = Object.entries(items)
            .filter(([key, value]) => value)
            .map(([key]) => key);
        //if no item is checked nothing happens ( for the moment :> )
        if (selectedVodIds.length === 0) {
            //we will handle that later with an alert
            return
        }

        // Find the corresponding vod items from the videos array
        const selectedVods = videos.filter((vod) => selectedVodIds.includes(vod.vodId))

        //  Check if any selected vod has a truthy sourceId whitch means its already associated
        if (selectedVods.some((vod) => vod.sourceId)) {
            //we will handle that later with an alert
            return
        }
        togglePanel(selectedVodIds)
    }

    //function in relation with source list  to get playlist of a source
    const handleGetVods = (source) => {
        setIsSelectionAlloued(false) // close selection
        setIsSearchVisible(false) // close search bar
        if (source === "allVods") {
            setSourceToGetPlaylist(`allVods`)
            getAllVods()
            setIsAllSources(true)
        }
        else {
            setSourceToGetPlaylist(source)
            getSourcePlaylist(source?.id)
            setIsAllSources(false)
        }
    }

    // Effect to set the sourceToGetPlaylist state to the first source
    useEffect(() => {
        const fetchData = () => {
            if (isAdmin) {
                setSourceToGetPlaylist(`allVods`)
                getAllVods()
            } else {
                if (sources.sources.length > 0) {
                    setSourceToGetPlaylist(sources?.sources[0])
                    getSourcePlaylist(sources?.sources[0]?.id)
                    setIsAllSources(false)
                }
            }
        }
        if (getSourceSuccess) fetchData()
        // eslint-disable-next-line 
    }, [getSourceSuccess])

    useEffect(() => {
        if (isAllSources) {
            setVideos(vods)
            setError(vodsError)
        } else {
            setVideos(playlist)
            setError(playlistError)
        }
        // eslint-disable-next-line 
    }, [playlist, vods])

    // Effect to update individual checkbox status when "Check All" button is clicked and evey time we get videos
    useEffect(() => {
        if (getisSuccess) {
            setFilteredItems(videos)
            if (listLayout && checkAllClicked) {
                const updatedCheckedItems = {}
                videos?.forEach((item) => {
                    updatedCheckedItems[item.vodId] = isAllSelected
                })
                setCheckedItems(updatedCheckedItems)
                setCheckAllClicked(false)
            }
        }
        // eslint-disable-next-line
    }, [isAllSelected, videos])

    // Effect to refrech checkedItems everytime we request videos, it triggers the above effect
    useEffect(() => {
        if (videos) {
            setCheckAllClicked(true)
            setIsAllSelected(false)
        }
    }, [videos])


    // Function to toggle the status of an individual checkbox
    const toggleCheck = (itemId) => {
        setCheckedItems(prev => ({
            ...prev,
            [itemId]: !prev[itemId]
        }))
    }

    // Function to handle the "Check All" button click
    const handleAllCheck = () => {
        setIsAllSelected(perv => !perv)
        setCheckAllClicked(true)
    }

    useEffect(() => {
        if (listLayout) {
            const checkedValues = Object.values(checkedItems)
            // Set isAllSelected to false if at least one checkbox is unchecked
            if (checkedValues.some(value => !value)) {
                setIsAllSelected(false)
            }
            // Set isAllSelected to true if all checkboxes are checked (we make sure if checkedValues isn't empty cuz it will mislead us)
            if (checkedValues.length > 0 && checkedValues.every(Boolean)) {
                setIsAllSelected(true)
            }
        }
        // eslint-disable-next-line
    }, [checkedItems])

    //conditionnal rendering for gridLayout and listLayout during loading and after fulfiled request and if there is an error(error rendering is in jsx)
    let content
    if (gridLayout) {
        if (getIsLoading) {
            content =
                <>
                    {Array(12)
                        .fill("")
                        .map((e, index) => {
                            return <ShimmerVideoCard key={index} />
                        })}
                </>
        } else if (getisSuccess) {
            content = filteredItems?.map((item) => {
                //if theres a sourceID attribute it means the vod has a matching source
                const matchingSource = item.sourceId
                return <VideoCard
                    key={item.vodId}
                    video={item}
                    setSelectedVod={setSelectedVod}
                    setVideoPath={setVideoPath}
                    toggleVideoPlayer={toggleVideoPlayer}
                    togglePanel={togglePanel}
                    matchingSource={matchingSource}
                />
            })
        } else if (videosError) {
            console.log(error)
        }
    } else {
        if (getIsLoading) {
            content =
                <div className="flex items-center justify-center bg-white dark:bg-black text-black dark:text-white h-[calc(100vh-64px)]">
                    <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 
                    border-solid border-current border-r-transparent -mt-1.5 animate-spin-slow">
                    </div>
                </div>
        } else if (getisSuccess) {
            content = <Table
                items={filteredItems}
                setItemToUpdate={setSelectedVod}
                setItemToDelete={setSelectedVod}
                vodPage={true}
                setVideoPath={setVideoPath}
                toggleVideoPlayer={toggleVideoPlayer}
                togglePanel={togglePanel}
                isSelectionAlloued={isSelectionAlloued}
                checkedItems={checkedItems}
                toggleCheck={toggleCheck}
                handleAllCheck={handleAllCheck}
            />
        } else if (videosError) {
            console.log(error)
        }
    }

    const handleSubmit = async (e) => {
        e.preventDefault()
        if (!selectedSource) return
        let isArray
        try {
            // Check if selectedVod is an array
            isArray = Array.isArray(selectedVod)
            // Determine the appropriate associate function based on the type of selectedVod
            const associteFunction = isArray ? associateVods : associateVod
            // Call the associate function with the correct key based on the type of selectedVod
            await associteFunction({ [isArray ? 'vodIds' : 'vodId']: selectedVod, sourceId: selectedSource.id }).unwrap()
            // close panel when loading finishes, null parameter et setselectedVod to null
            if (vodAssociateLoadingFinished) {
                togglePanel(null)
                dispatch(setAlertMsg(`${!isArray ? "Sauvegarde  associée" : "Sauvegardes associées"} avec succès.`))
                dispatch(openSuccessAlert())
                handleGetVods("allVods")
            }
        } catch (err) {
            console.error(err)
            dispatch(setAlertMsg(`Erreur lors de l'association ${!isArray ? "de la sauvegarde." : "des sauvegardes."}`))
            dispatch(openErrorAlert())
        }
    }

    const buttonClasses = `font-bold text-md bg-blue-600 rounded-xl text-white dark:text-black p-3 px-7 border border-transparent ${!selectedSource ? '!text-blue-400' : 'hover:bg-transparent hover:border-blue-600 hover:text-blue-600 dark:hover:text-blue-600'} focus:outline-none focus:ring-2 focus:ring-blue-600 dark:focus:ring-blue-900 `

    return (

        <>
            <LeftNav />
            <Options />
            <AlertElt />
            <DeleteConfimation
                itemToDelete={selectedVod}
                setItemToDelete={setSelectedVod}
                vodPage={true}
                handleGetVods={handleGetVods}
                sourceToGetPlaylist={sourceToGetPlaylist}
            />
            <div className="flex float-right w-[calc(100%-240px)] h-[calc(100vh-64px)] p-9 bg-white dark:bg-black">
                <div className="grow flex flex-col items-center">

                    {videosError || sourceError
                        ?
                        <div className="flex h-full items-center justify-center p-5 w-full bg-white dark:bg-black">
                            <div className="text-center">
                                <div className="inline-flex rounded-full bg-red-100 dark:bg-red-900 p-4">
                                    <div className="rounded-full stroke-red-600 bg-red-200 dark:bg-red-700 p-4">
                                        <CgClose size={54} />
                                    </div>
                                </div>
                                <h1 className="mt-5 text-[36px] font-bold text-slate-800 dark:text-gray-300 lg:text-[50px]">Erreur</h1>
                                <p className="text-slate-600 dark:text-gray-400 mt-5 lg:text-lg">
                                    Ressource indisponible pour le moment.

                                    <br /> Essayez de rafraîchir la page.
                                </p>
                            </div>
                        </div>
                        : sourcesLoading
                            ? <div className="flex h-full w-full items-center justify-center bg-white dark:bg-black text-black dark:text-white">
                                <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 
                              border-solid border-current border-r-transparent -mt-1.5 animate-spin-slow">
                                </div>
                            </div>
                            : <>
                                <div className="flex justify-between text-black dark:text-white w-full mb-5">
                                    <h1 className="bg-[#00000016] dark:bg-gray-900 border border-gray-400 dark:border-gray-400 p-3 px-10 inline-block rounded-[7px] text-lg">
                                        <div className="flex items-center">
                                            {`Liste des sauvegaredes`}
                                            {gridLayout && getIsLoading && (
                                                <div className="h-7 w-7 ml-3 animate-spin rounded-full border-4 
                                        border-solid border-current border-r-transparent animate-spin-slow"></div>
                                            )}
                                        </div>
                                    </h1>
                                    <div className="flex ">
                                        {/* delete associate button */}
                                        {isAdmin && listLayout && isSelectionAlloued &&
                                            <>
                                                <button
                                                    onClick={() => { handleDeleteButton(checkedItems) }}
                                                    className={`text-red-500 bg-transparent border border-red-500 px-1 my-1 inline-block rounded-xl text-sm mr-3`}>
                                                    <div className="flex items-center">
                                                        <RiDeleteBinLine className="mr-2 text-lg" />
                                                        <span>Supprimer</span>
                                                    </div>
                                                </button>
                                                {isAllSources && <button
                                                    onClick={() => { handleAssociateButton(checkedItems) }}
                                                    className={`text-yellow-500 bg-transparent border border-yellow-500 px-1 my-1 inline-block rounded-xl text-sm mr-3`}>
                                                    <div className="flex items-center">
                                                        <IoIosLink className="mr-2 text-lg" />
                                                        <span>Associer</span>
                                                    </div>
                                                </button>}
                                            </>
                                        }
                                        {/* selection button  */}
                                        {isAdmin && listLayout && videos?.length > 1 &&
                                            <button
                                                onClick={() => { setIsSelectionAlloued(perv => !perv) }}
                                                className={`border border-gray-400 dark:border-gray-300 text-gray-600 dark:text-gray-300 ${isSelectionAlloued ? 'hover:text-red-500 hover:border-red-500 dark:hover:text-red-500 dark:hover:border-red-500' : 'hover:text-blue-500 hover:border-blue-500 dark:hover:text-blue-500 dark:hover:border-blue-500'} px-3 my-1 mr-3 inline-block rounded-full text-sm`}>
                                                <div className="flex items-center">
                                                    {isSelectionAlloued ? <MdCancel className="text-xl" /> : <BiSolidSelectMultiple className="text-xl" />}
                                                    {/* <span>{isSelectionAlloued ? 'Annuler' : 'Selectionner'}</span> */}
                                                </div>
                                            </button>
                                        }
                                        {/* search bar  */}
                                        {isSearchVisible
                                            ? <SearchBar
                                                vodPage={true}
                                                items={videos}
                                                setFilteredItems={setFilteredItems}
                                                setIsSearchVisible={setIsSearchVisible}
                                            />
                                            : (videos?.length > 1 && <button
                                                onClick={() => { setIsSearchVisible(true) }}
                                                className="hover:bg-blue-100 dark:hover:bg-blue-900 border border-gray-400 dark:border-gray-400 text-black dark:text-white font-black p-3 my-1 mr-3 inline-block rounded-[500px] text-sm">
                                                <div className="flex items-center">
                                                    <CiSearch size={21} />
                                                </div>
                                            </button>)
                                        }
                                        {/* source list */}
                                        <div className={`relative w-auto my-1 h-8 md:h-11 border border-gray-400 dark:border-gray-400 py-2 px-5 pr-11 rounded-2xl`}>
                                            <span>
                                                {sourceToGetPlaylist === "allVods" ? "Toutes les sources" : `Source : ${sourceToGetPlaylist?.name}`}
                                            </span>
                                            <div
                                                className="absolute z-20 right-3 top-[10px] text-black dark:text-white cursor-pointer text-xl rounded hover:bg-gray-400/[0.3]"
                                                onClick={() => { setIsSourceListVisible(perv => !perv) }}
                                            >
                                                {isSourceListVisible ? <IoMdArrowDropdown /> : <IoMdArrowDropup />}
                                            </div>
                                            <DropdownV2
                                                isSourceListVisible={isSourceListVisible}
                                                setIsSourceListVisible={setIsSourceListVisible}
                                                allSources={sources}
                                                handleGetVods={handleGetVods}
                                                isAdmin={isAdmin}
                                                vodPage={true}
                                            />
                                        </div>
                                    </div>
                                </div>
                                {videos?.length === 0
                                    ?
                                    <div className="flex h-full items-center justify-center w-full bg-white dark:bg-black">
                                        <div className="text-center">
                                            <div className="inline-flex rounded-full bg-purple-100 dark:bg-[#7b3c7e] p-4">
                                                <div className="rounded-full stroke-purple-600 bg-purple-200 dark:bg-[#c62cb9] p-4">
                                                    <GoDatabase size={54} />
                                                </div>
                                            </div>
                                            <p className="text-slate-600 dark:text-gray-200 mt-5 lg:text-xl">
                                                {`${isAllSources ? "Pas de sauvegarde disponible pour le moment." : "Pas de sauvegarde disponible pour cette source."}`}
                                            </p>
                                        </div>
                                    </div>
                                    :
                                    listLayout
                                        ?
                                        <div className="w-full flex flex-col items-center overflow-y-auto">
                                            {content}
                                        </div>
                                        :
                                        <div className="w-full p-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-y-0 gap-x-7 overflow-y-auto ">
                                            {content}
                                        </div>
                                }
                            </>
                    }

                    {/* div for blury background */}
                    {(playerIsOpen || panelIsOpen) && (<div className={`fixed top-0 left-0 w-screen h-screen bg-transparent transition-opacity ${(playerIsOpen || panelIsOpen)
                        ? "opacity-100 visible z-50"
                        : "opacity-0 invisible "
                        }`} style={{ backdropFilter: "blur(5px)" }}
                    ></div>)}

                    {/* VideoPlayer */}
                    {playerIsOpen && (
                        <div
                            className={`z-[52] absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 h-[60%] w-1/2 rounded-md border dark:border-gray-700 shadow-2xl`} >
                            <Watermark
                                className="w-full h-full"
                                content={username}
                                gap={[90.100]}
                                font={{
                                    color: "#FFFFFF65",
                                    fontSize: "12"
                                }}
                            >
                                <div
                                    onClick={toggleVideoPlayer}
                                    className={`absolute top-2 right-1 p-1 opacity-0 hover:opacity-100 transition-opacity duration-300 
                                        text-white cursor-pointer rounded-md text-[17px] bg-black bg-opacity-40`}>
                                    <CgClose size={24} />
                                </div>

                                <div className="rounded-md h-full w-full">
                                    <iframe
                                        title={`${videoPath}`}
                                        width="100%"
                                        height="100%"
                                        src={`${process.env.REACT_APP_AMS_URL}/WebRTCApp/play.html?id=${videoPath}&playOrder=vod`}
                                    >
                                    </iframe>
                                </div>
                            </Watermark>
                        </div>
                    )}
                    {panelIsOpen && (
                        <div className={`z-[52] flex flex-col absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 p-5 bg-[#d28add52] dark:bg-[#39163d85] rounded-2xl shadow-2xl md:min-w-[400px] max-h-[510px]`}
                            style={{
                                backdropFilter: "blur(40px)"
                            }}>

                            <div className="flex justify-between items-center">
                                <h3 className="text-black dark:text-white text-[22px] font-bold p-4">
                                    Associer la sauvegarde a une source
                                </h3>
                            </div>
                            <div className="!w-full !max-h-[50%] overflow-y-scroll no-scrollbar my-4">
                                <ul className="w-[90%] mx-auto text-sm font-medium rounded-lg border-black/[0.2] border dark:border dark:border-white/[0.2] ">
                                    {sources?.sources?.map((source, index, array) => (
                                        <li key={source.id} className="w-full rounded-lg hover:bg-gray-100/[0.2]">
                                            <div className="flex items-center pl-3">
                                                <input
                                                    id={`${source.id}-radio`}
                                                    type="radio"
                                                    name="sourceRadio"
                                                    checked={selectedSource === source}
                                                    onChange={() => handleRadioChange(source)}
                                                    className="w-4 focus:ring-0 ring-0 focus:ring-offset-0 ring-offset-0 cursor-pointer"
                                                />
                                                <label
                                                    htmlFor={`${source.id}-radio`}
                                                    className="w-full text-black dark:text-white py-3 ml-2 text-sm font-medium cursor-pointer"
                                                >
                                                    {source.name}
                                                </label>
                                            </div>
                                            {index !== array.length - 1 && (
                                                <hr className="w-[94%] mx-auto border-black/[0.2] border dark:border dark:border-white/[0.2]" />
                                            )}
                                        </li>
                                    ))}

                                </ul>
                            </div>
                            <div className="flex items-center justify-center mt-4">
                                <button
                                    type="button"
                                    onClick={handleSubmit}
                                    className={buttonClasses + 'flex items-center'}
                                    disabled={!selectedSource}
                                >
                                    <span className=''>Associer</span>
                                    {!vodAssociateLoadingFinished && (
                                        <div className="h-7 w-7 ml-3 animate-spin rounded-full border-4 
                                        border-solid border-current border-r-transparent animate-spin-slow"></div>
                                    )}
                                </button>
                                <button
                                    type="button"
                                    onClick={togglePanel}
                                    className="font-bold text-md rounded-xl text-black dark:text-white p-3 px-7 bg-transparent"
                                >
                                    <span className=''>Annuler</span>
                                </button>
                            </div>
                        </div>
                    )}

                </div>
            </div>
        </>
    )
}

export default PlaylistPage
