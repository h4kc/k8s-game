import React, { useEffect, useState } from "react"
import { useDispatch, useSelector } from "react-redux"

import { useGetSourcesForUserQuery } from "../store/slices/sourceApiSlice"

import Table from "../components/Table"
import LeftNav from "../components/LeftNav"
import Panel from "../components/Panel"
import SearchBar from "../components/SeachBar"

import { AiOutlinePlus } from "react-icons/ai"

import useAuth from "../utils/useAuth"
import Options from "../shared/Options"
import { openPanel } from "../store/slices/uiSlice"
import DeleteConfimation from "../shared/DeleteConfimation"
import { GoDatabase } from "react-icons/go"
import { CgClose } from "react-icons/cg"
import { CiSearch } from "react-icons/ci"
import AlertElt from "../shared/AlertElt"


const Feed = () => {

  const dispatch = useDispatch()
  const isPanelOpen = useSelector(state => state.ui.panelShown)
  const [isSearchVisible, setIsSearchVisible] = useState(false)
  const [filteredItems, setFilteredItems] = useState([])
  const [sourceToUpdate, setSourceToUpdate] = useState()
  const [sourceToDelete, setSourceToDelete] = useState()
  const { isAdmin } = useAuth()

  const {
    data,
    isLoading,
    isSuccess,
    isError,
    error
  } = useGetSourcesForUserQuery({
    refetchOnFocus: true,
    refetchOnMountOrArgChange: true
  })

  let content
  if (isSuccess) {
    if (data?.sources.length > 0) {
      content =
        (<Table
          items={filteredItems}
          setItemToUpdate={setSourceToUpdate}
          setItemToDelete={setSourceToDelete}
        />)
    } else {
      content =
        (<div className="flex h-full items-center justify-center w-full bg-white dark:bg-black">
          <div className="text-center">
            <div className="inline-flex rounded-full bg-purple-100 dark:bg-[#7b3c7e] p-4">
              <div className="rounded-full stroke-purple-600 bg-purple-200 dark:bg-[#c62cb9] p-4">
                <GoDatabase size={54} />
              </div>
            </div>
            <p className="text-slate-600 dark:text-gray-200 mt-5 lg:text-xl">
              Pas de Source disponible pour le moment.
            </p>
          </div>
        </div>)
    }
  } else if (isError) {
    console.log(error)
  }

  useEffect(() => {
    if (isSuccess) {
      setFilteredItems(data?.sources)
    }
    //eslint-disable-next-line
  }, [data?.sources])

  return (

    <div>
      <LeftNav />
      <Options />
      <AlertElt />
      <DeleteConfimation
        itemToDelete={sourceToDelete}
        setItemToDelete={setSourceToDelete}
      />
      <div className="flex float-right w-[calc(100%-240px)] h-[calc(100vh-64px)] p-9 bg-white dark:bg-black">
        {isError
          ?
          <div className="flex h-full items-center justify-center p-5 w-full bg-white dark:bg-black">
            <div className="text-center">
              <div className="inline-flex rounded-full bg-red-100 dark:bg-red-900 p-4">
                <div className="rounded-full stroke-red-600 bg-red-200 dark:bg-red-700 p-4">
                  <CgClose size={54} />
                </div>
              </div>
              <h1 className="mt-5 text-[36px] font-bold text-slate-800 dark:text-gray-300 lg:text-[50px]">Erreur</h1>
              <p className="text-slate-600 dark:text-gray-400 mt-5 lg:text-lg">
                Ressource indisponible pour le moment.
                  
                <br /> Essayez de rafraîchir la page.
              </p>
            </div>
          </div>
          : isLoading
            ? <div className="flex h-full w-full items-center justify-center bg-white dark:bg-black text-black dark:text-white">
              <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 
                    border-solid border-current border-r-transparent -mt-1.5 animate-spin-slow">
              </div>
            </div>
            :
            <>
              {isPanelOpen &&
                (<div className={`fixed top-0 left-0 w-screen h-screen bg-transparent transition-opacity ${isPanelOpen
                  ? "opacity-100 visible z-50"
                  : "opacity-0 invisible "
                  }`} style={{ backdropFilter: "blur(5px)" }}
                ></div>)
              }
              <div className="grow flex flex-col items-center overflow-y-auto no-scrollbar">
                {(isPanelOpen && isAdmin) &&
                  <Panel
                    itemToUpdate={sourceToUpdate}
                    setItemToUpdate={setSourceToUpdate}
                  />
                }

                <div className="flex justify-between text-black dark:text-white w-full mb-5">
                  <h1 className="bg-[#00000016] dark:bg-gray-900 border border-gray-400 dark:border-gray-400 p-3 px-20 inline-block rounded-[7px] text-lg">
                    Liste des sources
                  </h1>
                  <div className="flex justify-end">

                    {!isSearchVisible &&
                      <button
                        onClick={() => { setIsSearchVisible(true) }}
                        className="hover:bg-blue-100 dark:hover:bg-blue-900 border border-[#c8c8c8] dark:border-[#6b6b6b] text-black dark:text-white p-3 mt-3 inline-block rounded-[500px] text-sm">
                        <div className="flex items-center">
                          <CiSearch size={18} />
                        </div>
                      </button>}
                    {isSearchVisible &&
                      <SearchBar
                        items={data.sources}
                        setFilteredItems={setFilteredItems}
                        setIsSearchVisible={setIsSearchVisible}
                      />}

                    {isAdmin &&
                      <button
                        onClick={() => { dispatch(openPanel()) }}
                        className="bg-blue-600 hover:bg-blue-400 text-white dark:text-black px-3 mt-3 ml-5 inline-block rounded-xl text-sm">
                        <div className="flex items-center">
                          <AiOutlinePlus className="mr-2" />
                          <span>Créer</span>
                        </div>
                      </button>
                    }
                  </div>
                </div>
                {content}
              </div>
            </>}
      </div>
    </div >
  )
}

export default Feed
