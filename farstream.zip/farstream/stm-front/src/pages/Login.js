import React, { useCallback, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useDispatch } from 'react-redux'

import { useLoginMutation } from '../store/slices/authApiSlice'
import { setCredentials } from '../store/slices/authSlice'
import { useEffect } from 'react'
import { FaEye, FaEyeSlash } from 'react-icons/fa'
import AlertElt from '../shared/AlertElt'
import { openErrorAlert, setAlertMsg } from '../store/slices/uiSlice'

const Login = () => {
    const [userName, setUserName] = useState("")
    const [passWord, setPassWord] = useState("")
    const [isPasswordVisible, setIsPasswordVisible] = useState(false)
    const navigate = useNavigate()
    const dispatch = useDispatch()
    const [login, { isLoading, isSuccess }] = useLoginMutation()

    const fillCondition = userName !== "" && passWord !== ""; // Condition pour activer le bouton Se connecter

    const togglePasswordVisiblity = () => {
        setIsPasswordVisible(prev => !prev)
    }

    const connectHandler = useCallback(async () => {
        if (fillCondition) {
            try {
                const { accessToken, refreshToken } = await login({ username: userName, password: passWord }).unwrap();
                dispatch(setCredentials({ accessToken }))
                localStorage.setItem('refreshTo', refreshToken)
                setUserName('')
                setPassWord('')
                setTimeout(() => {
                    navigate('/')
                }, 3000)
            } catch (err) {
                if (err.status === 'FETCH_ERROR') {
                    dispatch(setAlertMsg(`La connexion au serveur a échoué. Veuillez réessayer plus tard.`))
                } else {
                    if (err.data.message) dispatch(setAlertMsg(err.data.message))
                    else if (err.data) dispatch(setAlertMsg(err.data))
                }
                dispatch(openErrorAlert())
            }
        }
        //eslint-disable-next-line
    }, [userName, passWord, fillCondition]);

    useEffect(() => {
        const enter = (event) => {
            if (event.key === 'Enter') {
                event.preventDefault();
                connectHandler(event);
            }
        };
        window.addEventListener('keydown', enter);
        return () => {
            window.removeEventListener('keydown', enter);
        }
    }, [connectHandler]);


    // Classes de style pour les champs de saisie
    const inputClasses = `
    peer placeholder-transparent h-10 w-full border-0 border-b-2 border-gray-300 
    bg-transparent text-black dark:text-white focus:outline-none 
    focus:border-blue-600 focus:ring-0
  `;

    // Classes de style pour les étiquettes des champs de saisie
    const labelClasses = `
    absolute left-0 -top-3.5 text-gray-600 dark:text-gray-300 text-sm 
    peer-placeholder-shown:text-base peer-placeholder-shown:text-gray-440
    peer-placeholder-shown:top-2 transition-all
    peer-focus:-top-3.5 peer-focus:text-gray-600 peer-focus:dark:text-gray-300 peer-focus:text-sm
  `;

    // Classes de style pour le bouton Se connecter
    const buttonClasses = `
    px-4 py-3 mt-10 border dark:border-gray-600 bg-gray-200 text-gray-400 
    dark:bg-gray-600 dark:text-gray-400  rounded-xl 
    ${fillCondition ? 'active:scale-90 duration-100 will-change-transform overflow-hidden relative !bg-[#0ef8] text-white dark:!text-black' : ''}
  `;
    return (
        <>
            <AlertElt />
            <div className="h-[calc(100vh-64px)] w-full bg-gray-100 text-black dark:bg-[#080108] dark:text-gray-100 flex flex-col justify-center">
                <div className="relative md:w-6/12 py-3 sm:max-w-xl sm:mx-auto">
                    <div className={`z-20 relative px-2 pt-16 pb-10 bg-transparent text-black border dark:border-gray-600
                       dark:text-white shadow-[1px_25px_40px_10px] dark:shadow-[1px_25px_40px_10px] shadow-[#aef8] dark:shadow-[#aef8] sm:rounded-3xl`}>
                        <div className="max-w-md mx-auto">
                            <div>
                                <h1 className={`text-2xl font-semibold text-center transition-tranform duration-1000 
                            ${isSuccess && "translate-y-32 text-3xl"}`}>
                                    Bienvenue
                                </h1>
                            </div>
                            <div className="divide-y divide-gray-200 translate-y-4">
                                <div className={`py-6 text-base leading-6 space-y-4 text-gray-700 sm:text-lg sm:leading-7
                               opacity-100 transition-opacity duration-500
                              ${isSuccess ? "!opacity-0" : ""}`}>
                                    <div className="relative mb-8">
                                        <input
                                            autoComplete="off"
                                            type="text"
                                            id="username"
                                            value={userName}
                                            onChange={(e) => setUserName(e.target.value)}
                                            className={inputClasses}
                                            placeholder=""
                                        />
                                        <label
                                            htmlFor="username"
                                            className={labelClasses}
                                        >
                                            Nom d'utilisateur
                                        </label>
                                    </div>
                                    <div className="relative">
                                        <input
                                            autoComplete="off"
                                            type={isPasswordVisible ? 'text' : 'password'}
                                            id="password"
                                            value={passWord}
                                            onChange={(e) => setPassWord(e.target.value)}
                                            className={inputClasses}
                                            placeholder=""
                                        />

                                        <label
                                            htmlFor="password"
                                            className={labelClasses}
                                        >
                                            Mot de passe
                                        </label>
                                        {passWord && (
                                            <div
                                                className="absolute right-3 top-[10px] cursor-pointer text-black dark:text-white"
                                                onClick={togglePasswordVisiblity}
                                            >
                                                {isPasswordVisible
                                                    ? <FaEye className="text-xl" />
                                                    : <FaEyeSlash className="text-xl" />}
                                            </div>
                                        )}
                                    </div>
                                    <div className="relative text-center">
                                        <button
                                            onClick={connectHandler}
                                            disabled={!fillCondition}
                                            className={buttonClasses}
                                        >
                                            <div className="flex items-center">
                                                <span>Se connecter</span>
                                                {isLoading && (
                                                    <div className="inline-block h-8 w-8 ml-3 animate-spin rounded-full border-4 
                                        border-solid border-current border-r-transparent -mt-1.5 animate-spin-slow"></div>
                                                )}
                                            </div>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>

    )
}

export default Login
