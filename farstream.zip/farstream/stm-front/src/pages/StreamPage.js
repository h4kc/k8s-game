import React, { useEffect, useState, useCallback } from "react"
import { useSelector, useDispatch } from 'react-redux'


// import ReactPlayer from "react-player"

import { MdFitScreen } from "react-icons/md"
import { CgClose, CgMediaLive } from "react-icons/cg"

import SuggestionVideoCard from "../components/SuggestionVideoCard"
import LeftNav from "../components/LeftNav"
import SideMenu from "../components/SideMenu"
import VideoContainer from "../components/VideoContainer"
import { useGetStreamForUserQuery } from "../store/slices/streamApiSlice"
import useWindowFocus from "use-window-focus"
import Options from "../shared/Options"
import { toggleWideView } from "../store/slices/uiSlice"
import { GoDatabase } from "react-icons/go"
import AlertElt from "../shared/AlertElt"
import { AiOutlineLoading3Quarters } from "react-icons/ai"


const StreamPage = () => {

  const isWideView = useSelector((state) => state.ui.wideView)
  const isLeftNavOpen = useSelector((state) => state.ui.leftNav)
  const dispatch = useDispatch()
  const [streamObject, setStreamObject] = useState()
  const [streamCount, setStreamCount] = useState(1)
  const [streamsInGrid, setStreamsInGrid] = useState()
  const [streamsInSideMenu, setStreamsInSideMenu] = useState()
  const [otherStreams, setOtherStreams] = useState()
  const [remainCount, setRemainCount] = useState(0)

  //normally i use it to control side menu opening, it control the refeching too
  const [sideMenuIsOpen, setSideMenuIsOpen] = useState(false)

  //normally i use it to control side menu opening, it control the refeching too
  const [canRefetch, setCanRefetch] = useState(true)


  const windowFocused = useWindowFocus()
  const {
    data: streams,
    isSuccess,
    isError,
    error
  } = useGetStreamForUserQuery({
    pollingInterval: canRefetch ? 5000 : 0,
    // refetchOnFocus: true,
    // refetchOnMountOrArgChange: true
  })
  // if we want ro control broadcast start/stop
  // const [updateBroadcastStatus, { isLoading: broadcastLoading }] = useUpdateBroadcastStatusMutation()

  useEffect(() => {
    if (isSuccess) {
      setStreamObject(streams)
    }

    // console.log(streams)
    // eslint-disable-next-line
  }, [streams])

  useEffect(() => {
    if (sideMenuIsOpen) {
      setCanRefetch(false)
    } else {
      setCanRefetch(true)
    }
    // eslint-disable-next-line
  }, [sideMenuIsOpen])

  useEffect(() => {
    if (streamObject) {
      const streamsWithIndex = streamObject.map((stream, index) => ({ ...stream, originalIndex: index }))
      const [firstStream, ...restStreams] = streamsWithIndex
      setStreamsInSideMenu(streamsWithIndex)

      if (streamsInGrid && otherStreams) {
        // Retrieve stream IDs from StreamsInGrid and OtherStreams
        const streamsInGridIds = streamsInGrid.map(stream => stream?.streamId)
        const otherStreamsIds = otherStreams.map(stream => stream?.streamId)

        // Replace streams with updated ones from streamObject
        const updatedStreamsInGrid = streamsWithIndex.filter(stream => streamsInGridIds.includes(stream?.streamId))
        const updatedOtherStreams = streamsWithIndex.filter(stream => otherStreamsIds.includes(stream?.streamId))

        setStreamsInGrid(updatedStreamsInGrid)
        setOtherStreams(updatedOtherStreams)
      } else {
        // If StreamsInGrid and OtherStreams are empty, do the initial setup
        setStreamsInGrid([firstStream])
        setOtherStreams(restStreams)
      }
    }
    // eslint-disable-next-line
  }, [streamObject])

  useEffect(() => {
    setStreamCount(streamsInGrid?.length)
    setRemainCount(otherStreams?.length)
  }, [streamsInGrid, otherStreams])

  const addStreamToGrid = (streamToAdd) => {
    if (streamsInGrid.length < 16) {
      setStreamsInGrid(prev => [...prev, streamToAdd].sort((a, b) => a.originalIndex - b.originalIndex))
      setOtherStreams(prev => prev.filter(stream => stream?.streamId !== streamToAdd.streamId))
    }
  }

  const deleteFromGrid = (streamToRemove) => {
    if (streamsInGrid.length > 1) {
      setStreamsInGrid(prev => prev.filter(stream => stream?.streamId !== streamToRemove.streamId))
      setOtherStreams(prev => [...prev, streamToRemove].sort((a, b) => a.originalIndex - b.originalIndex))
    }
  }

  const setGridToOneStream = (streamToKeep) => {
    // Add the streams currently in the grid to the otherStreams 
    const remainingGridStreams = streamsInGrid.filter(stream => stream.streamId !== streamToKeep.streamId)
    setOtherStreams(prev => [...prev, ...remainingGridStreams].sort((a, b) => a.originalIndex - b.originalIndex))

    // Set the grid to contain only the provided stream
    setStreamsInGrid([streamToKeep])
  }

  // if we want ro control broadcast start/stop

  // const handleBroadcast = async (id, broadcastStatus) => {
  //   try {
  //     let response
  //     if (broadcastStatus === "broadcasting") {
  //       dispatch(openSuccessAlert())
  //       dispatch(setAlertMsg(`le stream va s'arreter dans quelque secondes. Veuillez ne pas répéter l'opération.`))
  //       response = await updateBroadcastStatus({ id, action: "stop" })
  //       console.log(response)
  //     } else {
  //       dispatch(setAlertMsg(`le stream va se lancer dans quelque secondes. Veuillez ne pas répéter l'opération.`))
  //       dispatch(openSuccessAlert())
  //       response = await updateBroadcastStatus({ id, action: "start" })
  //       console.log(response)
  //     }
  //   } catch (err) {
  //     console.error(err)
  //     dispatch(setAlertMsg(`Erreur lors ${broadcastStatus === "broadcasting" ? "de l'arrêt" : "du lancement"} du stream.`))
  //     dispatch(openErrorAlert())
  //   }
  // }

  const toggleFullscreen = useCallback(() => {
    dispatch(toggleWideView())
    if (!isWideView) {
      document.body.requestFullscreen()
    } else {
      if (document.fullscreenElement) {
        document.exitFullscreen()
      }
    }
  }, [isWideView, dispatch])

  useEffect(() => {
    const handleKeyDown = (event) => {
      if (event.key === 'f') {
        event.preventDefault()
        toggleFullscreen()
      }
    }

    window.addEventListener('keyup', handleKeyDown)

    return () => {
      window.removeEventListener('keyup', handleKeyDown)
    }
  }, [toggleFullscreen])

  const handleViewClick = () => {
    toggleFullscreen()
  }


  return (
    <div className={`flex flex-row justify-center  overflow-hidden bg-white dark:bg-black 
          ${isWideView ? "" : ""}`}>

      {/* ce div est utilise comme une couche qui covre l'ecran quand la leftNav est ouverte */}
      <div className={`fixed top-0 left-0 w-screen h-screen bg-transparent transition-opacity ${isLeftNavOpen
        ? "dark:!bg-[#0f0f0f9e] opacity-100 visible z-50"
        : "opacity-0 invisible "
        }`}
        style={{
          backdropFilter: "blur(5px)"
        }}
      ></div>

      <LeftNav />
      <Options />
      <AlertElt />
      <div className={`relative w-full h-[calc(100vh-64px)] flex flex-col transition-all duration-300 overflow-x-hidden lg:flex-row py-5 px-2
                      ${isWideView ? "!p-2 !h-screen" : ""}`}>
        {/* Error message */}
        {isError
          ? <div className="flex h-full items-center justify-center w-full bg-white dark:bg-black">
            <div className="text-center">
              <div className="inline-flex rounded-full bg-red-100 dark:bg-red-900 p-4">
                <div className="rounded-full stroke-red-600 bg-red-200 dark:bg-red-700 p-4">
                  <CgClose size={54} />
                </div>
              </div>
              <h1 className="mt-5 text-[36px] font-bold text-slate-800 dark:text-gray-300 lg:text-[50px]">Erreur</h1>
              <p className="text-slate-600 dark:text-gray-400 mt-5 lg:text-lg">
                Ressource indisponible pour le moment.

                <br /> Essayez de rafraîchir la page.
              </p>
            </div>
          </div>
          // waiting for AMS message 
          : !isSuccess
            ? <div className="flex h-full items-center justify-center w-full bg-white dark:bg-black">
              <div className="text-center">
                <div className="inline-flex rounded-full bg-purple-100 dark:bg-[#7b3c7e] p-4">
                  <div className="rounded-full stroke-purple-600 bg-purple-200 dark:bg-[#c62cb9] p-4">
                    <AiOutlineLoading3Quarters className="animate-spin" size={54} />
                  </div>
                </div>
                <p className="text-slate-600 dark:text-gray-200 mt-5 lg:text-xl">
                  En attente de la réponse du serveur Ant Media.
                </p>
              </div>
            </div>
            //  empty streams array message
            : !(streams?.length > 0)
              ? <div className="flex h-full items-center justify-center w-full bg-white dark:bg-black">
                <div className="text-center">
                  <div className="inline-flex rounded-full bg-purple-100 dark:bg-[#7b3c7e] p-4">
                    <div className="rounded-full stroke-purple-600 bg-purple-200 dark:bg-[#c62cb9] p-4">
                      <GoDatabase size={54} />
                    </div>
                  </div>
                  <p className="text-slate-600 dark:text-gray-200 mt-5 lg:text-xl">
                    Pas de Stream disponible pour le moment.
                  </p>
                </div>
              </div>
              : (
                <>
                  <SideMenu
                    sideMenuIsOpen={sideMenuIsOpen}
                    setSideMenuIsOpen={setSideMenuIsOpen}
                    handleViewClick={handleViewClick}
                    videosInSideMenu={streamsInSideMenu}
                    setOtherVideos={setOtherStreams}
                    setVideosInGrid={setStreamsInGrid}
                    videosInGrid={streamsInGrid}
                  />
                  <div className={`flex flex-col transition-all duration-300 no-scrollbar
                        ${isWideView ? "w-full" : "lg:w-[calc(100%-3px)] xl:w-[calc(100%-400px)]"} px-2 overflow-y-auto`}>

                    <div className={`transition-all duration-300 h-full lg:ml-0 mr-[-16px] lg:mr-0`}>
                        <VideoContainer
                          videoCount={streamCount}
                          videosInGrid={streamsInGrid}
                          deleteFromGrid={deleteFromGrid}
                          setGridToOneStream={setGridToOneStream}
                        // if we want ro control broadcast start/stop
                        // handleBroadcast={handleBroadcast}
                        // broadcastLoading={broadcastLoading}
                        />
                    </div>

                  </div>

                  <div className={`transition-all duration-300 
                        ${isWideView ? "w-0" : "flex flex-col px-4 lg:w-[350px] xl:w-[400px]"}`}>
                    {!isWideView &&
                      <div>
                        <div className=" w-full mb-3 px-2 py-2 flex justify-between items-center
                             text-black dark:text-white bg-purple-200 dark:bg-purple-900 rounded-lg">
                          <div className="flex items-center ">
                            <CgMediaLive className="text-xl ml-1 mr-2" />
                            <span>{remainCount !== 0 ? `Autres Streams (${remainCount})` : 'Autres Streams'}</span>
                          </div>

                          <div
                            title="Mode plein écran"
                            onClick={handleViewClick}
                            className="p-2 rounded-md hover:bg-black/[0.2] dark:hover:bg-[#ffe3e3]/[0.4] cursor-pointer">
                            <MdFitScreen className="text-[21px]" />
                          </div>

                        </div>
                        <div className={`h-[580px] overflow-y-auto no-scrollbar rounded-lg`}>
                          {
                            otherStreams?.map(stream => (
                              <SuggestionVideoCard
                                key={stream?.streamId}
                                video={stream}
                                addAction={addStreamToGrid}
                              />
                            ))
                          }
                        </div>
                      </div>
                    }
                  </div>
                </>)}
      </div>
    </div>
  )
}

export default StreamPage
