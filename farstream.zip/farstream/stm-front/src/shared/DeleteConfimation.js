import React from "react"
import { useDispatch, useSelector } from "react-redux"

import { PiSealWarningBold } from "react-icons/pi"
import { closeDeleteConfimation, openErrorAlert, openSuccessAlert, setAlertMsg } from "../store/slices/uiSlice"
import { useDeleteUserMutation } from "../store/slices/userApiSlice"
import { useDeleteSourceMutation } from "../store/slices/sourceApiSlice"
import { useDeleteVodMutation, useDeleteMultipleVodsMutation } from "../store/slices/vodApiSlice"


const DeleteConfimation = ({ userPage, vodPage, itemToDelete, setItemToDelete, handleGetVods, sourceToGetPlaylist }) => {

    const isdeleteConfimationOpen = useSelector((state) => state.ui.deleteConfimationShown)
    const [deleteSource, { isLoading: sourceDeleteLoading }] = useDeleteSourceMutation()
    const [deleteUser, { isLoading: userDeleteLoading }] = useDeleteUserMutation()
    const [deleteVod, { isLoading: vodDeleteLoading }] = useDeleteVodMutation()
    const [deleteVods, { isLoading: vodsDeleteLoading }] = useDeleteMultipleVodsMutation()
    const LoadingFinished = !sourceDeleteLoading && !userDeleteLoading && !vodDeleteLoading && !vodsDeleteLoading

    const dispatch = useDispatch()

    const sendDelete = async (item) => {
        if (!item) return
        try {
            // in user page we use deleteUser in vodPage if we have an array we use deleteVods for multiple delete or deleteVod for single delete in the last case if we aren't in userPage nor vodPage we use deleteSource
            const deleteFunction =
                userPage
                    ? deleteUser
                    : vodPage
                        ? Array.isArray(item)
                            ? deleteVods
                            : deleteVod
                        : deleteSource
            // with same logic we change parameter of delete fct (for vods if we have an array we send it, if not we send vodId) (for users and sources we send id)
            await deleteFunction(vodPage ? Array.isArray(item) ? item : item.vodId : item.id).unwrap()
            if (LoadingFinished) {
                setItemToDelete()
                if (vodPage) handleGetVods(sourceToGetPlaylist)
                dispatch(closeDeleteConfimation())
                dispatch(setAlertMsg(`${userPage ? "Utilisateur supprimé" : vodPage ? Array.isArray(item)
                ? "Sauvegardes supprimées" : "Sauvegarde supprimée" : "Source supprimée"} avec succès.`))
                dispatch(openSuccessAlert())
            }
        } catch (err) {
            console.error(err)
            dispatch(setAlertMsg(`Erreur lors de la suppression de ${userPage ? "l'utilisateur." : vodPage ? "la sauvegarde." : "la source."}`))
            dispatch(openErrorAlert())
        }
    }

    const buttonClasses = `font-bold text-md bg-red-600 rounded-xl text-white dark:text-black p-3 px-7 border border-transparent hover:bg-transparent hover:border-red-600 hover:text-red-600 dark:hover:text-red-600 focus:outline-none focus:ring-2 focus:ring-red-600 dark:focus:ring-red-900 `

    return (
        <>
            {/* div for blury background */}
            {isdeleteConfimationOpen && (<div className={`fixed top-0 left-0 w-screen h-screen bg-transparent transition-opacity  opacity-100 visible z-[60] dark:!bg-[#0f0f0f9e]`} style={{ backdropFilter: "blur(5px)" }}
            ></div>)}

            {isdeleteConfimationOpen && (
                <div className={`z-[62] absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-[#ffffff] dark:bg-[#39163d85] rounded-2xl shadow-2xl w-[400px] max-h-[510px] p-7`}
                    style={{
                        backdropFilter: "blur(40px)"
                    }}>
                    <h3 className="flex items-center justify-center">
                        <PiSealWarningBold className="text-[100px] text-yellow-400 dark:text-yellow-800" />
                    </h3>
                    <div className="w-full flex flex-col text-black dark:text-white ">
                        <p className="text-center flex flex-col py-4 mb-5">
                            <span>{`Vous voulez vraiment confirmer la suppression ${Array.isArray(itemToDelete) ? "des" : "de"}
                            ${userPage
                                    ? "'" + itemToDelete.username + "'"
                                    : vodPage
                                        ? Array.isArray(itemToDelete)
                                            ? "sauvegardes"
                                            : "la sauvegarde"
                                        : "'" + itemToDelete.name + "'"} ?`} </span>
                            <span>Cette action est irreversible.</span>
                        </p>
                        <div className="flex items-center justify-center">
                            <button
                                type="button"
                                onClick={() => { sendDelete(itemToDelete) }}
                                className={buttonClasses + 'flex items-center'}
                                disabled={false}
                            >
                                <span className=''>Oui, Supprimer</span>
                                {!LoadingFinished && (
                                    <div className="h-7 w-7 ml-3 animate-spin rounded-full border-4 
                                        border-solid border-current border-r-transparent animate-spin-slow"></div>
                                )}
                            </button>
                            <button
                                type="button"
                                onClick={() => { dispatch(closeDeleteConfimation()) }}
                                className="font-bold text-md rounded-xl text-black dark:text-white p-3 px-7 bg-transparent"
                            >
                                <span className=''>Annuler</span>
                            </button>
                        </div>
                    </div>
                </div>
            )}


        </>
    )
}

export default DeleteConfimation

