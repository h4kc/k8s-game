
import React from "react"

const Dropdown = ({ items, light, leftnav, refelmt, isStreamPage, PlaylistItem }) => {
    return (
        <div
            ref={refelmt}
            className={`absolute z-[31] bg-white dark:bg-opacity-10 bg-opacity-10 border rounded-md 
                ${leftnav ? "!w-[216px] bottom-[120px] left-3 bg-[#b8b4b437] border-[#8e5c8e]" : "top-9 right-1"}
                ${isStreamPage && "!w-[236px] bottom-[60px]"}
                ${PlaylistItem && "!border-gray-400"}
                ${light ? "text-black dark:!text-white border-gray-200 dark:!border-gray-600" : "text-white border-gray-600"}`}
            style={{
                backdropFilter: "blur(20px)", // Adjust the blur intensity as needed
                backgroundColor: !light ? "rgba(0, 0, 0, 0.4)" : "initial" // Adjust background color and opacity
            }}>
            <ul>
                {items.map((item, index) => (
                    <li
                        key={index}
                        className={`flex items-center px-2 py-2 cursor-pointer text-[13px] ${light ? "hover:bg-[#0000002d] dark:hover:bg-[#ffffff2d]" : "hover:bg-[#ffffff2d]"}  hover:rounded-md`}
                        onClick={item.action}
                    >
                        {item.icon && (<span className="mr-3 text-[21px]">{item.icon}</span>)}
                        <span>{item.value}</span>
                        {item.loading && (
                            <div className="h-6 w-6 ml-11 animate-spin rounded-full border-4 
                                        border-solid border-current border-r-transparent animate-spin-slow"></div>
                        )}

                    </li>
                ))}
            </ul>
        </div>
    )
}

export default Dropdown


