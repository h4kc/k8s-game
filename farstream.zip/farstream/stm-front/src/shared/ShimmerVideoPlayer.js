import React from "react";

const ShimmeVideoPlayer = () => {
  return (
    <div className="w-full h-full bg-slate-400/[0.4] rounded-md">
      
    </div>
  );
};

export default ShimmeVideoPlayer;
