import React from "react"
import { Link } from "react-router-dom"
import { useSelector, useDispatch } from 'react-redux'


import { SlMenu } from "react-icons/sl"
import { CgClose } from "react-icons/cg"
import { toggleLeftNav } from "../store/slices/uiSlice"
import useAuth from "../utils/useAuth"

const Logo = ({ isLoginPage, isStreamPage, leftNav}) => {

    const isLeftNavOpen = useSelector((state) => state.ui.leftNav)
    const dispatch = useDispatch()
    const { isAdmin } = useAuth()

    const handleToggleLeftNav = (event) => {
        event.stopPropagation()
        dispatch(toggleLeftNav())
    }

    return (
        <div className="flex h-5 items-center">
            {!isLoginPage && (
                <div
                    onClick={handleToggleLeftNav}
                    className={`flex h-10 w-10 justify-center items-center rounded-full ${isStreamPage ? "" : "md:hidden"} md:mr-1 cursor-pointer hover:bg-[#303030]/[0.6]`}
                >
                    {isLeftNavOpen ? (
                        <CgClose className="text-black dark:text-white text-xl" />
                    ) : (
                        <SlMenu className="text-black dark:text-white text-xl" />
                    )}
                </div>
            )}

            <Link to="/" className="flex h-5 items-center hover:blur-[0.95px]">
                <span className={`text-[#3a3a3a] dark:text-[#aef8] text-2xl ml-2 font-extrabold hover:opacity-85`}>{`Steam simple ${isAdmin && !leftNav ? "- Admin" : ""}`}</span>
            </Link>
        </div>
    )
}

export default Logo

