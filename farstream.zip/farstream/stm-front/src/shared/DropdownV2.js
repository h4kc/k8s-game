import React, { useState, useEffect } from "react"

const DropdownV2 = ({ isAdmin, vodPage, allSources, handleRoleClick, handleProtocolClick, handleGetVods, setIsSourceListVisible, setSourceIds, isSourceListVisible, isRoleListVisible, isProtocolListVisible, panelData }) => {

    const [checkedSources, setCheckedSources] = useState({})

    const toggleCheck = (e, sourceId) => {
        setCheckedSources(prev => ({
            ...prev,
            [sourceId]: !prev[sourceId]
        }))
    }

    const handlelistItemClick = async (source) => {
        setIsSourceListVisible(false)
        handleGetVods(source)
    }

    useEffect(() => {

        const initialCheckedSources = {}

        if (panelData && Array.isArray(panelData.sources)) {
            panelData.sources.forEach(source => { initialCheckedSources[source] = true })
        }
        setCheckedSources(initialCheckedSources)

    }, [panelData])

    useEffect(() => {
        const keysWithTrueValue = Object.keys(checkedSources)
            .filter(key => checkedSources[key] === true)
            .map(Number)
        if (setSourceIds) {
            setSourceIds(keysWithTrueValue)
        }
        return () => {
            if (setSourceIds) {
                setSourceIds({})
            }
        }
        //eslint-disable-next-line
    }, [checkedSources])

    return (
        <>
            {(isRoleListVisible) && (
                <div className="z-[30] absolute flex flex-col w-full top-10 text-sm dark:bg-white bg-gray-200
                             text-black dark:!text-white border !border-gray-300 dark:!border-gray-600 overflow-y-auto
                                rounded-lg dark:bg-opacity-10 bg-opacity-10"
                    style={{ backdropFilter: "blur(70px)" }}>
                    <span className="w-full cursor-pointer p-3 rounded-lg hover:bg-gray-100/[0.1]"
                        onClick={(e) => { handleRoleClick(e, "viewer") }}>Viewer</span>
                    <span className="w-full cursor-pointer p-3 rounded-lg hover:bg-gray-100/[0.1]"
                        onClick={(e) => { handleRoleClick(e, "recorder") }}>Recorder</span>
                </div>)}
            {(isProtocolListVisible) && (
                <div className="z-[30] absolute flex flex-col w-full top-10 text-sm dark:bg-white bg-gray-200
                             text-black dark:!text-white border !border-gray-300 dark:!border-gray-600 overflow-y-auto
                                rounded-lg dark:bg-opacity-10 bg-opacity-10"
                    style={{ backdropFilter: "blur(70px)" }}>
                    <span className="w-full cursor-pointer p-3 hover:bg-gray-100/[0.1] border-b border-gray-300 dark:border-gray-600"
                        onClick={(e) => { handleProtocolClick(e, "RTSP") }}>RTSP</span>
                    <span className="w-full cursor-pointer p-3 rounded-lg hover:bg-gray-100/[0.1]"
                        onClick={(e) => { handleProtocolClick(e, "RTMP") }}>RTMP</span>
                </div>)}
            {(isSourceListVisible) && (
                <div
                    className="z-[35] absolute flex flex-col max-h-[200px] top-11 right-0 left-0 text-sm dark:bg-white bg-gray-200
                             text-black dark:!text-white border border-gray-400 dark:border-gray-400 overflow-y-auto
                                rounded-lg dark:bg-opacity-10 bg-opacity-10 no-scrollbar"
                    style={{
                        backdropFilter: "blur(60px)",
                    }}>
                    <ul className="w-full mx-auto text-sm font-medium">
                        {(vodPage && isAdmin) && (
                            <div
                                className="z-[40] w-full border-b border-gray-300 dark:border-gray-600 rounded-sm hover:bg-gray-100/[0.1] text-[15px] p-3 font-medium cursor-pointer"
                                onClick={() => { handlelistItemClick("allVods") }}>
                                toutes les sources
                            </div>
                        )}
                        {allSources?.sources?.length > 0
                            ? (allSources.sources.map((source) => (
                                (vodPage
                                    ? <div
                                        key={source.id}
                                        className="z-[40] w-full border-b border-gray-300 dark:border-gray-600 rounded-sm hover:bg-gray-100/[0.1] text-[15px] p-3 font-medium cursor-pointer"
                                        onClick={() => { handlelistItemClick(source) }}>
                                        {source.name}
                                    </div>
                                    : <li
                                        key={source.id}
                                        className="z-[40] w-full border-b border-gray-300 dark:border-gray-600 rounded-sm hover:bg-gray-100/[0.1]"
                                    >
                                        <div className="flex items-center pl-3">
                                            <input
                                                id={`${source.id}-checkbox`}
                                                type="checkbox"
                                                checked={!!checkedSources[source.id]}
                                                onChange={(e) => toggleCheck(e, source.id)}
                                                className="w-4 h-4 text-blue-600 bg-gray-100 dark:bg-gray-500 border-gray-300 rounded shadow-sm shadow-purple-500 cursor-pointer"
                                            />
                                            <label
                                                htmlFor={`${source.id}-checkbox`}
                                                className="z-[47] text-[15px] w-full py-3 ml-2 font-medium cursor-pointer"
                                            >
                                                {source.name}
                                            </label>
                                        </div>
                                    </li>))))
                            : (
                                <li className="text-gray-500 dark:text-gray-400 py-3 pl-3">
                                    aucune source disponuble.
                                </li>
                            )}
                    </ul>
                </div>)}
        </>
    )
}

export default DropdownV2


