import React, { useEffect } from "react"

const CheckBoxList = ({ videolist, isAllSelected, checkedVideos, setCheckedVideos }) => {

    useEffect(() => {
        const updatedCheckedVideos = {}
        videolist.forEach(video => {
            updatedCheckedVideos[video.streamId] = isAllSelected
        })
        setCheckedVideos(updatedCheckedVideos)
        // console.log(checkedVideos)
        // eslint-disable-next-line
    }, [isAllSelected, videolist, setCheckedVideos])

    const toggleCheck = (videoId) => {
        setCheckedVideos(prev => ({
            ...prev,
            [videoId]: !prev[videoId]
        }))
    }

    return (
        <div className="w-full overflow-hidden">

            <ul className="w-[95%] mt-2 mx-auto text-sm font-medium border border-gray-200 rounded-lg dark:border-gray-600 ">
                {videolist.map((video) => (
                    <li
                        key={video.streamId} // Make sure each video has a unique identifier (e.g., id)
                        className="w-full border-b border-gray-200 rounded-lg dark:border-gray-600 hover:bg-gray-100/[0.2]"
                    >
                        <div className="flex items-center pl-3">
                            <input
                                id={`${video.streamId}-checkbox`} // Use video.id for unique checkbox IDs
                                type="checkbox"
                                checked={!!checkedVideos[video.streamId]}
                                onChange={() => toggleCheck(video.streamId)}
                                className="w-4 h-4 text-blue-600 bg-gray-100 dark:bg-gray-500
                                 border-gray-300 rounded shadow-sm shadow-purple-500 cursor-pointer"
                            />
                            <label
                                htmlFor={`${video.streamId}-checkbox`} // Match the input's ID
                                className="w-full py-3 ml-2 text-sm font-medium cursor-pointer"
                            >
                                {video.name}
                            </label>
                        </div>
                    </li>
                ))}
            </ul>
        </div>
    )
}

export default CheckBoxList
