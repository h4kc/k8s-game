import React, { useCallback, useEffect, useRef } from "react"
import { useDispatch, useSelector } from "react-redux"

import { CiViewList } from "react-icons/ci"
import { PiGridNineFill } from "react-icons/pi"
import { MdDarkMode, MdOutlineLightMode } from "react-icons/md"
import { FiSettings } from "react-icons/fi"
import { closeOptions, setDefaultTheme, setLayout } from "../store/slices/uiSlice"


const Options = () => {

    const isOptionOpen = useSelector((state) => state.ui.optionShown)
    const localTheme = localStorage.getItem('theme')
    const stateTheme = useSelector((state) => state.ui.theme)
    const currentTheme = localTheme || stateTheme
    const currentLayout = useSelector((state) => state.ui.layout)
    const dispatch = useDispatch()
    const OptionsElement = useRef()

    const handleThemeChange = () => {
        dispatch(setDefaultTheme('dark'))
    }

    const handleLayoutClick = (layout) => {
        dispatch(setLayout(layout))
    }

    const CloseOptions = useCallback((event) => {

        const isOutsideOptions = !OptionsElement?.current?.contains(event.target)
        if (isOutsideOptions && isOptionOpen) {
            dispatch(closeOptions())
        }

        //eslint-disable-next-line
    }, [isOptionOpen])

    useEffect(() => {
        document.addEventListener('click', CloseOptions)
        return () => {
            document.removeEventListener('click', CloseOptions)
        }
    }, [CloseOptions])


    const buttonClasses = `font-bold text-md bg-blue-600 rounded-xl text-white dark:text-black p-3 px-7 border border-transparent hover:bg-transparent hover:border-blue-600 hover:text-blue-600 dark:hover:text-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-600 dark:focus:ring-blue-900 `

    return (
        <>
            {/* div for blury background */}
            {isOptionOpen && (<div className={`fixed top-0 left-0 w-screen h-screen bg-transparent transition-opacity  opacity-100 visible z-[60] dark:!bg-[#0f0f0f9e]`} style={{ backdropFilter: "blur(5px)" }}
            ></div>)}

            {isOptionOpen && (
                <div
                    ref={OptionsElement}
                    className={`z-[62] absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-[#ffffff] dark:bg-[#39163d85] rounded-2xl shadow-2xl dark:shadow-[#a2a2a2d2] md:min-w-[650px] max-h-[510px] p-7`}
                    style={{
                        backdropFilter: "blur(40px)"
                    }}>
                    <h3 className="flex items-center text-blue-500 text-[22px] font-bold text-left">
                        <><FiSettings className="pr-2 text-[34px]" />Options</>
                    </h3>
                    <div className="w-full flex p-5">
                        <div className="w-[50%] flex flex-col overflow-hidden ">
                            <p className="text-black dark:text-white text-lg font-bold p-4">
                                Thème par défaut
                            </p>
                            <p className="text-black dark:text-white text-lg font-bold p-4 py-6">
                                Aperçu des sauvegardes
                            </p>
                        </div>
                        <div className="w-[50%] flex flex-col overflow-hidden items-center">
                            <label className='themeSwitcherTwo relative inline-flex cursor-pointer select-none items-center p-4'>
                                <input
                                    type='checkbox'
                                    checked={currentTheme === 'dark'}
                                    onChange={handleThemeChange}
                                    className='sr-only'
                                />
                                <span className='label flex items-center text-sm font-medium text-black dark:text-white'>
                                    <><MdOutlineLightMode className="pr-1 text-2xl" />Clair</>
                                </span>
                                <span
                                    className={`slider mx-4 flex h-8 w-[60px] items-center rounded-full p-1 duration-200 ${currentTheme === 'dark' ? 'bg-[#212b36]' : 'bg-[#CCCCCE]'}`}>
                                    <span
                                        className={`dot h-6 w-6 rounded-full bg-white duration-200 ${currentTheme === 'dark' ? 'translate-x-[28px]' : ''}`}
                                    ></span>
                                </span>
                                <span className='label flex items-center text-sm font-medium text-black dark:text-white'>
                                    <><MdDarkMode className="pr-1 text-2xl" />Sombre</>
                                </span>
                            </label>
                            <label className='themeSwitcherTwo relative inline-flex cursor-pointer select-none items-center p-4'>
                                <span
                                    onClick={() => { handleLayoutClick("list") }}
                                    className={`label flex items-center text-sm font-medium text-black dark:text-white mr-3 rounded-2xl py-2 px-4 transition-[background-color] duration-200 border-black/[0.2] border dark:border dark:border-white/[0.2] ${currentLayout === "list" && 'bg-green-500'}`}>
                                    <><CiViewList className="pr-1 text-2xl" />Liste</>
                                </span>
                                <span
                                    onClick={() => { handleLayoutClick("grid") }}
                                    className={`label flex items-center text-sm font-medium text-black dark:text-white rounded-2xl py-2 px-4 transition-[background-color] duration-200 border-black/[0.2] border dark:border dark:border-white/[0.2] ${currentLayout === "grid" && 'bg-green-500'}`}>
                                    <><PiGridNineFill className="pr-1 text-2xl" />Grille</>
                                </span>
                            </label>
                        </div>
                    </div>
                    <div className="flex items-center justify-center">
                        <button
                            type="button"
                            onClick={() => { dispatch(closeOptions()) }}
                            className={buttonClasses + 'flex items-center'}
                        >
                            <span className=''>Confirmer</span>
                            {false && (
                                <div className="h-7 w-7 ml-3 animate-spin rounded-full border-4 
                                border-solid border-current border-r-transparent animate-spin-slow"></div>
                            )}
                        </button>
                    </div>
                </div>
            )}


        </>
    )
}

export default Options

