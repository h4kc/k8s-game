import { Alert } from "@material-tailwind/react"
import React, { useEffect } from "react"
import { closeSuccessAlert, closeErrorAlert, setAlertMsg } from "../store/slices/uiSlice"
import { useDispatch, useSelector } from "react-redux"
import { MdErrorOutline } from "react-icons/md"
import { FaRegCheckCircle } from "react-icons/fa"


const AlertElt = () => {

    const dispatch = useDispatch()
    const isSuccessAlertOpen = useSelector((state) => state.ui.successAlertShown)
    const isErrorAlertOpen = useSelector((state) => state.ui.errorAlertShown)
    const alertMsg = useSelector((state) => state.ui.alertMsg)


    useEffect(() => {
        if (isSuccessAlertOpen || isErrorAlertOpen) {
            setTimeout(() => {
                dispatch(closeSuccessAlert())
                dispatch(closeErrorAlert())
                dispatch(setAlertMsg(""))
            }, 3000)
        }
        // eslint-disable-next-line
    }, [isSuccessAlertOpen, isErrorAlertOpen])

    let alertColors
    const successColors = ` border-[#0e9451] bg-[#98f0a5] text-[#0e9451] dark:bg-[#33bf4877] dark:text-[#5bfe73] dark:border-[#5bfe73]`
    const errorColors = `border-[#f91b1b] bg-[#ffc4c4] text-[#f91b1b] dark:border-[#ff3e3ee1] dark:bg-[#ad3c3c8d] dark:text-[#fc8080e1] `
    // const warningColors = ` border-[#f8fc05] bg-[#f8faa0] text-[#f8fc05] `
    // const infoColors = ` border-[#2e86c9] bg-[#8cc5f0] text-[#2e86c9] `

    if (isSuccessAlertOpen) {
        alertColors = successColors
    } else if (isErrorAlertOpen) {
        alertColors = errorColors
    }


    return (
        <Alert
            open={isSuccessAlertOpen || isErrorAlertOpen}
            icon={isErrorAlertOpen ? <MdErrorOutline className="text-2xl" /> : <FaRegCheckCircle className="text-2xl" />}
            className={`alert absolute z-[100] top-20 w-auto right-9 rounded-none border-l-4 font-medium ${alertColors}`}
            animate={{
                mount: {
                  translateY: ['-30px', '0px'],
                  transition: { duration: 0.7 } 
                },
                unmount: {
                  translateY: ['0px', '-30px'],
                  transition: { duration: 0.7 } 
                }
              }}
            style={{
                backdropFilter: "blur(30px)", 
            }}>

            {alertMsg} 

        </Alert>
    )
}

export default AlertElt
