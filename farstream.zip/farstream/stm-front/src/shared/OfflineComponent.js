import React from "react";
import { BiError } from "react-icons/bi";

const OfflineComponent = () => {
  return (
    <section className="grow flex items-center sm:p-16 text-gray-600 bg-white dark:bg-black dark:text-white">
      <div className="container flex flex-col items-center justify-center px-5 mx-auto text-center sm:max-w-md">
        <BiError
          className="w-40 h-40 text-gray-300 dark:text-gray-600 "
        />
         
        <p className="text-3xl">
          IL semble qu'il y a une erreur de connection, verifier la connection au reseau
        </p>
        <p>Essayez de:</p>
        <ul>
          <li>
            Verifier <span className="text-purple-500">Les cables</span>
          </li>
          <li>
            Redemarer votre  <span className="text-purple-500">ordinateur</span> ou{" "}
            <span className="text-purple-500">tablette</span>
          </li>
        </ul>
      </div>
    </section>
  );
};

export default OfflineComponent;
