import React from 'react';

function generateRandomNumber(min, max) {
  return Math.floor(Math.random() * (max - min + 1) + min);
}

function getRandomBubbleStyle() {
  const size = generateRandomNumber(20, 80); // Random size between 20px and 80px
  const delay = generateRandomNumber(0, 30); // Random delay between 0s and 30s

  return `
    w-${size}
    h-${size}
    animate-spin
    animate-delay-${delay}
    rounded-lg  // Apply border-radius to create squares with rounded corners
    bg-opacity-20
    absolute
    bottom-0
  `;
}

const Bubbles = () => {
  const numBubbles = 20; // Number of bubbles you want

  const bubbleElements = Array.from({ length: numBubbles }, (_, index) => (
    <li key={index} className={`bg-white ${getRandomBubbleStyle()}`}></li>
  ));

  return (
    <ul className="bg-bubbles w-full h-90vh">
      {bubbleElements}
    </ul>
  );
};

export default Bubbles;

