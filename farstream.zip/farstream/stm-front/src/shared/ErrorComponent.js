import React from "react";
import { Link } from "react-router-dom";
import {TbError404} from "react-icons/tb";



const ErrorComponent = () => {
  // const err = useRouteError();

  return (
    <section className="flex items-center h-[calc(100vh-64px)] p-16 bg-gray-100 text-gray-900 dark:bg-gray-900 dark:text-gray-100">
      <div className="container flex flex-col items-center justify-center px-5 mx-auto my-8">
        <div className="max-w-md text-center">
          <div className="flex justify-center items-center mb-8 font-extrabold text-9xl text-center text-gray-600"><TbError404 /></div>
            
          <p className="text-2xl font-semibold md:text-3xl">
          Désolé, nous n'avons pas pu trouver cette page.
          </p>
          {/* <p className="mt-4 mb-8 text-gray-400">{err?.error?.message}</p> */}
          <p className="mt-4 mb-8 text-gray-400">
          vous inquiétez pas, vous pouvez continuer votre navigation sur la page d'accueil.
          </p>
          <Link
            rel="noopener noreferrer"
            to="/"
            className="px-8 py-3 font-semibold rounded bg-blue-400 text-gray-900"
          >
            Retour à la page d'accueil
          </Link>
        </div>
      </div>
    </section>
  );
};

export default ErrorComponent;
