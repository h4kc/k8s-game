import React from "react";

const ShimmerVideoCard = () => {
  return (
    <div className="flex flex-col mb-8 animate-pulse">
      <div className="relative h-48 md:h-40 md:rounded-xl overflow-hidden dark:bg-slate-500/[0.4] bg-slate-500/[0.2]">
        {/*Thumbnail*/}
      </div>

      <div className="flex mt-3">

        <div className="flex flex-col ml-1">
          <span className=" dark:bg-slate-400/[0.4] bg-slate-400/[0.2] rounded-md py-2 px-32 md:px-[110px]">
            {/*Details*/}
          </span>

          <span className="mt-2 flex dark:bg-slate-500/[0.4] bg-slate-500/[0.2] rounded-md py-2 px-22 md:px-[70px] mr-10 ">
            {/*Details*/}
          </span>
        </div>
      </div>
    </div>
  );
};

export default ShimmerVideoCard;
