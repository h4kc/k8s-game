import React from "react";

const Loader = () => {
  return (
    <div className="load-bar">
      <div className="bar"></div>
      <div className="bar2"></div>

    </div>
  );
};

export default Loader;
