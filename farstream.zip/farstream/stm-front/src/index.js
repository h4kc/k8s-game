import React, { StrictMode } from "react"
import ReactDOM from "react-dom/client"
import { Provider } from "react-redux"
import { BrowserRouter, Route, Routes } from "react-router-dom"

import "./index.css"
import App from "./App"
import ThemeProvider from "./utils/ThemeProvider"
import { disableReactDevTools } from "@fvilers/disable-react-devtools"
import { PersistGate } from "redux-persist/integration/react"
import { persistor, store } from "./store/store"

if (process.env.NODE_ENV === 'production') disableReactDevTools()

const root = ReactDOM.createRoot(document.getElementById("root"))

root.render(
  <StrictMode>
    <Provider store={store}>
      <ThemeProvider>
        <BrowserRouter>
          <PersistGate persistor={persistor}>
            <Routes>
              <Route path="/*" element={<App />} />
            </Routes>
          </PersistGate>
        </BrowserRouter>
      </ThemeProvider>
    </Provider>
  </StrictMode>
);