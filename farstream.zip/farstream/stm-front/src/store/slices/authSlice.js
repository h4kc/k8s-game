import { createSlice } from '@reduxjs/toolkit'

const authSlice = createSlice({
    name: 'auth',
    initialState: { accToken: null},
    reducers: {
        setCredentials: (state, action) => {
            const { accessToken } = action.payload
            state.accToken = accessToken
        },
        logOut: (state, action) => {
            state.accToken = null
        },
    }
})

export const { setCredentials, logOut } = authSlice.actions

export default authSlice.reducer

export const selectCurrentToken = (state) => state.auth.accToken
export const selectRefreshToken = (state) => state.auth.refToken