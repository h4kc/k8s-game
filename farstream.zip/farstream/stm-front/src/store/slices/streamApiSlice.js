import { apiSlice } from "../api/apiSlice";


export const extendedApiSlice = apiSlice.injectEndpoints({
    endpoints: (builder) => ({ 
        getStreamForUser: builder.query({
            query: () => ({ url: `/stream` }),
            providesTags: (result, error, arg) => {
                const sourceIds = result?.stream?.map(source => source.id) || [];
                return sourceIds.map(id => ({ type: 'Source', id }));
            }
        }),
        updateRecordingStatus: builder.mutation({
            query: ({ id, recordingStatus }) => {
                return {
                    url: `stream/${id}/recording/${recordingStatus}`,
                    method: 'PUT',
                }
            }
        }),
        updateBroadcastStatus: builder.mutation({
            query: ({ id, action }) => {
                return {
                    url: `/stream/${id}/action/${action}`,
                    method: 'POST',
                }
            }
        }),
    }),
})

export const {
    useGetStreamForUserQuery,
    useUpdateRecordingStatusMutation,
    useUpdateBroadcastStatusMutation,
     } = extendedApiSlice
