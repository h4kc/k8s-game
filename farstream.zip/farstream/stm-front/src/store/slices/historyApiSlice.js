import { apiSlice } from "../api/apiSlice"

export const extendedApiSlice = apiSlice.injectEndpoints({
    endpoints: (builder) => ({
        getHistory: builder.query({
            query: () => ({ url: '/history' }),
        }),
        getHistoryById: builder.query({
            query: (HistoryId) => ({ url: `/history/${HistoryId}` }),
        }),
        getHistoryForDuration: builder.query({
            query: ({ duration }) => {
                return {
                    url: `/history/duration`,
                    method: 'GET',
                    body: { duration: duration }
                }
            },
        }),

    }),
})

export const {
    useGetHistoryQuery,
    useGetHistoryByIdQuery,
    useGetHistoryForDurationQuery,
} = extendedApiSlice




