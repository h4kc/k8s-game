import { createSlice } from '@reduxjs/toolkit'

const initialState = {
    theme: localStorage.getItem('theme') || 'light',
    layout: localStorage.getItem('layout') || 'grid',
    wideView: false,
    leftNav: false,
    panelShown: false,
    optionShown: false,
    deleteConfimationShown: false,
    updateMode: false,
    successAlertShown: false,
    errorAlertShown: false,
    alertMsg: "",
}

export const uiSlice = createSlice({
    name: 'ui',
    initialState,
    reducers: {
        toggleTheme: (state) => {
            state.theme = 'dark'
        },
        setDefaultTheme: (state) => {
            state.theme = 'dark'
            localStorage.setItem('theme', state.theme)
        },
        setLayout: (state, action) => {
            state.layout = action.payload
            localStorage.setItem('layout', state.layout)
        },
        toggleWideView: (state) => {
            state.wideView = !state.wideView
        },
        toggleLeftNav: state => {
            state.leftNav = !state.leftNav
        },
        closeLeftNav: state => {
            state.leftNav = false
        },
        openOptions: state => {
            state.optionShown = true
        },
        closeOptions: state => {
            state.optionShown = false
        },
        openDeleteConfimation: state => {
            state.deleteConfimationShown = true
        },
        closeDeleteConfimation: state => {
            state.deleteConfimationShown = false
        },
        openPanel: state => {
            state.panelShown = true
        },
        setUpdateMode: state => {
            state.updateMode = true
        },
        closePanel: state => {
            state.panelShown = false
            state.updateMode = false
        },
        openSuccessAlert: state => {
            state.successAlertShown = true
        },
        closeSuccessAlert: state => {
            state.successAlertShown = false
        },
        openErrorAlert: state => {
            state.errorAlertShown = true
        },
        closeErrorAlert: state => {
            state.errorAlertShown = false
        },
        setAlertMsg: (state, action) => {
            state.alertMsg = action.payload
        },
    },
})

export const {
    toggleTheme,
    setLayout,
    setDefaultTheme,
    toggleWideView,
    toggleLeftNav,
    closeLeftNav,
    openOptions,
    closeOptions,
    openDeleteConfimation,
    closeDeleteConfimation,
    openPanel,
    closePanel,
    setUpdateMode,
    openSuccessAlert,
    closeSuccessAlert,
    openErrorAlert,
    closeErrorAlert,
    setAlertMsg } = uiSlice.actions
export default uiSlice.reducer
