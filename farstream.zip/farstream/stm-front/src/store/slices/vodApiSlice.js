import { apiSlice } from "../api/apiSlice"

export const extendedApiSlice = apiSlice.injectEndpoints({
    endpoints: (builder) => ({
        getAllVods: builder.mutation({
            query: () => ({ url: `/vods` }),
        }),
        getSourcePlaylist: builder.mutation({
            query: (sourceId) => ({ url: `/vods/source/${sourceId}` }),
        }),
        associateVod: builder.mutation({
            query: ({ vodId, sourceId }) => {
                return {
                    url: `/vods/${vodId}/source/${sourceId}`,
                    method: 'PUT',
                }
            },
            invalidatesTags: (result, error, arg) => [
                { type: 'Playlist', vodId: arg.vodId }
            ],
        }),
        associateMultipleVods: builder.mutation({
            query: ({ vodIds, sourceId }) => {
                return {
                    url: `/vods/list/source/${sourceId}`,
                    method: 'PUT',
                    body: {vodIds : vodIds}
                }
            },
            invalidatesTags: (result, error, arg) => [
                { type: 'Playlist', vodId: arg.vodId }
            ],
        }),
        deleteVod: builder.mutation({
            query: (vodId) => ({
                url: `/vods/${vodId}`,
                method: 'DELETE'
            }),
            invalidatesTags: (result, error, arg) => [
                { type: 'Playlist', vodId: arg.vodId }
            ]
        }),
        deleteMultipleVods: builder.mutation({
            query: (vodIds) => ({
                url: `/vods/list`,
                method: 'DELETE',
                body: {vodIds : vodIds}
            }),
            invalidatesTags: (result, error, arg) => [
                { type: 'Playlist', vodId: arg.vodId }
            ]
        }),
    }),
})

export const {
    useGetSourcePlaylistMutation,
    useGetAllVodsMutation,
    useAssociateVodMutation,
    useAssociateMultipleVodsMutation,
    useDeleteVodMutation,
    useDeleteMultipleVodsMutation,
 } = extendedApiSlice




