import { apiSlice } from "../api/apiSlice"

export const extendedApiSlice = apiSlice.injectEndpoints({
    endpoints: (builder) => ({
        getSources: builder.query({
            query: () => ({ url: '/source' }),
            providesTags: (result, error, arg) => {
                const sourceIds = result?.sources?.map(source => source.id) || []
                return [
                    { type: 'Source', id: "LIST" },
                    ...sourceIds.map(id => ({ type: 'Source', id }))
                ]
            }
        }),
        getSourceById: builder.query({
            query: (SourceId) => ({ url: `/source/${SourceId}` }),
        }),
        getSourcesForUser: builder.query({
            query: () => ({ url: `/source/user` }),
            providesTags: (result, error, arg) => {
                const sourceIds = result?.sources?.map(source => source.id) || []
                return [
                    { type: 'Source', id: "LIST" },
                    ...sourceIds.map(id => ({ type: 'Source', id }))
                ]
            }
        }),
        createSource: builder.mutation({
            query: (newSource) => ({
                url: '/source',
                method: 'POST',
                body: newSource,
            }),
            invalidatesTags: (result, error, arg) => [
                { type: 'Source', id: arg.id }
            ]
        }),
        updateSource: builder.mutation({
            query: ({ id, sourceToUpdate }) => {
                return {
                    url: `/source/${id}`,
                    method: 'PUT',
                    body: sourceToUpdate,
                }
            },
            invalidatesTags: (result, error, arg) => [
                { type: 'Source', id: arg.id }
            ]
        }),
        deleteSource: builder.mutation({
            query: (id) => ({
                url: `/source/${id}`,
                method: 'DELETE'
            }),
            invalidatesTags: (result, error, arg) => [
                { type: 'Source', id: arg.id },
            ]
        }),
        generateId: builder.mutation({
            query: () => ({
                url: '/generateId',
                method: 'GET',
            }),
        }),


    }),
})

export const {
    useGetSourcesQuery,
    useGetSourceByIdQuery,
    useGetSourcesForUserQuery,
    useCreateSourceMutation,
    useUpdateSourceMutation,
    useDeleteSourceMutation,
    useGenerateIdMutation
} = extendedApiSlice




