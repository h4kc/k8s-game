import {
    createSelector,
    createEntityAdapter
} from "@reduxjs/toolkit";
import { apiSlice } from "../api/apiSlice";

const userAdapter = createEntityAdapter()

const initialState = userAdapter.getInitialState()

export const extendedApiSlice = apiSlice.injectEndpoints({
    endpoints: (builder) => ({
        getUsers: builder.query({
            query: () => ({ url: '/users' }),
            providesTags: (result, error, arg) => {
                const userIds = result?.users?.map(user => user.id) || [];
                return [
                    { type: 'User', id: "LIST" },
                    ...userIds.map(id => ({ type: 'User', id }))
                ];
            }
        }),

        createUser: builder.mutation({
            query: (newUser) => ({
                url: '/user',
                method: 'POST',
                body: newUser,
            }),
            invalidatesTags: [
                { type: 'User', id: "LIST" }
            ]
        }),
        updateUser: builder.mutation({
            query: ({ id, userToUpdate }) => {
               
                return {
                    url: `/user/${id}`,
                    method: 'PUT',
                    body: userToUpdate,
                }
            },
            invalidatesTags: (result, error, arg) => [
                { type: 'User', id: arg.id }
            ]
        }),
        deleteUser: builder.mutation({
            query: (id) => ({
                url: `/user/${id}`,
                method: 'DELETE',
                body: { id }
            }),
            invalidatesTags: (result, error, arg) => [
                { type: 'User', id: arg.id }
            ]
        }),
    }),
})

export const {
    useGetUsersQuery,
    useCreateUserMutation,
    useUpdateUserMutation,
    useDeleteUserMutation } = extendedApiSlice

export const selectUsersResult = extendedApiSlice.endpoints.getUsers.select()
// export const selectUsersResult = state => state.api?.queries["getUsers(\"user\")"]

const selectUsersData = createSelector(
    selectUsersResult,
    usersResult => {
        const users = usersResult?.data?.users || []
        const normalizedData = userAdapter.upsertMany(initialState, users)
        return normalizedData
    } // normalized state object with ids & entities
)


// Export the selectors using destructuring
export const {
    selectAll: selectAllUsers,
    selectById: selectUserById,
    selectIds: selecTUserIds
} = userAdapter.getSelectors(state => {
    const data = selectUsersData(state) ?? initialState;
    // console.log('usersResult:', usersResult);
    // console.log('selectUsersData(state):', selectUsersData(state));
    return data;
});




