import { combineReducers, configureStore } from "@reduxjs/toolkit"
import uiReducer from "./slices/uiSlice"
import authReducer from "./slices/authSlice"
import { apiSlice } from "./api/apiSlice"
import storage from "redux-persist/lib/storage";
import { persistStore, persistReducer } from "redux-persist";

const persistConfig = {
    key: 'root',
    storage,
    blacklist: ['auth'],
}
const rootReducer = combineReducers({
    ui: uiReducer,
    auth: authReducer,
    [apiSlice.reducerPath]: apiSlice.reducer,
})
const persistedReducer = persistReducer(persistConfig, rootReducer)
export const store = configureStore({
    reducer: persistedReducer,
    middleware: (getDefaultMiddleware) =>
        getDefaultMiddleware({
            serializableCheck: {
                // Ignore these action types, these for a warning that kept popping
                ignoredActions: ['persist/PERSIST', 'persist/REHYDRATE'],
            },
        }).concat(apiSlice.middleware),
    devTools: false,
});
export const persistor = persistStore(store)